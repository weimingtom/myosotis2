arithmetic
==========

Java Arithmetic Engine (formerly Arity)
