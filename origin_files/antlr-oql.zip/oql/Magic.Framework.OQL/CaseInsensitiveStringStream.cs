﻿using System;
using Antlr.Runtime;

namespace Magic.Framework.OQL
{
    /// <summary>
    /// Case insensitive look ahead 
    /// </summary>
    public class CaseInsensitiveStringStream : ANTLRStringStream
    {
        public CaseInsensitiveStringStream() { }
        public CaseInsensitiveStringStream(string input) : base(input) { }
        public override int LA(int i)
        {
            if (i == 0)
                return 0;
            if (i < 0)
            {
                i++;
                if (this.p + i - 1 < 0)
                    return -1;
            }
            if (this.p + i - 1 >= this.n)
            {
                return -1;
            }
            return Char.ToLowerInvariant(this.data[this.p + i - 1]);
        }
    }
}
