﻿//===============================================================================
// Magic Framework
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// 3/10/2008 6:11:05 PM
//===============================================================================

using System;
using System.Collections.Generic;
using System.Text;

namespace Magic.Framework.OQL
{
    /// <summary>
    /// 
    /// </summary>
    public class SqlVisitorTest : ISqlVisitor
    {
        private RequiredClause _clauseFlag = RequiredClause.All;
        public const string VAR_PRIFIX1 = "_p";
        public const string VAR_PRIFIX2 = "_n";
        private int _varIndex2 = 0;
        private bool _spaceAdded = false;
        private StringBuilder _sqlBuilder = new StringBuilder();

        private IDictionary<string, string> _tableMapping = new Dictionary<string, string>();

        public SqlVisitorTest()
        {
            //table name
            this._tableMapping.Add("table1", "__t1");
            this._tableMapping.Add("table2", "__t2");
            //table alias in sql, to test if the alias is passed into Table()
            this._tableMapping.Add("t1", "__t1");
            this._tableMapping.Add("t2", "__t2");
        }

        /// <summary>
        /// Output sql text.
        /// </summary>
        /// <param name="sql"></param>
        public void Sql(string sql)
        {
            if (string.IsNullOrEmpty(sql) || sql.Length <= 0) return;
            this._spaceAdded = false;
            if (sql.Length == 1)
            {
                char c = sql[0];
                if (c == '(' || c == ',' || c == ' ') this._spaceAdded = true;
            }
            this._sqlBuilder.Append(sql);
        }
        /// <summary>
        /// Output named variable.
        /// </summary>
        /// <param name="varName"></param>
        public void NamedVariable(string varName)
        {
            this._spaceAdded = false;
            this._sqlBuilder.Append(VAR_PRIFIX2).Append(this._varIndex2++);
        }
        /// <summary>
        /// Output positioned variable.
        /// </summary>
        /// <param name="index"></param>
        public void PositionedVariable(int index)
        {
            this._spaceAdded = false;
            this._sqlBuilder.Append(VAR_PRIFIX1).Append(index);
        }
        /// <summary>
        /// Output object: table name or column name.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="alias"></param>
        public void Table(string name)
        {
            this._spaceAdded = false;
            if (this._tableMapping.ContainsKey(name)) this._sqlBuilder.Append(this._tableMapping[name]);
            else this._sqlBuilder.Append(name);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        public void Column(string table, string name, bool iAmSure)
        {
            this._spaceAdded = false;
            this._sqlBuilder.Append(name);
        }
        /// <summary>
        /// The column maybe comes from the <paramref name="tables"/>
        /// </summary>
        /// <param name="tables"></param>
        /// <param name="name"></param>
        public void Column(IList<string> tables, string name)
        {
            this._sqlBuilder.Append(name);
        }
        /// <summary>
        /// Request add a white space
        /// </summary>
        public void Space()
        {
            //remove additional white spaces
            if (!this._spaceAdded)
            {
                this._sqlBuilder.Append(" ");
                this._spaceAdded = true;
            }
        }

        public override string ToString()
        {
            return this._sqlBuilder.ToString();
        }
        public void Clear()
        {
            this._sqlBuilder = new StringBuilder();
        }

        /// <summary>
        /// Which clauses the ISqlVisitor is requesting for.
        /// </summary>
        public RequiredClause ClauseFlag
        {
            get
            {
                return this._clauseFlag;
            }
            set
            {
                this._clauseFlag = value;
            }
        }
    }
}
