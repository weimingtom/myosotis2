﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 7, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Constant, such as int, decimal, float, string literal. System variables(starting with @@) are treated as constant.
    /// </summary>
    public class Constant : Expression
    {
        /// <summary>
        /// Combines all tokens text to this expression, including the one passed into this construct.
        /// </summary>
        /// <remarks>
        /// Real -> {new Constant($Real)}
        /// All constant rewriting rules use the above style.
        /// </remarks>
        /// <param name="t"></param>
        public Constant(IToken t)
            : base(t)
        {
        }
        public Constant(Expression exp)
            : base(new CommonToken(OQLParser.TextNode, ""))
        {
            if (Expressions.Text.IsText(exp))
                this.Token.Text = exp.ToString();
            else if (exp != null && exp._children != null && exp._children.Count == 1 && Expressions.Text.IsText(exp._children[0]))
                this.Token.Text = exp._children[0].ToString();
            //new CommonToken(OQLParser.TextNode, exp == null ? "" : exp.ToString())
        }

        public override Expression DupNode()
        {
            return new Constant(this.Token);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString()); //Constant is a text like expression
        }
        public static bool IsConstant(Expression exp)
        {
            if (exp == null || exp.IsNil) return false;
            return exp is Constant;
        }
    }
}
