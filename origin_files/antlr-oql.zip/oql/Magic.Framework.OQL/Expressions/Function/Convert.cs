﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 10, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions.Function
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class Convert : Expression
    {
        #region constructors
        public Convert(Expression node)
            : base(node.Token)
        {
        }
        public Convert(IToken t)
            : base(t)
        {
        }
        #endregion

        public override Expression DupNode()
        {
            return new Convert(this);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString()); //CONVERT keyword
            visitor.Sql("(");
            this.InternalVisitSql(visitor, true, ","); //datatype, expression, style clause
            visitor.Sql(")");
        }
    }
}
