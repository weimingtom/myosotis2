﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 10, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions.Function
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class Avg : Expression
    {
        #region constructors
        public Avg(Expression node)
            : base(node.Token)
        {
        }
        public Avg(IToken t)
            : base(t)
        {
        }
        #endregion

        public override Expression DupNode()
        {
            return new Avg(this);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString()); //AVG keyword
            visitor.Sql("(");
            if (this._children != null && this._children.Count > 0)
                this._children[0].VisitSql(visitor);
            visitor.Sql(")");
        }
    }
}
