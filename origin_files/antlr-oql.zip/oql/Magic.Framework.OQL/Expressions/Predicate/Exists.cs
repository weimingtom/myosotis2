﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 10, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions.Predicate
{
    /// <summary>
    /// EXISTS subquery
    /// child 0: subquery
    /// </summary>
    public class Exists : Expression
    {
        public Exists(IToken t)
            : base(t)
        {
        }

        public override Expression DupNode()
        {
            return new Exists(this.Token);
        }

        public override void VisitSql(ISqlVisitor visitor)
        {
            //children: expression, subquery
            if (this._children == null || this._children.Count != 1) return;
            visitor.Sql(this.ToString()); //EXISTS keyword
            this._children[0].VisitSql(visitor); //sub query
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.EXISTS;
            }
        }
    }
}
