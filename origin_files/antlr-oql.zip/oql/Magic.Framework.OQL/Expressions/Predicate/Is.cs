﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 10, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions.Predicate
{
    /// <summary>
    /// IS NOT? NULL
    /// </summary>
    public class Is : Expression
    {
        public Is(IToken t)
            : base(t)
        {
            t.Text = string.Empty;
        }

        public override Expression DupNode()
        {
            return new Is(this.Token);
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.Predicate_Is;
            }
        }
    }
}
