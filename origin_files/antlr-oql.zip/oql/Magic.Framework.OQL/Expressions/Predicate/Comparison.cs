﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 10, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions.Predicate
{
    /// <summary>
    /// Comparison predicates, such as exp1>=exp2, exp1 LIKE exp2, exp1!&lt;exp2
    /// </summary>
    public class Comparison : Expression
    {
        public Comparison(IToken t)
            : base(t)
        {
            t.Text = string.Empty;
        }

        public override Expression DupNode()
        {
            return new Comparison(this.Token);
        }

        public override void VisitSql(ISqlVisitor visitor)
        {
            //Comparison has and only has three children: left expression, operator, right expression.
            if (this._children == null) return;
            for (int i = 0; i < this._children.Count; i++)
            {
                if (!this._children[i].IsNil && this._children[i].Token.Type == OQLParser.LIKE)
                    visitor.Space();
                this._children[i].VisitSql(visitor);
                if (!this._children[i].IsNil && this._children[i].Token.Type == OQLParser.LIKE)
                    visitor.Space();
            }
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.Predicate;
            }
        }
    }
}
