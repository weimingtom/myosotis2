﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 8, 2008
//===============================================================================

using Antlr.Runtime;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Table, column, and function name
    /// <remarks>
    /// </remarks>
    /// </summary>
    public class OrderByItem : Expression
    {
        /// <summary>
        /// <param name="t"></param>
        public OrderByItem(IToken t)
            : base(t)
        {
            this.Token.Text = "";
        }

        public override Expression DupNode()
        {
            return new OrderByItem(this.Token);
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.OrderByItem;
            }
        }

        //use the default VisitSql method of Expression
    }
}
