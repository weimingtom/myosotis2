﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 8, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class JoinedTable : CombinedKeywords
    {
        #region constructors
        public JoinedTable(Expression node)
            : base(node.Token, string.Empty, false, null, false
            , new int[] { OQLParser.INNER, OQLParser.CROSS, OQLParser.LEFT, OQLParser.RIGHT, OQLParser.OUTER, OQLParser.JOIN })
        {
        }
        public JoinedTable(IToken t)
            : base(t, string.Empty, false, null, false
            , new int[] { OQLParser.INNER, OQLParser.CROSS, OQLParser.LEFT, OQLParser.RIGHT, OQLParser.OUTER, OQLParser.JOIN })
        {
        }
        #endregion

        protected override bool PreCombine(int count, System.Text.StringBuilder builder, IToken token)
        {
            if (count > 0) builder.Append(" ");
            return true;
        }

        public override Expression DupNode()
        {
            return new JoinedTable(this);
        }
        public static bool IsJoinedTable(Expression exp)
        {
            if (exp == null || exp.IsNil) return false;
            return exp.Token.Type == OQLParser.JoinedTable;
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            //JoinedTable has one or two children, the first is a Table, and the second, if exists, is the ON clause.
            visitor.Sql(this.ToString()); //INNER/LEFT/RIGHT JOIN  keywords
            visitor.Space();
            this._children[0].VisitSql(visitor); //table
            visitor.Space();
            if (this._children.Count == 2) //On clause
                this._children[1].VisitSql(visitor);
        }
        public Table GetTable()
        {
            if (this._children == null || this._children.Count <= 0) return null;
            return this._children[0] as Table;
        }
    }
}
