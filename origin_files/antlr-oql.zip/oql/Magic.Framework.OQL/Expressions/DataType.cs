﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 7, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Currently DataType is treated as text expressions.
    /// </summary>
    public class DataType : Text
    {
        /// <summary>
        /// Combines all subtree tokens text to this expression, but ingore the DataType token.
        /// </summary>
        /// <remarks>
        /// datatype -> ^(DataType datatype)
        /// All DataType rewriting rules use the above style.
        /// </remarks>
        /// <param name="t"></param>
        public DataType(IToken t)
            : base(t, string.Empty, false, null) //Just ignore the imaginary token.
        {
        }

        public override Expression DupNode()
        {
            return new DataType(this.Token);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString()); //DataType is a Text expression
        }
    }
}