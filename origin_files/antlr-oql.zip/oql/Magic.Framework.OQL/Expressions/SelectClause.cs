﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 7, 2008
//===============================================================================

using System.Collections.Generic;
using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class SelectClause : CombinedKeywords
    {
        private bool _hasDistinct = false;

        #region constructors
        public SelectClause(Expression node)
            : base(node.Token, string.Empty, false, null, false, new int[] { OQLParser.SELECT, OQLParser.DISTINCT })
        {
        }
        public SelectClause(IToken t)
            : base(t, string.Empty, false, null, false, new int[] { OQLParser.SELECT, OQLParser.DISTINCT })
        {
        }
        #endregion

        protected override bool PreCombine(int count, System.Text.StringBuilder builder, IToken token)
        {
            if (token.Type == OQLParser.DISTINCT)
            {
                this._hasDistinct = true;
                builder.Append(" ");
            }
            return true;
        }

        public override Expression DupNode()
        {
            return new SelectClause(this);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString());
            visitor.Space();
            this.InternalVisitSql(visitor, true, ",");
        }
        public static bool IsSelectClause(Expression exp)
        {
            if (exp == null || exp.IsNil) return false;
            return exp.Token.Type == OQLParser.SelectClause;
        }
        public IList<Column> Columns
        {
            get
            {
                IList<Column> r = new List<Column>();
                if (this._children == null || this._children.Count <= 0) return r;
                foreach (Expression exp in this)
                    if (Column.IsColumn(exp)) r.Add(exp as Column);
                return r;
            }
        }
        public bool HasDistinct
        {
            get
            {
                return this._hasDistinct;
            }
        }
    }
}
