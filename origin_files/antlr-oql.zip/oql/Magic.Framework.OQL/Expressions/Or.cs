﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 9, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class Or : Condition
    {
        #region constructors
        public Or(Expression node)
            : base(node.Token)
        {
        }
        public Or(IToken t)
            : base(t)
        {
        }
        #endregion

        public override Expression DupNode()
        {
            return new Or(this);
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            //Or has and only has two children.
            if (this._children == null || this._children.Count != 2) return;
            this._children[0].VisitSql(visitor); //left expression
            visitor.Space();
            visitor.Sql(this.ToString()); //OR keyword
            visitor.Space();
            this._children[1].VisitSql(visitor); //right expression
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.OR;
            }
        }
    }
}
