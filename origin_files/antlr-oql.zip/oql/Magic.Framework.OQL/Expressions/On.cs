﻿//===============================================================================
// Magic Framework
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// 3/10/2008 6:06:07 PM
//===============================================================================

using Antlr.Runtime;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// </summary>
    public class On : Expression
    {
        public On(IToken t)
            : base(t)
        {
        }

        public override Expression DupNode()
        {
            return new On(this.Token);
        }

        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString()); //ON keyword
            visitor.Space();
            this.InternalVisitSql(visitor, false, null); //conditions
        }
    }
}
