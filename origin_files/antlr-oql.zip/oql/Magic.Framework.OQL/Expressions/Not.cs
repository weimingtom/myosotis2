﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 9, 2008
//===============================================================================

using Antlr.Runtime;
using Antlr.Runtime.Tree;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Select clause
    /// </summary>
    public class Not : Condition
    {
        #region constructors
        public Not(Expression node)
            : base(node.Token)
        {
        }
        public Not(IToken t)
            : base(t)
        {
        }
        #endregion

        public override Expression DupNode()
        {
            return new Not(this);
        }

        public override void VisitSql(ISqlVisitor visitor)
        {
            //Not has and only has one child.
            if (this._children == null || this._children.Count != 1) return;
            visitor.Sql(this.ToString()); //NOT keyword
            visitor.Space();
            this._children[0].VisitSql(visitor);
        }

        internal static int TreeType
        {
            get
            {
                return OQLParser.NOT;
            }
        }
    }
}
