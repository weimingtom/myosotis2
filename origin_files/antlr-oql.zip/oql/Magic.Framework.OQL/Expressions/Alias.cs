﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 7, 2008
//===============================================================================

using Antlr.Runtime;

namespace Magic.Framework.OQL.Expressions
{
    /// <summary>
    /// Table, column, and function name
    /// <remarks>
    /// </remarks>
    /// </summary>
    public class Alias : Expression
    {
        private string _as = null;
        private string _alias = null;

        /// <summary>
        /// 
        /// </summary>
        /// AS? identifier -> ^(Alias AS? identifier)
        /// All Identifier rewriting rules use the above style.
        /// <param name="t"></param>
        public Alias(IToken t)
            : base(t)
        {
            this.Token.Text = "";
        }

        private void SetValue(IToken token)
        {
            if (token.Type == OQLParser.AS)
                this._as = token.Text;
            else if (token.Type == OQLParser.QuotedIdentifier || token.Type == OQLParser.NonQuotedIdentifier)
                this._alias = token.Text;
        }
        public override void AddChild(Expression t)
        {
            if (t == null) return;
            if (!t.IsNil) this.SetValue(t.Token);
            if (t._children != null && t._children.Count > 0)
                for (int i = 0; i < t._children.Count; i++)
                    if (!t._children[i].IsNil) this.SetValue(t._children[i].Token);
        }
        public override Expression DupNode()
        {
            return new Identifier(this.Token);
        }
        public override string ToString()
        {
            return this._as == null ? this._alias : this._as + " " + this._alias;
        }
        public override void VisitSql(ISqlVisitor visitor)
        {
            visitor.Sql(this.ToString());
        }

        public string Name
        {
            get
            {
                return this._alias;
            }
        }

        public static bool IsAlias(Expression exp)
        {
            if (exp == null || exp.IsNil) return false;
            return exp.Token.Type == OQLParser.Alias;
        }
    }
}