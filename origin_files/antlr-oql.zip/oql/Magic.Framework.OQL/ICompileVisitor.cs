﻿using System;
using System.Collections.Generic;
using System.Text;
using Magic.Framework.OQL;
using Magic.Framework.OQL.Expressions;

namespace Magic.Framework.OQL
{
    public interface ICompileVisitor
    {
        /// <summary>
        /// Compile a query.
        /// </summary>
        /// <param name="stmt"></param>
        void VisitQuery(QueryStatement stmt);
        /// <summary>
        /// Compile a positioned variable.
        /// </summary>
        /// <param name="index"></param>
        /// <param name="var"></param>
        void VisitPositionedVariable(UserVariable var);
    }
}