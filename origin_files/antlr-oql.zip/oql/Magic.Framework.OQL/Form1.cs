﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Antlr.Runtime;
using Antlr.Runtime.Tree;
using Magic.Framework.OQL.Factory;
using Magic.Framework.OQL;
using Magic.Framework.OQL.Expressions;

namespace Magic.Framework.OQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //            if (this.textBox1.Text.Length <= 0) return;

            //            string s2 = null;
            //            OQLParser.start_return r = null;

            //            DateTime start = DateTime.Now;
            //            for (int i = 0; i < 1000; i++)
            //            {
            //                string s = string.Format(@"Select 12, 'ada {0} And >0""' As c1, (select 1), @UserName, case when a=1 then 1 else 0 end, sum(a) as Total
            //From Sys_User a, Sys_Org b
            //inner join Sys_Org_View c on c.Org_Id=b.Org_Id and (ccc={1})
            //Where cast(a.User_Id as varchar)=b.User_Id or (a=b and Total between 100 And 1000)
            //Group bY a, b
            //haViNg Total between 100 And 1000
            //Order By a, DDD Desc, A asc", i, i);
            //                CaseInsensitiveStringStream stream = new CaseInsensitiveStringStream(s);
            //                OQLLexer lex = new OQLLexer(stream);
            //                CommonTokenStream tokens = new CommonTokenStream(lex);
            //                OQLParser parser = new OQLParser(tokens);
            //                parser.TreeAdaptor = new TreeFactory();
            //                OQLParser.start_return statements = null;
            //                statements = parser.start();
            //                if (i == 309)
            //                {
            //                    s2 = s;
            //                    r = statements;
            //                }
            //            }
            //            TimeSpan ts = DateTime.Now - start;
            //            MessageBox.Show((ts.Seconds * 1000 + ts.Milliseconds).ToString());

            //            this.textBox1.Text = s2;
            //            this.treeView1.Nodes.Clear();
            //            for (int i = 0; i < r.tree.ChildCount; i++)
            //            {
            //                TreeNode node = new TreeNode();
            //                this.ShowAST(node, r.tree.GetChild(i));
            //                this.treeView1.Nodes.Add(node);
            //            }

            OQLLexer lex = new OQLLexer(new CaseInsensitiveStringStream(this.textBox1.Text));
            CommonTokenStream tokens = new CommonTokenStream(lex);
            OQLParser parser = new OQLParser(tokens);
            parser.TreeAdaptor = new TreeFactory();
            OQLParser.start_return statements = null;
            statements = parser.start();
            if (statements == null || statements.tree == null)
            {
                MessageBox.Show("returned null");
                return;
            }

            this.treeView1.Nodes.Clear();
            for (int i = 0; i < statements.tree.ChildCount; i++)
            {
                TreeNode node = new TreeNode();
                this.ShowAST(node, statements.tree.GetChild(i));
                this.treeView1.Nodes.Add(node);
            }

            if (statements.Tree == null) return;

            //string sql = "";
            //SqlVisitorTest visitor = new SqlVisitorTest();
            //QueryStatement query = null;
            //if (statements.tree is QueryStatement)
            //    query = statements.tree as QueryStatement;
            //else if (statements.tree._children != null && statements.tree._children.Count > 0 && statements.tree._children[0] is QueryStatement)
            //    query = statements.tree._children[0] as QueryStatement;
            //if (query == null) return;
            //query.VisitCompile(query);
            //DateTime start = DateTime.Now;
            //for (int i = 0; i < 2000; i++)
            //{
            //    query.VisitSql(visitor);
            //    visitor.Clear();
            //}
            //TimeSpan ts = DateTime.Now - start;
            //MessageBox.Show((ts.Seconds * 1000 + ts.Milliseconds).ToString());
            //this.textBox1.Text = visitor.ToString();
        }

        private void ShowAST(TreeNode treeNode, ITree tree)
        {
            if (tree == null || tree.IsNil) return;
            treeNode.Text = tree.Text + "   -   (" + tree.GetType().Name + ")";

            for (int i = 0; i < tree.ChildCount; i++)
            {
                TreeNode node = new TreeNode();
                this.ShowAST(node, tree.GetChild(i));
                treeNode.Nodes.Add(node);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = System.IO.File.ReadAllText("input.txt");
        }
    }
}