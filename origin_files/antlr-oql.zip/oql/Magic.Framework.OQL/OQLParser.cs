// $ANTLR 3.0.1 OQL.g 2008-10-09 05:40:17
namespace  Magic.Framework.OQL
{
using Magic.Framework.OQL.Expressions; 

using System;
using Antlr.Runtime;
using IList 		= System.Collections.IList;
using ArrayList 	= System.Collections.ArrayList;
using Stack 		= Antlr.Runtime.Collections.StackList;




using Antlr.Runtime.Tree;

public class OQLParser : Parser 
{
    public static readonly string[] tokenNames = new string[] 
	{
        "<invalid>", 
		"<EOR>", 
		"<DOWN>", 
		"<UP>", 
		"Eq", 
		"Neq1", 
		"Neq2", 
		"Le1", 
		"Le2", 
		"Lt", 
		"Ge1", 
		"Ge2", 
		"Gt", 
		"DIV", 
		"PLUS", 
		"MINUS", 
		"MUL", 
		"MOD", 
		"BITAND", 
		"BITNOT", 
		"BITOR", 
		"BITXOR", 
		"LPAREN", 
		"RPAREN", 
		"COLON", 
		"COMMA", 
		"SEMI", 
		"DOT", 
		"ALL", 
		"AND", 
		"AS", 
		"ASC", 
		"BETWEEN", 
		"BY", 
		"CASE", 
		"CROSS", 
		"DELETE", 
		"DESC", 
		"DISTINCT", 
		"ELSE", 
		"END", 
		"EXISTS", 
		"FOR", 
		"FROM", 
		"GROUP", 
		"HAVING", 
		"IN", 
		"INNER", 
		"INSERT", 
		"INTO", 
		"IS", 
		"JOIN", 
		"LEFT", 
		"LIKE", 
		"NOT", 
		"NULL", 
		"ON", 
		"OR", 
		"ORDER", 
		"OUTER", 
		"RIGHT", 
		"SELECT", 
		"SET", 
		"THEN", 
		"UNION", 
		"UPDATE", 
		"VALUES", 
		"WHEN", 
		"WHERE", 
		"TRUNCATE", 
		"SUM", 
		"AVG", 
		"MAX", 
		"MIN", 
		"COUNT", 
		"LEN", 
		"CHAR", 
		"NCHAR", 
		"VARCHAR", 
		"NVARCHAR", 
		"TEXT", 
		"NTEXT", 
		"DATETIME", 
		"INT", 
		"DECIMAL", 
		"BINARY", 
		"QuotedIdentifier", 
		"NonQuotedIdentifier", 
		"Integer", 
		"StringLiteral", 
		"Real", 
		"UserVariable", 
		"Whitespace", 
		"SingleLineComment", 
		"MultiLineComment", 
		"DigitChar", 
		"NonQuotedIdentifier_0", 
		"LetterChar", 
		"TextNode", 
		"SelectClause", 
		"UnionStmt", 
		"SelectStmt", 
		"WhereClause", 
		"GroupByClause", 
		"OrderByClause", 
		"OrderByItem", 
		"UpdateClause", 
		"UpdateStmt", 
		"DeleteClause", 
		"DeleteStmt", 
		"InsertClause", 
		"InsertStmt", 
		"Alias", 
		"Table", 
		"JoinedTable", 
		"Column", 
		"Predicate", 
		"Predicate_Is", 
		"DataType", 
		"Group", 
		"UserFunction"
    };

    public const int DataType = 118;
    public const int BITNOT = 19;
    public const int UpdateClause = 106;
    public const int MOD = 17;
    public const int Group = 119;
    public const int CASE = 34;
    public const int InsertClause = 110;
    public const int CHAR = 76;
    public const int UserFunction = 120;
    public const int COUNT = 74;
    public const int NOT = 54;
    public const int EOF = -1;
    public const int Lt = 9;
    public const int RPAREN = 23;
    public const int INSERT = 48;
    public const int UnionStmt = 100;
    public const int OrderByClause = 104;
    public const int NonQuotedIdentifier = 87;
    public const int SELECT = 61;
    public const int INTO = 49;
    public const int DigitChar = 95;
    public const int ASC = 31;
    public const int NTEXT = 81;
    public const int Table = 113;
    public const int UpdateStmt = 107;
    public const int InsertStmt = 111;
    public const int NULL = 55;
    public const int ELSE = 39;
    public const int NonQuotedIdentifier_0 = 96;
    public const int UserVariable = 91;
    public const int Eq = 4;
    public const int ON = 56;
    public const int INT = 83;
    public const int DELETE = 36;
    public const int OrderByItem = 105;
    public const int MUL = 16;
    public const int Le2 = 8;
    public const int GROUP = 44;
    public const int Le1 = 7;
    public const int LetterChar = 97;
    public const int BITOR = 20;
    public const int OR = 57;
    public const int FROM = 43;
    public const int END = 40;
    public const int DISTINCT = 38;
    public const int WHERE = 68;
    public const int INNER = 47;
    public const int SingleLineComment = 93;
    public const int ORDER = 58;
    public const int NCHAR = 77;
    public const int Column = 115;
    public const int Gt = 12;
    public const int UPDATE = 65;
    public const int MAX = 72;
    public const int FOR = 42;
    public const int VARCHAR = 78;
    public const int AND = 29;
    public const int SUM = 70;
    public const int CROSS = 35;
    public const int BITAND = 18;
    public const int LPAREN = 22;
    public const int AS = 30;
    public const int Ge1 = 10;
    public const int IN = 46;
    public const int THEN = 63;
    public const int Ge2 = 11;
    public const int Predicate_Is = 117;
    public const int COMMA = 25;
    public const int IS = 50;
    public const int LEFT = 52;
    public const int AVG = 71;
    public const int ALL = 28;
    public const int TRUNCATE = 69;
    public const int BITXOR = 21;
    public const int SelectClause = 99;
    public const int Neq2 = 6;
    public const int Real = 90;
    public const int PLUS = 14;
    public const int EXISTS = 41;
    public const int Predicate = 116;
    public const int DOT = 27;
    public const int SelectStmt = 101;
    public const int Whitespace = 92;
    public const int NVARCHAR = 79;
    public const int MultiLineComment = 94;
    public const int Neq1 = 5;
    public const int LIKE = 53;
    public const int OUTER = 59;
    public const int BY = 33;
    public const int DATETIME = 82;
    public const int VALUES = 66;
    public const int RIGHT = 60;
    public const int SET = 62;
    public const int HAVING = 45;
    public const int MIN = 73;
    public const int MINUS = 15;
    public const int TEXT = 80;
    public const int QuotedIdentifier = 86;
    public const int DeleteStmt = 109;
    public const int SEMI = 26;
    public const int DeleteClause = 108;
    public const int JOIN = 51;
    public const int UNION = 64;
    public const int COLON = 24;
    public const int StringLiteral = 89;
    public const int DECIMAL = 84;
    public const int GroupByClause = 103;
    public const int WHEN = 67;
    public const int JoinedTable = 114;
    public const int LEN = 75;
    public const int Alias = 112;
    public const int DESC = 37;
    public const int DIV = 13;
    public const int BINARY = 85;
    public const int WhereClause = 102;
    public const int TextNode = 98;
    public const int BETWEEN = 32;
    public const int Integer = 88;
    
    
        public OQLParser(ITokenStream input) 
    		: base(input)
    	{
    		InitializeCyclicDFAs();
        }
        
    protected ITreeAdaptor adaptor = new CommonTreeAdaptor();
    
    public ITreeAdaptor TreeAdaptor
    {
        get { return this.adaptor; }
        set { this.adaptor = value; }
    }

    override public string[] TokenNames
	{
		get { return tokenNames; }
	}

    override public string GrammarFileName
	{
		get { return "OQL.g"; }
	}


    public class start_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start start
    // OQL.g:111:1: start : statements ;
    public start_return start() // throws RecognitionException [1]
    {   
        start_return retval = new start_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        statements_return statements1 = null;
        
        
    
        try 
    	{
            // OQL.g:111:6: ( statements )
            // OQL.g:111:8: statements
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_statements_in_start938);
            	statements1 = statements();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, statements1.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end start

    public class statements_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start statements
    // OQL.g:112:1: statements : ( statement ( ( SEMI )? ) )* EOF ;
    public statements_return statements() // throws RecognitionException [1]
    {   
        statements_return retval = new statements_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken SEMI3 = null;
        IToken EOF4 = null;
        statement_return statement2 = null;
        
        
        Expression SEMI3_tree=null;
        Expression EOF4_tree=null;
    
        try 
    	{
            // OQL.g:112:11: ( ( statement ( ( SEMI )? ) )* EOF )
            // OQL.g:112:13: ( statement ( ( SEMI )? ) )* EOF
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	// OQL.g:112:13: ( statement ( ( SEMI )? ) )*
            	do 
            	{
            	    int alt2 = 2;
            	    int LA2_0 = input.LA(1);
            	    
            	    if ( (LA2_0 == DELETE || LA2_0 == INSERT || LA2_0 == SELECT || LA2_0 == UPDATE || LA2_0 == TRUNCATE) )
            	    {
            	        alt2 = 1;
            	    }
            	    
            	
            	    switch (alt2) 
            		{
            			case 1 :
            			    // OQL.g:112:14: statement ( ( SEMI )? )
            			    {
            			    	PushFollow(FOLLOW_statement_in_statements947);
            			    	statement2 = statement();
            			    	followingStackPointer_--;
            			    	
            			    	adaptor.AddChild(root_0, statement2.Tree);
            			    	// OQL.g:112:24: ( ( SEMI )? )
            			    	// OQL.g:112:25: ( SEMI )?
            			    	{
            			    		// OQL.g:112:25: ( SEMI )?
            			    		int alt1 = 2;
            			    		int LA1_0 = input.LA(1);
            			    		
            			    		if ( (LA1_0 == SEMI) )
            			    		{
            			    		    alt1 = 1;
            			    		}
            			    		switch (alt1) 
            			    		{
            			    		    case 1 :
            			    		        // OQL.g:112:25: SEMI
            			    		        {
            			    		        	SEMI3 = (IToken)input.LT(1);
            			    		        	Match(input,SEMI,FOLLOW_SEMI_in_statements950); 
            			    		        	SEMI3_tree = (Expression)adaptor.Create(SEMI3);
            			    		        	adaptor.AddChild(root_0, SEMI3_tree);

            			    		        
            			    		        }
            			    		        break;
            			    		
            			    		}

            			    	
            			    	}

            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop2;
            	    }
            	} while (true);
            	
            	loop2:
            		;	// Stops C# compiler whinging that label 'loop2' has no statements

            	EOF4 = (IToken)input.LT(1);
            	Match(input,EOF,FOLLOW_EOF_in_statements957); 
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end statements

    public class statement_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start statement
    // OQL.g:114:1: statement : ( selectStatement | updateStatement | deleteStatement | insertStatement );
    public statement_return statement() // throws RecognitionException [1]
    {   
        statement_return retval = new statement_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        selectStatement_return selectStatement5 = null;

        updateStatement_return updateStatement6 = null;

        deleteStatement_return deleteStatement7 = null;

        insertStatement_return insertStatement8 = null;
        
        
    
        try 
    	{
            // OQL.g:114:10: ( selectStatement | updateStatement | deleteStatement | insertStatement )
            int alt3 = 4;
            switch ( input.LA(1) ) 
            {
            case SELECT:
            	{
                alt3 = 1;
                }
                break;
            case UPDATE:
            	{
                alt3 = 2;
                }
                break;
            case DELETE:
            case TRUNCATE:
            	{
                alt3 = 3;
                }
                break;
            case INSERT:
            	{
                alt3 = 4;
                }
                break;
            	default:
            	    NoViableAltException nvae_d3s0 =
            	        new NoViableAltException("114:1: statement : ( selectStatement | updateStatement | deleteStatement | insertStatement );", 3, 0, input);
            
            	    throw nvae_d3s0;
            }
            
            switch (alt3) 
            {
                case 1 :
                    // OQL.g:117:2: selectStatement
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_selectStatement_in_statement971);
                    	selectStatement5 = selectStatement();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, selectStatement5.Tree);
                    
                    }
                    break;
                case 2 :
                    // OQL.g:118:4: updateStatement
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_updateStatement_in_statement976);
                    	updateStatement6 = updateStatement();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, updateStatement6.Tree);
                    
                    }
                    break;
                case 3 :
                    // OQL.g:119:4: deleteStatement
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_deleteStatement_in_statement981);
                    	deleteStatement7 = deleteStatement();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, deleteStatement7.Tree);
                    
                    }
                    break;
                case 4 :
                    // OQL.g:120:4: insertStatement
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_insertStatement_in_statement986);
                    	insertStatement8 = insertStatement();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, insertStatement8.Tree);
                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end statement

    public class selectStatement_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start selectStatement
    // OQL.g:122:1: selectStatement : select_1 ( UNION ( ALL )? select_2 )* ( orderBy )? -> {isUnion}? ^( UnionStmt ^( SelectStmt select_1 ) ( ^( TextNode UNION ( ALL )? ) ^( SelectStmt select_2 ) )+ ( orderBy )? ) -> {!isUnion}? ^( SelectStmt select_1 ( orderBy )? ) ->;
    public selectStatement_return selectStatement() // throws RecognitionException [1]
    {   
        selectStatement_return retval = new selectStatement_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken UNION10 = null;
        IToken ALL11 = null;
        select_1_return select_19 = null;

        select_2_return select_212 = null;

        orderBy_return orderBy13 = null;
        
        
        Expression UNION10_tree=null;
        Expression ALL11_tree=null;
        RewriteRuleTokenStream stream_UNION = new RewriteRuleTokenStream(adaptor,"token UNION");
        RewriteRuleTokenStream stream_ALL = new RewriteRuleTokenStream(adaptor,"token ALL");
        RewriteRuleSubtreeStream stream_select_1 = new RewriteRuleSubtreeStream(adaptor,"rule select_1");
        RewriteRuleSubtreeStream stream_select_2 = new RewriteRuleSubtreeStream(adaptor,"rule select_2");
        RewriteRuleSubtreeStream stream_orderBy = new RewriteRuleSubtreeStream(adaptor,"rule orderBy");
        try 
    	{
            // OQL.g:123:2: ( select_1 ( UNION ( ALL )? select_2 )* ( orderBy )? -> {isUnion}? ^( UnionStmt ^( SelectStmt select_1 ) ( ^( TextNode UNION ( ALL )? ) ^( SelectStmt select_2 ) )+ ( orderBy )? ) -> {!isUnion}? ^( SelectStmt select_1 ( orderBy )? ) ->)
            // OQL.g:123:4: select_1 ( UNION ( ALL )? select_2 )* ( orderBy )?
            {
            	bool isUnion=false;
            	PushFollow(FOLLOW_select_1_in_selectStatement999);
            	select_19 = select_1();
            	followingStackPointer_--;
            	
            	stream_select_1.Add(select_19.Tree);
            	// OQL.g:123:35: ( UNION ( ALL )? select_2 )*
            	do 
            	{
            	    int alt5 = 2;
            	    int LA5_0 = input.LA(1);
            	    
            	    if ( (LA5_0 == UNION) )
            	    {
            	        alt5 = 1;
            	    }
            	    
            	
            	    switch (alt5) 
            		{
            			case 1 :
            			    // OQL.g:123:36: UNION ( ALL )? select_2
            			    {
            			    	UNION10 = (IToken)input.LT(1);
            			    	Match(input,UNION,FOLLOW_UNION_in_selectStatement1002); 
            			    	stream_UNION.Add(UNION10);

            			    	// OQL.g:123:42: ( ALL )?
            			    	int alt4 = 2;
            			    	int LA4_0 = input.LA(1);
            			    	
            			    	if ( (LA4_0 == ALL) )
            			    	{
            			    	    alt4 = 1;
            			    	}
            			    	switch (alt4) 
            			    	{
            			    	    case 1 :
            			    	        // OQL.g:123:42: ALL
            			    	        {
            			    	        	ALL11 = (IToken)input.LT(1);
            			    	        	Match(input,ALL,FOLLOW_ALL_in_selectStatement1004); 
            			    	        	stream_ALL.Add(ALL11);

            			    	        
            			    	        }
            			    	        break;
            			    	
            			    	}

            			    	PushFollow(FOLLOW_select_2_in_selectStatement1007);
            			    	select_212 = select_2();
            			    	followingStackPointer_--;
            			    	
            			    	stream_select_2.Add(select_212.Tree);
            			    	isUnion=true;
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop5;
            	    }
            	} while (true);
            	
            	loop5:
            		;	// Stops C# compiler whinging that label 'loop5' has no statements

            	// OQL.g:123:74: ( orderBy )?
            	int alt6 = 2;
            	int LA6_0 = input.LA(1);
            	
            	if ( (LA6_0 == ORDER) )
            	{
            	    alt6 = 1;
            	}
            	switch (alt6) 
            	{
            	    case 1 :
            	        // OQL.g:123:74: orderBy
            	        {
            	        	PushFollow(FOLLOW_orderBy_in_selectStatement1013);
            	        	orderBy13 = orderBy();
            	        	followingStackPointer_--;
            	        	
            	        	stream_orderBy.Add(orderBy13.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	
            	// AST REWRITE
            	// elements:          ALL, orderBy, select_1, select_2, select_1, orderBy, UNION
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 124:4: -> {isUnion}? ^( UnionStmt ^( SelectStmt select_1 ) ( ^( TextNode UNION ( ALL )? ) ^( SelectStmt select_2 ) )+ ( orderBy )? )
            	if (isUnion)
            	{
            	    // OQL.g:124:17: ^( UnionStmt ^( SelectStmt select_1 ) ( ^( TextNode UNION ( ALL )? ) ^( SelectStmt select_2 ) )+ ( orderBy )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(UnionStmt, "UnionStmt"), root_1);
            	    
            	    // OQL.g:124:29: ^( SelectStmt select_1 )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(SelectStmt, "SelectStmt"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_select_1.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    if ( !(stream_select_2.HasNext() || stream_UNION.HasNext()) ) {
            	        throw new RewriteEarlyExitException();
            	    }
            	    while ( stream_select_2.HasNext() || stream_UNION.HasNext() )
            	    {
            	        // OQL.g:124:53: ^( TextNode UNION ( ALL )? )
            	        {
            	        Expression root_2 = (Expression)adaptor.GetNilNode();
            	        root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
            	        
            	        adaptor.AddChild(root_2, stream_UNION.Next());
            	        // OQL.g:124:70: ( ALL )?
            	        if ( stream_ALL.HasNext() )
            	        {
            	            adaptor.AddChild(root_2, stream_ALL.Next());
            	        
            	        }
            	        stream_ALL.Reset();
            	        
            	        adaptor.AddChild(root_1, root_2);
            	        }
            	        // OQL.g:124:76: ^( SelectStmt select_2 )
            	        {
            	        Expression root_2 = (Expression)adaptor.GetNilNode();
            	        root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(SelectStmt, "SelectStmt"), root_2);
            	        
            	        adaptor.AddChild(root_2, stream_select_2.Next());
            	        
            	        adaptor.AddChild(root_1, root_2);
            	        }
            	    
            	    }
            	    stream_select_2.Reset();
            	    stream_UNION.Reset();
            	    // OQL.g:124:101: ( orderBy )?
            	    if ( stream_orderBy.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_orderBy.Next());
            	    
            	    }
            	    stream_orderBy.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 125:4: -> {!isUnion}? ^( SelectStmt select_1 ( orderBy )? )
            	if (!isUnion)
            	{
            	    // OQL.g:125:18: ^( SelectStmt select_1 ( orderBy )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(SelectStmt, "SelectStmt"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_select_1.Next());
            	    // OQL.g:125:40: ( orderBy )?
            	    if ( stream_orderBy.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_orderBy.Next());
            	    
            	    }
            	    stream_orderBy.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 126:4: ->
            	{
            	    root_0 = null;
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end selectStatement

    public class select_1_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start select_1
    // OQL.g:129:1: select_1 : select ( from )? ( where )? ( groupBy )? ;
    public select_1_return select_1() // throws RecognitionException [1]
    {   
        select_1_return retval = new select_1_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        select_return select14 = null;

        from_return from15 = null;

        where_return where16 = null;

        groupBy_return groupBy17 = null;
        
        
    
        try 
    	{
            // OQL.g:129:9: ( select ( from )? ( where )? ( groupBy )? )
            // OQL.g:129:11: select ( from )? ( where )? ( groupBy )?
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_select_in_select_11080);
            	select14 = select();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, select14.Tree);
            	// OQL.g:129:18: ( from )?
            	int alt7 = 2;
            	int LA7_0 = input.LA(1);
            	
            	if ( (LA7_0 == FROM) )
            	{
            	    alt7 = 1;
            	}
            	switch (alt7) 
            	{
            	    case 1 :
            	        // OQL.g:129:18: from
            	        {
            	        	PushFollow(FOLLOW_from_in_select_11082);
            	        	from15 = from();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, from15.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	// OQL.g:129:24: ( where )?
            	int alt8 = 2;
            	int LA8_0 = input.LA(1);
            	
            	if ( (LA8_0 == WHERE) )
            	{
            	    alt8 = 1;
            	}
            	switch (alt8) 
            	{
            	    case 1 :
            	        // OQL.g:129:24: where
            	        {
            	        	PushFollow(FOLLOW_where_in_select_11085);
            	        	where16 = where();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, where16.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	// OQL.g:129:31: ( groupBy )?
            	int alt9 = 2;
            	int LA9_0 = input.LA(1);
            	
            	if ( (LA9_0 == GROUP) )
            	{
            	    alt9 = 1;
            	}
            	switch (alt9) 
            	{
            	    case 1 :
            	        // OQL.g:129:31: groupBy
            	        {
            	        	PushFollow(FOLLOW_groupBy_in_select_11088);
            	        	groupBy17 = groupBy();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, groupBy17.Tree);
            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end select_1

    public class select_2_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start select_2
    // OQL.g:130:1: select_2 : select_1 ;
    public select_2_return select_2() // throws RecognitionException [1]
    {   
        select_2_return retval = new select_2_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        select_1_return select_118 = null;
        
        
    
        try 
    	{
            // OQL.g:130:9: ( select_1 )
            // OQL.g:130:11: select_1
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_select_1_in_select_21095);
            	select_118 = select_1();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, select_118.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end select_2

    public class subQuery_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start subQuery
    // OQL.g:131:1: subQuery : LPAREN selectStatement RPAREN -> selectStatement ;
    public subQuery_return subQuery() // throws RecognitionException [1]
    {   
        subQuery_return retval = new subQuery_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken LPAREN19 = null;
        IToken RPAREN21 = null;
        selectStatement_return selectStatement20 = null;
        
        
        Expression LPAREN19_tree=null;
        Expression RPAREN21_tree=null;
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_selectStatement = new RewriteRuleSubtreeStream(adaptor,"rule selectStatement");
        try 
    	{
            // OQL.g:131:9: ( LPAREN selectStatement RPAREN -> selectStatement )
            // OQL.g:131:11: LPAREN selectStatement RPAREN
            {
            	LPAREN19 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_subQuery1102); 
            	stream_LPAREN.Add(LPAREN19);

            	PushFollow(FOLLOW_selectStatement_in_subQuery1104);
            	selectStatement20 = selectStatement();
            	followingStackPointer_--;
            	
            	stream_selectStatement.Add(selectStatement20.Tree);
            	RPAREN21 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_subQuery1106); 
            	stream_RPAREN.Add(RPAREN21);

            	
            	// AST REWRITE
            	// elements:          selectStatement
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 131:41: -> selectStatement
            	{
            	    adaptor.AddChild(root_0, stream_selectStatement.Next());
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end subQuery

    public class updateStatement_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start updateStatement
    // OQL.g:132:1: updateStatement : update ( from )? ( where )? ;
    public updateStatement_return updateStatement() // throws RecognitionException [1]
    {   
        updateStatement_return retval = new updateStatement_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        update_return update22 = null;

        from_return from23 = null;

        where_return where24 = null;
        
        
    
        try 
    	{
            // OQL.g:132:16: ( update ( from )? ( where )? )
            // OQL.g:132:18: update ( from )? ( where )?
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_update_in_updateStatement1117);
            	update22 = update();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, update22.Tree);
            	// OQL.g:132:25: ( from )?
            	int alt10 = 2;
            	int LA10_0 = input.LA(1);
            	
            	if ( (LA10_0 == FROM) )
            	{
            	    alt10 = 1;
            	}
            	switch (alt10) 
            	{
            	    case 1 :
            	        // OQL.g:132:25: from
            	        {
            	        	PushFollow(FOLLOW_from_in_updateStatement1119);
            	        	from23 = from();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, from23.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	// OQL.g:132:31: ( where )?
            	int alt11 = 2;
            	int LA11_0 = input.LA(1);
            	
            	if ( (LA11_0 == WHERE) )
            	{
            	    alt11 = 1;
            	}
            	switch (alt11) 
            	{
            	    case 1 :
            	        // OQL.g:132:31: where
            	        {
            	        	PushFollow(FOLLOW_where_in_updateStatement1122);
            	        	where24 = where();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, where24.Tree);
            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end updateStatement

    public class deleteStatement_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start deleteStatement
    // OQL.g:133:1: deleteStatement : ( delete ( where )? | truncate );
    public deleteStatement_return deleteStatement() // throws RecognitionException [1]
    {   
        deleteStatement_return retval = new deleteStatement_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        delete_return delete25 = null;

        where_return where26 = null;

        truncate_return truncate27 = null;
        
        
    
        try 
    	{
            // OQL.g:133:16: ( delete ( where )? | truncate )
            int alt13 = 2;
            int LA13_0 = input.LA(1);
            
            if ( (LA13_0 == DELETE) )
            {
                alt13 = 1;
            }
            else if ( (LA13_0 == TRUNCATE) )
            {
                alt13 = 2;
            }
            else 
            {
                NoViableAltException nvae_d13s0 =
                    new NoViableAltException("133:1: deleteStatement : ( delete ( where )? | truncate );", 13, 0, input);
            
                throw nvae_d13s0;
            }
            switch (alt13) 
            {
                case 1 :
                    // OQL.g:133:18: delete ( where )?
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_delete_in_deleteStatement1129);
                    	delete25 = delete();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, delete25.Tree);
                    	// OQL.g:133:25: ( where )?
                    	int alt12 = 2;
                    	int LA12_0 = input.LA(1);
                    	
                    	if ( (LA12_0 == WHERE) )
                    	{
                    	    alt12 = 1;
                    	}
                    	switch (alt12) 
                    	{
                    	    case 1 :
                    	        // OQL.g:133:25: where
                    	        {
                    	        	PushFollow(FOLLOW_where_in_deleteStatement1131);
                    	        	where26 = where();
                    	        	followingStackPointer_--;
                    	        	
                    	        	adaptor.AddChild(root_0, where26.Tree);
                    	        
                    	        }
                    	        break;
                    	
                    	}

                    
                    }
                    break;
                case 2 :
                    // OQL.g:133:34: truncate
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_truncate_in_deleteStatement1136);
                    	truncate27 = truncate();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, truncate27.Tree);
                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end deleteStatement

    public class insertStatement_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start insertStatement
    // OQL.g:134:1: insertStatement : insert ( values | selectStatement ) ;
    public insertStatement_return insertStatement() // throws RecognitionException [1]
    {   
        insertStatement_return retval = new insertStatement_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        insert_return insert28 = null;

        values_return values29 = null;

        selectStatement_return selectStatement30 = null;
        
        
    
        try 
    	{
            // OQL.g:134:16: ( insert ( values | selectStatement ) )
            // OQL.g:134:18: insert ( values | selectStatement )
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_insert_in_insertStatement1142);
            	insert28 = insert();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, insert28.Tree);
            	// OQL.g:134:25: ( values | selectStatement )
            	int alt14 = 2;
            	int LA14_0 = input.LA(1);
            	
            	if ( (LA14_0 == VALUES) )
            	{
            	    alt14 = 1;
            	}
            	else if ( (LA14_0 == SELECT) )
            	{
            	    alt14 = 2;
            	}
            	else 
            	{
            	    NoViableAltException nvae_d14s0 =
            	        new NoViableAltException("134:25: ( values | selectStatement )", 14, 0, input);
            	
            	    throw nvae_d14s0;
            	}
            	switch (alt14) 
            	{
            	    case 1 :
            	        // OQL.g:134:26: values
            	        {
            	        	PushFollow(FOLLOW_values_in_insertStatement1145);
            	        	values29 = values();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, values29.Tree);
            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:134:35: selectStatement
            	        {
            	        	PushFollow(FOLLOW_selectStatement_in_insertStatement1149);
            	        	selectStatement30 = selectStatement();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, selectStatement30.Tree);
            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end insertStatement

    public class select_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start select
    // OQL.g:137:1: select : SELECT ( DISTINCT )? columns -> ^( SelectClause SELECT ( DISTINCT )? columns ) ;
    public select_return select() // throws RecognitionException [1]
    {   
        select_return retval = new select_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken SELECT31 = null;
        IToken DISTINCT32 = null;
        columns_return columns33 = null;
        
        
        Expression SELECT31_tree=null;
        Expression DISTINCT32_tree=null;
        RewriteRuleTokenStream stream_SELECT = new RewriteRuleTokenStream(adaptor,"token SELECT");
        RewriteRuleTokenStream stream_DISTINCT = new RewriteRuleTokenStream(adaptor,"token DISTINCT");
        RewriteRuleSubtreeStream stream_columns = new RewriteRuleSubtreeStream(adaptor,"rule columns");
        try 
    	{
            // OQL.g:138:2: ( SELECT ( DISTINCT )? columns -> ^( SelectClause SELECT ( DISTINCT )? columns ) )
            // OQL.g:138:4: SELECT ( DISTINCT )? columns
            {
            	SELECT31 = (IToken)input.LT(1);
            	Match(input,SELECT,FOLLOW_SELECT_in_select1162); 
            	stream_SELECT.Add(SELECT31);

            	// OQL.g:138:11: ( DISTINCT )?
            	int alt15 = 2;
            	int LA15_0 = input.LA(1);
            	
            	if ( (LA15_0 == DISTINCT) )
            	{
            	    alt15 = 1;
            	}
            	switch (alt15) 
            	{
            	    case 1 :
            	        // OQL.g:138:11: DISTINCT
            	        {
            	        	DISTINCT32 = (IToken)input.LT(1);
            	        	Match(input,DISTINCT,FOLLOW_DISTINCT_in_select1164); 
            	        	stream_DISTINCT.Add(DISTINCT32);

            	        
            	        }
            	        break;
            	
            	}

            	PushFollow(FOLLOW_columns_in_select1167);
            	columns33 = columns();
            	followingStackPointer_--;
            	
            	stream_columns.Add(columns33.Tree);
            	
            	// AST REWRITE
            	// elements:          DISTINCT, columns, SELECT
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 139:2: -> ^( SelectClause SELECT ( DISTINCT )? columns )
            	{
            	    // OQL.g:139:5: ^( SelectClause SELECT ( DISTINCT )? columns )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(SelectClause, "SelectClause"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_SELECT.Next());
            	    // OQL.g:139:27: ( DISTINCT )?
            	    if ( stream_DISTINCT.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_DISTINCT.Next());
            	    
            	    }
            	    stream_DISTINCT.Reset();
            	    adaptor.AddChild(root_1, stream_columns.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end select

    public class from_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start from
    // OQL.g:141:1: from : FROM tables ;
    public from_return from() // throws RecognitionException [1]
    {   
        from_return retval = new from_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken FROM34 = null;
        tables_return tables35 = null;
        
        
        Expression FROM34_tree=null;
    
        try 
    	{
            // OQL.g:141:5: ( FROM tables )
            // OQL.g:141:7: FROM tables
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	FROM34 = (IToken)input.LT(1);
            	Match(input,FROM,FOLLOW_FROM_in_from1189); 
            	FROM34_tree = (Expression)adaptor.Create(FROM34);
            	root_0 = (Expression)adaptor.BecomeRoot(FROM34_tree, root_0);

            	PushFollow(FOLLOW_tables_in_from1192);
            	tables35 = tables();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, tables35.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end from

    public class where_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start where
    // OQL.g:142:1: where : WHERE condition -> ^( WhereClause WHERE condition ) ;
    public where_return where() // throws RecognitionException [1]
    {   
        where_return retval = new where_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken WHERE36 = null;
        condition_return condition37 = null;
        
        
        Expression WHERE36_tree=null;
        RewriteRuleTokenStream stream_WHERE = new RewriteRuleTokenStream(adaptor,"token WHERE");
        RewriteRuleSubtreeStream stream_condition = new RewriteRuleSubtreeStream(adaptor,"rule condition");
        try 
    	{
            // OQL.g:142:6: ( WHERE condition -> ^( WhereClause WHERE condition ) )
            // OQL.g:142:8: WHERE condition
            {
            	WHERE36 = (IToken)input.LT(1);
            	Match(input,WHERE,FOLLOW_WHERE_in_where1199); 
            	stream_WHERE.Add(WHERE36);

            	PushFollow(FOLLOW_condition_in_where1201);
            	condition37 = condition();
            	followingStackPointer_--;
            	
            	stream_condition.Add(condition37.Tree);
            	
            	// AST REWRITE
            	// elements:          condition, WHERE
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 142:24: -> ^( WhereClause WHERE condition )
            	{
            	    // OQL.g:142:27: ^( WhereClause WHERE condition )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(WhereClause, "WhereClause"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_WHERE.Next());
            	    adaptor.AddChild(root_1, stream_condition.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end where

    public class orderBy_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start orderBy
    // OQL.g:144:1: orderBy : ORDER BY orderBy_1 ( COMMA orderBy_1 )* -> ^( OrderByClause ORDER BY ( orderBy_1 )+ ) ;
    public orderBy_return orderBy() // throws RecognitionException [1]
    {   
        orderBy_return retval = new orderBy_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken ORDER38 = null;
        IToken BY39 = null;
        IToken COMMA41 = null;
        orderBy_1_return orderBy_140 = null;

        orderBy_1_return orderBy_142 = null;
        
        
        Expression ORDER38_tree=null;
        Expression BY39_tree=null;
        Expression COMMA41_tree=null;
        RewriteRuleTokenStream stream_BY = new RewriteRuleTokenStream(adaptor,"token BY");
        RewriteRuleTokenStream stream_ORDER = new RewriteRuleTokenStream(adaptor,"token ORDER");
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_orderBy_1 = new RewriteRuleSubtreeStream(adaptor,"rule orderBy_1");
        try 
    	{
            // OQL.g:145:2: ( ORDER BY orderBy_1 ( COMMA orderBy_1 )* -> ^( OrderByClause ORDER BY ( orderBy_1 )+ ) )
            // OQL.g:145:4: ORDER BY orderBy_1 ( COMMA orderBy_1 )*
            {
            	ORDER38 = (IToken)input.LT(1);
            	Match(input,ORDER,FOLLOW_ORDER_in_orderBy1221); 
            	stream_ORDER.Add(ORDER38);

            	BY39 = (IToken)input.LT(1);
            	Match(input,BY,FOLLOW_BY_in_orderBy1223); 
            	stream_BY.Add(BY39);

            	PushFollow(FOLLOW_orderBy_1_in_orderBy1225);
            	orderBy_140 = orderBy_1();
            	followingStackPointer_--;
            	
            	stream_orderBy_1.Add(orderBy_140.Tree);
            	// OQL.g:145:23: ( COMMA orderBy_1 )*
            	do 
            	{
            	    int alt16 = 2;
            	    int LA16_0 = input.LA(1);
            	    
            	    if ( (LA16_0 == COMMA) )
            	    {
            	        alt16 = 1;
            	    }
            	    
            	
            	    switch (alt16) 
            		{
            			case 1 :
            			    // OQL.g:145:24: COMMA orderBy_1
            			    {
            			    	COMMA41 = (IToken)input.LT(1);
            			    	Match(input,COMMA,FOLLOW_COMMA_in_orderBy1228); 
            			    	stream_COMMA.Add(COMMA41);

            			    	PushFollow(FOLLOW_orderBy_1_in_orderBy1230);
            			    	orderBy_142 = orderBy_1();
            			    	followingStackPointer_--;
            			    	
            			    	stream_orderBy_1.Add(orderBy_142.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop16;
            	    }
            	} while (true);
            	
            	loop16:
            		;	// Stops C# compiler whinging that label 'loop16' has no statements

            	
            	// AST REWRITE
            	// elements:          ORDER, orderBy_1, BY
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 146:2: -> ^( OrderByClause ORDER BY ( orderBy_1 )+ )
            	{
            	    // OQL.g:146:5: ^( OrderByClause ORDER BY ( orderBy_1 )+ )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(OrderByClause, "OrderByClause"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_ORDER.Next());
            	    adaptor.AddChild(root_1, stream_BY.Next());
            	    if ( !(stream_orderBy_1.HasNext()) ) {
            	        throw new RewriteEarlyExitException();
            	    }
            	    while ( stream_orderBy_1.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_orderBy_1.Next());
            	    
            	    }
            	    stream_orderBy_1.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end orderBy

    public class orderBy_1_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start orderBy_1
    // OQL.g:148:1: orderBy_1 : expressions ( ( ASC ) | ( DESC ) )? -> {orderMethod==0}? ^( OrderByItem expressions ) -> {orderMethod==1}? ^( OrderByItem expressions ASC ) -> {orderMethod==2}? ^( OrderByItem expressions DESC ) ->;
    public orderBy_1_return orderBy_1() // throws RecognitionException [1]
    {   
        orderBy_1_return retval = new orderBy_1_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken ASC44 = null;
        IToken DESC45 = null;
        expressions_return expressions43 = null;
        
        
        Expression ASC44_tree=null;
        Expression DESC45_tree=null;
        RewriteRuleTokenStream stream_ASC = new RewriteRuleTokenStream(adaptor,"token ASC");
        RewriteRuleTokenStream stream_DESC = new RewriteRuleTokenStream(adaptor,"token DESC");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:149:2: ( expressions ( ( ASC ) | ( DESC ) )? -> {orderMethod==0}? ^( OrderByItem expressions ) -> {orderMethod==1}? ^( OrderByItem expressions ASC ) -> {orderMethod==2}? ^( OrderByItem expressions DESC ) ->)
            // OQL.g:149:4: expressions ( ( ASC ) | ( DESC ) )?
            {
            	int orderMethod=0;
            	PushFollow(FOLLOW_expressions_in_orderBy_11259);
            	expressions43 = expressions();
            	followingStackPointer_--;
            	
            	stream_expressions.Add(expressions43.Tree);
            	// OQL.g:149:37: ( ( ASC ) | ( DESC ) )?
            	int alt17 = 3;
            	int LA17_0 = input.LA(1);
            	
            	if ( (LA17_0 == ASC) )
            	{
            	    alt17 = 1;
            	}
            	else if ( (LA17_0 == DESC) )
            	{
            	    alt17 = 2;
            	}
            	switch (alt17) 
            	{
            	    case 1 :
            	        // OQL.g:150:4: ( ASC )
            	        {
            	        	// OQL.g:150:4: ( ASC )
            	        	// OQL.g:150:5: ASC
            	        	{
            	        		ASC44 = (IToken)input.LT(1);
            	        		Match(input,ASC,FOLLOW_ASC_in_orderBy_11267); 
            	        		stream_ASC.Add(ASC44);

            	        		orderMethod=1;
            	        	
            	        	}

            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:151:4: ( DESC )
            	        {
            	        	// OQL.g:151:4: ( DESC )
            	        	// OQL.g:151:5: DESC
            	        	{
            	        		DESC45 = (IToken)input.LT(1);
            	        		Match(input,DESC,FOLLOW_DESC_in_orderBy_11276); 
            	        		stream_DESC.Add(DESC45);

            	        		orderMethod=2;
            	        	
            	        	}

            	        
            	        }
            	        break;
            	
            	}

            	
            	// AST REWRITE
            	// elements:          DESC, ASC, expressions, expressions, expressions
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 152:4: -> {orderMethod==0}? ^( OrderByItem expressions )
            	if (orderMethod==0)
            	{
            	    // OQL.g:152:24: ^( OrderByItem expressions )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(OrderByItem, "OrderByItem"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_expressions.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 153:4: -> {orderMethod==1}? ^( OrderByItem expressions ASC )
            	if (orderMethod==1)
            	{
            	    // OQL.g:153:24: ^( OrderByItem expressions ASC )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(OrderByItem, "OrderByItem"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_expressions.Next());
            	    adaptor.AddChild(root_1, stream_ASC.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 154:4: -> {orderMethod==2}? ^( OrderByItem expressions DESC )
            	if (orderMethod==2)
            	{
            	    // OQL.g:154:24: ^( OrderByItem expressions DESC )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(OrderByItem, "OrderByItem"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_expressions.Next());
            	    adaptor.AddChild(root_1, stream_DESC.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 155:4: ->
            	{
            	    root_0 = null;
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end orderBy_1

    public class groupBy_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start groupBy
    // OQL.g:157:1: groupBy : GROUP BY expressions ( COMMA expressions )* ( having )? -> ^( GroupByClause GROUP BY ( expressions )+ ( having )? ) ;
    public groupBy_return groupBy() // throws RecognitionException [1]
    {   
        groupBy_return retval = new groupBy_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken GROUP46 = null;
        IToken BY47 = null;
        IToken COMMA49 = null;
        expressions_return expressions48 = null;

        expressions_return expressions50 = null;

        having_return having51 = null;
        
        
        Expression GROUP46_tree=null;
        Expression BY47_tree=null;
        Expression COMMA49_tree=null;
        RewriteRuleTokenStream stream_GROUP = new RewriteRuleTokenStream(adaptor,"token GROUP");
        RewriteRuleTokenStream stream_BY = new RewriteRuleTokenStream(adaptor,"token BY");
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_having = new RewriteRuleSubtreeStream(adaptor,"rule having");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:158:2: ( GROUP BY expressions ( COMMA expressions )* ( having )? -> ^( GroupByClause GROUP BY ( expressions )+ ( having )? ) )
            // OQL.g:158:4: GROUP BY expressions ( COMMA expressions )* ( having )?
            {
            	GROUP46 = (IToken)input.LT(1);
            	Match(input,GROUP,FOLLOW_GROUP_in_groupBy1337); 
            	stream_GROUP.Add(GROUP46);

            	BY47 = (IToken)input.LT(1);
            	Match(input,BY,FOLLOW_BY_in_groupBy1339); 
            	stream_BY.Add(BY47);

            	PushFollow(FOLLOW_expressions_in_groupBy1341);
            	expressions48 = expressions();
            	followingStackPointer_--;
            	
            	stream_expressions.Add(expressions48.Tree);
            	// OQL.g:158:25: ( COMMA expressions )*
            	do 
            	{
            	    int alt18 = 2;
            	    int LA18_0 = input.LA(1);
            	    
            	    if ( (LA18_0 == COMMA) )
            	    {
            	        alt18 = 1;
            	    }
            	    
            	
            	    switch (alt18) 
            		{
            			case 1 :
            			    // OQL.g:158:26: COMMA expressions
            			    {
            			    	COMMA49 = (IToken)input.LT(1);
            			    	Match(input,COMMA,FOLLOW_COMMA_in_groupBy1344); 
            			    	stream_COMMA.Add(COMMA49);

            			    	PushFollow(FOLLOW_expressions_in_groupBy1346);
            			    	expressions50 = expressions();
            			    	followingStackPointer_--;
            			    	
            			    	stream_expressions.Add(expressions50.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop18;
            	    }
            	} while (true);
            	
            	loop18:
            		;	// Stops C# compiler whinging that label 'loop18' has no statements

            	// OQL.g:158:46: ( having )?
            	int alt19 = 2;
            	int LA19_0 = input.LA(1);
            	
            	if ( (LA19_0 == HAVING) )
            	{
            	    alt19 = 1;
            	}
            	switch (alt19) 
            	{
            	    case 1 :
            	        // OQL.g:158:46: having
            	        {
            	        	PushFollow(FOLLOW_having_in_groupBy1350);
            	        	having51 = having();
            	        	followingStackPointer_--;
            	        	
            	        	stream_having.Add(having51.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	
            	// AST REWRITE
            	// elements:          expressions, GROUP, BY, having
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 159:2: -> ^( GroupByClause GROUP BY ( expressions )+ ( having )? )
            	{
            	    // OQL.g:159:5: ^( GroupByClause GROUP BY ( expressions )+ ( having )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(GroupByClause, "GroupByClause"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_GROUP.Next());
            	    adaptor.AddChild(root_1, stream_BY.Next());
            	    if ( !(stream_expressions.HasNext()) ) {
            	        throw new RewriteEarlyExitException();
            	    }
            	    while ( stream_expressions.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_expressions.Next());
            	    
            	    }
            	    stream_expressions.Reset();
            	    // OQL.g:159:43: ( having )?
            	    if ( stream_having.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_having.Next());
            	    
            	    }
            	    stream_having.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end groupBy

    public class having_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start having
    // OQL.g:161:1: having : HAVING condition ;
    public having_return having() // throws RecognitionException [1]
    {   
        having_return retval = new having_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken HAVING52 = null;
        condition_return condition53 = null;
        
        
        Expression HAVING52_tree=null;
    
        try 
    	{
            // OQL.g:161:7: ( HAVING condition )
            // OQL.g:161:9: HAVING condition
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	HAVING52 = (IToken)input.LT(1);
            	Match(input,HAVING,FOLLOW_HAVING_in_having1376); 
            	HAVING52_tree = (Expression)adaptor.Create(HAVING52);
            	root_0 = (Expression)adaptor.BecomeRoot(HAVING52_tree, root_0);

            	PushFollow(FOLLOW_condition_in_having1379);
            	condition53 = condition();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, condition53.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end having

    public class update_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start update
    // OQL.g:162:1: update : UPDATE table SET identifier Eq expressions ( update_1 )* -> ^( UpdateClause ^( Table table ) SET ^( Column identifier ) Eq expressions ( update_1 )* ) ;
    public update_return update() // throws RecognitionException [1]
    {   
        update_return retval = new update_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken UPDATE54 = null;
        IToken SET56 = null;
        IToken Eq58 = null;
        table_return table55 = null;

        identifier_return identifier57 = null;

        expressions_return expressions59 = null;

        update_1_return update_160 = null;
        
        
        Expression UPDATE54_tree=null;
        Expression SET56_tree=null;
        Expression Eq58_tree=null;
        RewriteRuleTokenStream stream_UPDATE = new RewriteRuleTokenStream(adaptor,"token UPDATE");
        RewriteRuleTokenStream stream_Eq = new RewriteRuleTokenStream(adaptor,"token Eq");
        RewriteRuleTokenStream stream_SET = new RewriteRuleTokenStream(adaptor,"token SET");
        RewriteRuleSubtreeStream stream_update_1 = new RewriteRuleSubtreeStream(adaptor,"rule update_1");
        RewriteRuleSubtreeStream stream_table = new RewriteRuleSubtreeStream(adaptor,"rule table");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:163:2: ( UPDATE table SET identifier Eq expressions ( update_1 )* -> ^( UpdateClause ^( Table table ) SET ^( Column identifier ) Eq expressions ( update_1 )* ) )
            // OQL.g:163:4: UPDATE table SET identifier Eq expressions ( update_1 )*
            {
            	UPDATE54 = (IToken)input.LT(1);
            	Match(input,UPDATE,FOLLOW_UPDATE_in_update1387); 
            	stream_UPDATE.Add(UPDATE54);

            	PushFollow(FOLLOW_table_in_update1389);
            	table55 = table();
            	followingStackPointer_--;
            	
            	stream_table.Add(table55.Tree);
            	SET56 = (IToken)input.LT(1);
            	Match(input,SET,FOLLOW_SET_in_update1391); 
            	stream_SET.Add(SET56);

            	PushFollow(FOLLOW_identifier_in_update1393);
            	identifier57 = identifier();
            	followingStackPointer_--;
            	
            	stream_identifier.Add(identifier57.Tree);
            	Eq58 = (IToken)input.LT(1);
            	Match(input,Eq,FOLLOW_Eq_in_update1395); 
            	stream_Eq.Add(Eq58);

            	PushFollow(FOLLOW_expressions_in_update1397);
            	expressions59 = expressions();
            	followingStackPointer_--;
            	
            	stream_expressions.Add(expressions59.Tree);
            	// OQL.g:163:47: ( update_1 )*
            	do 
            	{
            	    int alt20 = 2;
            	    int LA20_0 = input.LA(1);
            	    
            	    if ( (LA20_0 == COMMA) )
            	    {
            	        alt20 = 1;
            	    }
            	    
            	
            	    switch (alt20) 
            		{
            			case 1 :
            			    // OQL.g:163:47: update_1
            			    {
            			    	PushFollow(FOLLOW_update_1_in_update1399);
            			    	update_160 = update_1();
            			    	followingStackPointer_--;
            			    	
            			    	stream_update_1.Add(update_160.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop20;
            	    }
            	} while (true);
            	
            	loop20:
            		;	// Stops C# compiler whinging that label 'loop20' has no statements

            	
            	// AST REWRITE
            	// elements:          Eq, identifier, update_1, SET, table, expressions
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 164:2: -> ^( UpdateClause ^( Table table ) SET ^( Column identifier ) Eq expressions ( update_1 )* )
            	{
            	    // OQL.g:164:5: ^( UpdateClause ^( Table table ) SET ^( Column identifier ) Eq expressions ( update_1 )* )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(UpdateClause, "UpdateClause"), root_1);
            	    
            	    // OQL.g:164:20: ^( Table table )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(Table, "Table"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_table.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    adaptor.AddChild(root_1, stream_SET.Next());
            	    // OQL.g:164:39: ^( Column identifier )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(Column, "Column"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_identifier.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    adaptor.AddChild(root_1, stream_Eq.Next());
            	    adaptor.AddChild(root_1, stream_expressions.Next());
            	    // OQL.g:164:75: ( update_1 )*
            	    while ( stream_update_1.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_update_1.Next());
            	    
            	    }
            	    stream_update_1.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end update

    public class update_1_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start update_1
    // OQL.g:166:1: update_1 : COMMA identifier Eq expressions -> COMMA ^( Column identifier ) Eq expressions ;
    public update_1_return update_1() // throws RecognitionException [1]
    {   
        update_1_return retval = new update_1_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken COMMA61 = null;
        IToken Eq63 = null;
        identifier_return identifier62 = null;

        expressions_return expressions64 = null;
        
        
        Expression COMMA61_tree=null;
        Expression Eq63_tree=null;
        RewriteRuleTokenStream stream_Eq = new RewriteRuleTokenStream(adaptor,"token Eq");
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:167:2: ( COMMA identifier Eq expressions -> COMMA ^( Column identifier ) Eq expressions )
            // OQL.g:167:4: COMMA identifier Eq expressions
            {
            	COMMA61 = (IToken)input.LT(1);
            	Match(input,COMMA,FOLLOW_COMMA_in_update_11438); 
            	stream_COMMA.Add(COMMA61);

            	PushFollow(FOLLOW_identifier_in_update_11440);
            	identifier62 = identifier();
            	followingStackPointer_--;
            	
            	stream_identifier.Add(identifier62.Tree);
            	Eq63 = (IToken)input.LT(1);
            	Match(input,Eq,FOLLOW_Eq_in_update_11442); 
            	stream_Eq.Add(Eq63);

            	PushFollow(FOLLOW_expressions_in_update_11444);
            	expressions64 = expressions();
            	followingStackPointer_--;
            	
            	stream_expressions.Add(expressions64.Tree);
            	
            	// AST REWRITE
            	// elements:          expressions, COMMA, Eq, identifier
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 168:2: -> COMMA ^( Column identifier ) Eq expressions
            	{
            	    adaptor.AddChild(root_0, stream_COMMA.Next());
            	    // OQL.g:168:11: ^( Column identifier )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Column, "Column"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_identifier.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	    adaptor.AddChild(root_0, stream_Eq.Next());
            	    adaptor.AddChild(root_0, stream_expressions.Next());
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end update_1

    public class delete_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start delete
    // OQL.g:170:1: delete : DELETE ( FROM )? table -> ^( DELETE ( FROM )? ^( Table table ) ) ;
    public delete_return delete() // throws RecognitionException [1]
    {   
        delete_return retval = new delete_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken DELETE65 = null;
        IToken FROM66 = null;
        table_return table67 = null;
        
        
        Expression DELETE65_tree=null;
        Expression FROM66_tree=null;
        RewriteRuleTokenStream stream_DELETE = new RewriteRuleTokenStream(adaptor,"token DELETE");
        RewriteRuleTokenStream stream_FROM = new RewriteRuleTokenStream(adaptor,"token FROM");
        RewriteRuleSubtreeStream stream_table = new RewriteRuleSubtreeStream(adaptor,"rule table");
        try 
    	{
            // OQL.g:170:7: ( DELETE ( FROM )? table -> ^( DELETE ( FROM )? ^( Table table ) ) )
            // OQL.g:170:9: DELETE ( FROM )? table
            {
            	DELETE65 = (IToken)input.LT(1);
            	Match(input,DELETE,FOLLOW_DELETE_in_delete1467); 
            	stream_DELETE.Add(DELETE65);

            	// OQL.g:170:16: ( FROM )?
            	int alt21 = 2;
            	int LA21_0 = input.LA(1);
            	
            	if ( (LA21_0 == FROM) )
            	{
            	    alt21 = 1;
            	}
            	switch (alt21) 
            	{
            	    case 1 :
            	        // OQL.g:170:16: FROM
            	        {
            	        	FROM66 = (IToken)input.LT(1);
            	        	Match(input,FROM,FOLLOW_FROM_in_delete1469); 
            	        	stream_FROM.Add(FROM66);

            	        
            	        }
            	        break;
            	
            	}

            	PushFollow(FOLLOW_table_in_delete1472);
            	table67 = table();
            	followingStackPointer_--;
            	
            	stream_table.Add(table67.Tree);
            	
            	// AST REWRITE
            	// elements:          DELETE, table, FROM
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 170:28: -> ^( DELETE ( FROM )? ^( Table table ) )
            	{
            	    // OQL.g:170:31: ^( DELETE ( FROM )? ^( Table table ) )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(stream_DELETE.Next(), root_1);
            	    
            	    // OQL.g:170:40: ( FROM )?
            	    if ( stream_FROM.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_FROM.Next());
            	    
            	    }
            	    stream_FROM.Reset();
            	    // OQL.g:170:46: ^( Table table )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(Table, "Table"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_table.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end delete

    public class truncate_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start truncate
    // OQL.g:171:1: truncate : TRUNCATE table -> ^( TRUNCATE ^( Table table ) ) ;
    public truncate_return truncate() // throws RecognitionException [1]
    {   
        truncate_return retval = new truncate_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken TRUNCATE68 = null;
        table_return table69 = null;
        
        
        Expression TRUNCATE68_tree=null;
        RewriteRuleTokenStream stream_TRUNCATE = new RewriteRuleTokenStream(adaptor,"token TRUNCATE");
        RewriteRuleSubtreeStream stream_table = new RewriteRuleSubtreeStream(adaptor,"rule table");
        try 
    	{
            // OQL.g:171:9: ( TRUNCATE table -> ^( TRUNCATE ^( Table table ) ) )
            // OQL.g:171:11: TRUNCATE table
            {
            	TRUNCATE68 = (IToken)input.LT(1);
            	Match(input,TRUNCATE,FOLLOW_TRUNCATE_in_truncate1495); 
            	stream_TRUNCATE.Add(TRUNCATE68);

            	PushFollow(FOLLOW_table_in_truncate1497);
            	table69 = table();
            	followingStackPointer_--;
            	
            	stream_table.Add(table69.Tree);
            	
            	// AST REWRITE
            	// elements:          TRUNCATE, table
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 171:26: -> ^( TRUNCATE ^( Table table ) )
            	{
            	    // OQL.g:171:29: ^( TRUNCATE ^( Table table ) )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(stream_TRUNCATE.Next(), root_1);
            	    
            	    // OQL.g:171:40: ^( Table table )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(Table, "Table"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_table.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end truncate

    public class insert_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start insert
    // OQL.g:172:1: insert : INSERT INTO table LPAREN ( identifier ( COMMA identifier )* )? RPAREN ;
    public insert_return insert() // throws RecognitionException [1]
    {   
        insert_return retval = new insert_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken INSERT70 = null;
        IToken INTO71 = null;
        IToken LPAREN73 = null;
        IToken COMMA75 = null;
        IToken RPAREN77 = null;
        table_return table72 = null;

        identifier_return identifier74 = null;

        identifier_return identifier76 = null;
        
        
        Expression INSERT70_tree=null;
        Expression INTO71_tree=null;
        Expression LPAREN73_tree=null;
        Expression COMMA75_tree=null;
        Expression RPAREN77_tree=null;
    
        try 
    	{
            // OQL.g:173:2: ( INSERT INTO table LPAREN ( identifier ( COMMA identifier )* )? RPAREN )
            // OQL.g:173:4: INSERT INTO table LPAREN ( identifier ( COMMA identifier )* )? RPAREN
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	INSERT70 = (IToken)input.LT(1);
            	Match(input,INSERT,FOLLOW_INSERT_in_insert1517); 
            	INSERT70_tree = (Expression)adaptor.Create(INSERT70);
            	adaptor.AddChild(root_0, INSERT70_tree);

            	INTO71 = (IToken)input.LT(1);
            	Match(input,INTO,FOLLOW_INTO_in_insert1519); 
            	INTO71_tree = (Expression)adaptor.Create(INTO71);
            	adaptor.AddChild(root_0, INTO71_tree);

            	PushFollow(FOLLOW_table_in_insert1521);
            	table72 = table();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, table72.Tree);
            	LPAREN73 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_insert1523); 
            	LPAREN73_tree = (Expression)adaptor.Create(LPAREN73);
            	adaptor.AddChild(root_0, LPAREN73_tree);

            	// OQL.g:173:29: ( identifier ( COMMA identifier )* )?
            	int alt23 = 2;
            	int LA23_0 = input.LA(1);
            	
            	if ( ((LA23_0 >= QuotedIdentifier && LA23_0 <= NonQuotedIdentifier)) )
            	{
            	    alt23 = 1;
            	}
            	switch (alt23) 
            	{
            	    case 1 :
            	        // OQL.g:173:30: identifier ( COMMA identifier )*
            	        {
            	        	PushFollow(FOLLOW_identifier_in_insert1526);
            	        	identifier74 = identifier();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, identifier74.Tree);
            	        	// OQL.g:173:41: ( COMMA identifier )*
            	        	do 
            	        	{
            	        	    int alt22 = 2;
            	        	    int LA22_0 = input.LA(1);
            	        	    
            	        	    if ( (LA22_0 == COMMA) )
            	        	    {
            	        	        alt22 = 1;
            	        	    }
            	        	    
            	        	
            	        	    switch (alt22) 
            	        		{
            	        			case 1 :
            	        			    // OQL.g:173:42: COMMA identifier
            	        			    {
            	        			    	COMMA75 = (IToken)input.LT(1);
            	        			    	Match(input,COMMA,FOLLOW_COMMA_in_insert1529); 
            	        			    	COMMA75_tree = (Expression)adaptor.Create(COMMA75);
            	        			    	adaptor.AddChild(root_0, COMMA75_tree);

            	        			    	PushFollow(FOLLOW_identifier_in_insert1531);
            	        			    	identifier76 = identifier();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, identifier76.Tree);
            	        			    
            	        			    }
            	        			    break;
            	        	
            	        			default:
            	        			    goto loop22;
            	        	    }
            	        	} while (true);
            	        	
            	        	loop22:
            	        		;	// Stops C# compiler whinging that label 'loop22' has no statements

            	        
            	        }
            	        break;
            	
            	}

            	RPAREN77 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_insert1537); 
            	RPAREN77_tree = (Expression)adaptor.Create(RPAREN77);
            	adaptor.AddChild(root_0, RPAREN77_tree);

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end insert

    public class values_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start values
    // OQL.g:174:1: values : VALUES LPAREN ( expressions ( COMMA expressions )* )? RPAREN ;
    public values_return values() // throws RecognitionException [1]
    {   
        values_return retval = new values_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken VALUES78 = null;
        IToken LPAREN79 = null;
        IToken COMMA81 = null;
        IToken RPAREN83 = null;
        expressions_return expressions80 = null;

        expressions_return expressions82 = null;
        
        
        Expression VALUES78_tree=null;
        Expression LPAREN79_tree=null;
        Expression COMMA81_tree=null;
        Expression RPAREN83_tree=null;
    
        try 
    	{
            // OQL.g:174:7: ( VALUES LPAREN ( expressions ( COMMA expressions )* )? RPAREN )
            // OQL.g:174:9: VALUES LPAREN ( expressions ( COMMA expressions )* )? RPAREN
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	VALUES78 = (IToken)input.LT(1);
            	Match(input,VALUES,FOLLOW_VALUES_in_values1543); 
            	VALUES78_tree = (Expression)adaptor.Create(VALUES78);
            	adaptor.AddChild(root_0, VALUES78_tree);

            	LPAREN79 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_values1545); 
            	LPAREN79_tree = (Expression)adaptor.Create(LPAREN79);
            	adaptor.AddChild(root_0, LPAREN79_tree);

            	// OQL.g:174:23: ( expressions ( COMMA expressions )* )?
            	int alt25 = 2;
            	int LA25_0 = input.LA(1);
            	
            	if ( (LA25_0 == MINUS || LA25_0 == LPAREN || LA25_0 == CASE || LA25_0 == NULL || (LA25_0 >= SUM && LA25_0 <= LEN) || (LA25_0 >= QuotedIdentifier && LA25_0 <= UserVariable)) )
            	{
            	    alt25 = 1;
            	}
            	switch (alt25) 
            	{
            	    case 1 :
            	        // OQL.g:174:24: expressions ( COMMA expressions )*
            	        {
            	        	PushFollow(FOLLOW_expressions_in_values1548);
            	        	expressions80 = expressions();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, expressions80.Tree);
            	        	// OQL.g:174:36: ( COMMA expressions )*
            	        	do 
            	        	{
            	        	    int alt24 = 2;
            	        	    int LA24_0 = input.LA(1);
            	        	    
            	        	    if ( (LA24_0 == COMMA) )
            	        	    {
            	        	        alt24 = 1;
            	        	    }
            	        	    
            	        	
            	        	    switch (alt24) 
            	        		{
            	        			case 1 :
            	        			    // OQL.g:174:37: COMMA expressions
            	        			    {
            	        			    	COMMA81 = (IToken)input.LT(1);
            	        			    	Match(input,COMMA,FOLLOW_COMMA_in_values1551); 
            	        			    	COMMA81_tree = (Expression)adaptor.Create(COMMA81);
            	        			    	adaptor.AddChild(root_0, COMMA81_tree);

            	        			    	PushFollow(FOLLOW_expressions_in_values1553);
            	        			    	expressions82 = expressions();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, expressions82.Tree);
            	        			    
            	        			    }
            	        			    break;
            	        	
            	        			default:
            	        			    goto loop24;
            	        	    }
            	        	} while (true);
            	        	
            	        	loop24:
            	        		;	// Stops C# compiler whinging that label 'loop24' has no statements

            	        
            	        }
            	        break;
            	
            	}

            	RPAREN83 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_values1559); 
            	RPAREN83_tree = (Expression)adaptor.Create(RPAREN83);
            	adaptor.AddChild(root_0, RPAREN83_tree);

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end values

    public class columns_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start columns
    // OQL.g:175:1: columns : column ( COMMA column )* -> ( column )+ ;
    public columns_return columns() // throws RecognitionException [1]
    {   
        columns_return retval = new columns_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken COMMA85 = null;
        column_return column84 = null;

        column_return column86 = null;
        
        
        Expression COMMA85_tree=null;
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_column = new RewriteRuleSubtreeStream(adaptor,"rule column");
        try 
    	{
            // OQL.g:175:8: ( column ( COMMA column )* -> ( column )+ )
            // OQL.g:175:10: column ( COMMA column )*
            {
            	PushFollow(FOLLOW_column_in_columns1565);
            	column84 = column();
            	followingStackPointer_--;
            	
            	stream_column.Add(column84.Tree);
            	// OQL.g:175:17: ( COMMA column )*
            	do 
            	{
            	    int alt26 = 2;
            	    int LA26_0 = input.LA(1);
            	    
            	    if ( (LA26_0 == COMMA) )
            	    {
            	        alt26 = 1;
            	    }
            	    
            	
            	    switch (alt26) 
            		{
            			case 1 :
            			    // OQL.g:175:19: COMMA column
            			    {
            			    	COMMA85 = (IToken)input.LT(1);
            			    	Match(input,COMMA,FOLLOW_COMMA_in_columns1569); 
            			    	stream_COMMA.Add(COMMA85);

            			    	PushFollow(FOLLOW_column_in_columns1571);
            			    	column86 = column();
            			    	followingStackPointer_--;
            			    	
            			    	stream_column.Add(column86.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop26;
            	    }
            	} while (true);
            	
            	loop26:
            		;	// Stops C# compiler whinging that label 'loop26' has no statements

            	
            	// AST REWRITE
            	// elements:          column
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 175:35: -> ( column )+
            	{
            	    if ( !(stream_column.HasNext()) ) {
            	        throw new RewriteEarlyExitException();
            	    }
            	    while ( stream_column.HasNext() )
            	    {
            	        adaptor.AddChild(root_0, stream_column.Next());
            	    
            	    }
            	    stream_column.Reset();
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end columns

    public class column_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start column
    // OQL.g:176:1: column : ( MUL -> ^( Column MUL ) | identifier DOT MUL -> ^( Column identifier DOT MUL ) | expressions ( columnAlias )? -> ^( Column expressions ( columnAlias )? ) );
    public column_return column() // throws RecognitionException [1]
    {   
        column_return retval = new column_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken MUL87 = null;
        IToken DOT89 = null;
        IToken MUL90 = null;
        identifier_return identifier88 = null;

        expressions_return expressions91 = null;

        columnAlias_return columnAlias92 = null;
        
        
        Expression MUL87_tree=null;
        Expression DOT89_tree=null;
        Expression MUL90_tree=null;
        RewriteRuleTokenStream stream_DOT = new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleTokenStream stream_MUL = new RewriteRuleTokenStream(adaptor,"token MUL");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        RewriteRuleSubtreeStream stream_columnAlias = new RewriteRuleSubtreeStream(adaptor,"rule columnAlias");
        try 
    	{
            // OQL.g:177:2: ( MUL -> ^( Column MUL ) | identifier DOT MUL -> ^( Column identifier DOT MUL ) | expressions ( columnAlias )? -> ^( Column expressions ( columnAlias )? ) )
            int alt28 = 3;
            switch ( input.LA(1) ) 
            {
            case MUL:
            	{
                alt28 = 1;
                }
                break;
            case QuotedIdentifier:
            	{
                int LA28_2 = input.LA(2);
                
                if ( (LA28_2 == EOF || (LA28_2 >= DIV && LA28_2 <= MOD) || (LA28_2 >= LPAREN && LA28_2 <= RPAREN) || (LA28_2 >= COMMA && LA28_2 <= SEMI) || LA28_2 == AS || LA28_2 == DELETE || (LA28_2 >= FROM && LA28_2 <= GROUP) || LA28_2 == INSERT || LA28_2 == ORDER || LA28_2 == SELECT || (LA28_2 >= UNION && LA28_2 <= UPDATE) || (LA28_2 >= WHERE && LA28_2 <= TRUNCATE) || (LA28_2 >= QuotedIdentifier && LA28_2 <= NonQuotedIdentifier)) )
                {
                    alt28 = 3;
                }
                else if ( (LA28_2 == DOT) )
                {
                    alt28 = 2;
                }
                else 
                {
                    NoViableAltException nvae_d28s2 =
                        new NoViableAltException("176:1: column : ( MUL -> ^( Column MUL ) | identifier DOT MUL -> ^( Column identifier DOT MUL ) | expressions ( columnAlias )? -> ^( Column expressions ( columnAlias )? ) );", 28, 2, input);
                
                    throw nvae_d28s2;
                }
                }
                break;
            case NonQuotedIdentifier:
            	{
                int LA28_3 = input.LA(2);
                
                if ( (LA28_3 == EOF || (LA28_3 >= DIV && LA28_3 <= MOD) || (LA28_3 >= LPAREN && LA28_3 <= RPAREN) || (LA28_3 >= COMMA && LA28_3 <= SEMI) || LA28_3 == AS || LA28_3 == DELETE || (LA28_3 >= FROM && LA28_3 <= GROUP) || LA28_3 == INSERT || LA28_3 == ORDER || LA28_3 == SELECT || (LA28_3 >= UNION && LA28_3 <= UPDATE) || (LA28_3 >= WHERE && LA28_3 <= TRUNCATE) || (LA28_3 >= QuotedIdentifier && LA28_3 <= NonQuotedIdentifier)) )
                {
                    alt28 = 3;
                }
                else if ( (LA28_3 == DOT) )
                {
                    alt28 = 2;
                }
                else 
                {
                    NoViableAltException nvae_d28s3 =
                        new NoViableAltException("176:1: column : ( MUL -> ^( Column MUL ) | identifier DOT MUL -> ^( Column identifier DOT MUL ) | expressions ( columnAlias )? -> ^( Column expressions ( columnAlias )? ) );", 28, 3, input);
                
                    throw nvae_d28s3;
                }
                }
                break;
            case MINUS:
            case LPAREN:
            case CASE:
            case NULL:
            case SUM:
            case AVG:
            case MAX:
            case MIN:
            case COUNT:
            case LEN:
            case Integer:
            case StringLiteral:
            case Real:
            case UserVariable:
            	{
                alt28 = 3;
                }
                break;
            	default:
            	    NoViableAltException nvae_d28s0 =
            	        new NoViableAltException("176:1: column : ( MUL -> ^( Column MUL ) | identifier DOT MUL -> ^( Column identifier DOT MUL ) | expressions ( columnAlias )? -> ^( Column expressions ( columnAlias )? ) );", 28, 0, input);
            
            	    throw nvae_d28s0;
            }
            
            switch (alt28) 
            {
                case 1 :
                    // OQL.g:177:4: MUL
                    {
                    	MUL87 = (IToken)input.LT(1);
                    	Match(input,MUL,FOLLOW_MUL_in_column1588); 
                    	stream_MUL.Add(MUL87);

                    	
                    	// AST REWRITE
                    	// elements:          MUL
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 177:8: -> ^( Column MUL )
                    	{
                    	    // OQL.g:177:11: ^( Column MUL )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Column, "Column"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_MUL.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
                case 2 :
                    // OQL.g:178:6: identifier DOT MUL
                    {
                    	PushFollow(FOLLOW_identifier_in_column1604);
                    	identifier88 = identifier();
                    	followingStackPointer_--;
                    	
                    	stream_identifier.Add(identifier88.Tree);
                    	DOT89 = (IToken)input.LT(1);
                    	Match(input,DOT,FOLLOW_DOT_in_column1606); 
                    	stream_DOT.Add(DOT89);

                    	MUL90 = (IToken)input.LT(1);
                    	Match(input,MUL,FOLLOW_MUL_in_column1608); 
                    	stream_MUL.Add(MUL90);

                    	
                    	// AST REWRITE
                    	// elements:          MUL, DOT, identifier
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 178:25: -> ^( Column identifier DOT MUL )
                    	{
                    	    // OQL.g:178:28: ^( Column identifier DOT MUL )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Column, "Column"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_identifier.Next());
                    	    adaptor.AddChild(root_1, stream_DOT.Next());
                    	    adaptor.AddChild(root_1, stream_MUL.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
                case 3 :
                    // OQL.g:179:9: expressions ( columnAlias )?
                    {
                    	PushFollow(FOLLOW_expressions_in_column1631);
                    	expressions91 = expressions();
                    	followingStackPointer_--;
                    	
                    	stream_expressions.Add(expressions91.Tree);
                    	// OQL.g:179:21: ( columnAlias )?
                    	int alt27 = 2;
                    	int LA27_0 = input.LA(1);
                    	
                    	if ( (LA27_0 == AS || (LA27_0 >= QuotedIdentifier && LA27_0 <= NonQuotedIdentifier)) )
                    	{
                    	    alt27 = 1;
                    	}
                    	switch (alt27) 
                    	{
                    	    case 1 :
                    	        // OQL.g:179:21: columnAlias
                    	        {
                    	        	PushFollow(FOLLOW_columnAlias_in_column1633);
                    	        	columnAlias92 = columnAlias();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_columnAlias.Add(columnAlias92.Tree);
                    	        
                    	        }
                    	        break;
                    	
                    	}

                    	
                    	// AST REWRITE
                    	// elements:          columnAlias, expressions
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 179:34: -> ^( Column expressions ( columnAlias )? )
                    	{
                    	    // OQL.g:179:37: ^( Column expressions ( columnAlias )? )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Column, "Column"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	    // OQL.g:179:58: ( columnAlias )?
                    	    if ( stream_columnAlias.HasNext() )
                    	    {
                    	        adaptor.AddChild(root_1, stream_columnAlias.Next());
                    	    
                    	    }
                    	    stream_columnAlias.Reset();
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end column

    public class tables_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start tables
    // OQL.g:181:1: tables : table ( tables_0 )* ;
    public tables_return tables() // throws RecognitionException [1]
    {   
        tables_return retval = new tables_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        table_return table93 = null;

        tables_0_return tables_094 = null;
        
        
    
        try 
    	{
            // OQL.g:181:7: ( table ( tables_0 )* )
            // OQL.g:181:9: table ( tables_0 )*
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_table_in_tables1659);
            	table93 = table();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, table93.Tree);
            	// OQL.g:181:15: ( tables_0 )*
            	do 
            	{
            	    int alt29 = 2;
            	    int LA29_0 = input.LA(1);
            	    
            	    if ( (LA29_0 == COMMA || LA29_0 == CROSS || LA29_0 == INNER || LA29_0 == LEFT || LA29_0 == RIGHT) )
            	    {
            	        alt29 = 1;
            	    }
            	    
            	
            	    switch (alt29) 
            		{
            			case 1 :
            			    // OQL.g:181:15: tables_0
            			    {
            			    	PushFollow(FOLLOW_tables_0_in_tables1661);
            			    	tables_094 = tables_0();
            			    	followingStackPointer_--;
            			    	
            			    	adaptor.AddChild(root_0, tables_094.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop29;
            	    }
            	} while (true);
            	
            	loop29:
            		;	// Stops C# compiler whinging that label 'loop29' has no statements

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end tables

    public class tables_0_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start tables_0
    // OQL.g:182:1: tables_0 : ( COMMA table -> table | join -> join ) ;
    public tables_0_return tables_0() // throws RecognitionException [1]
    {   
        tables_0_return retval = new tables_0_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken COMMA95 = null;
        table_return table96 = null;

        join_return join97 = null;
        
        
        Expression COMMA95_tree=null;
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_table = new RewriteRuleSubtreeStream(adaptor,"rule table");
        RewriteRuleSubtreeStream stream_join = new RewriteRuleSubtreeStream(adaptor,"rule join");
        try 
    	{
            // OQL.g:182:9: ( ( COMMA table -> table | join -> join ) )
            // OQL.g:182:11: ( COMMA table -> table | join -> join )
            {
            	// OQL.g:182:11: ( COMMA table -> table | join -> join )
            	int alt30 = 2;
            	int LA30_0 = input.LA(1);
            	
            	if ( (LA30_0 == COMMA) )
            	{
            	    alt30 = 1;
            	}
            	else if ( (LA30_0 == CROSS || LA30_0 == INNER || LA30_0 == LEFT || LA30_0 == RIGHT) )
            	{
            	    alt30 = 2;
            	}
            	else 
            	{
            	    NoViableAltException nvae_d30s0 =
            	        new NoViableAltException("182:11: ( COMMA table -> table | join -> join )", 30, 0, input);
            	
            	    throw nvae_d30s0;
            	}
            	switch (alt30) 
            	{
            	    case 1 :
            	        // OQL.g:182:12: COMMA table
            	        {
            	        	COMMA95 = (IToken)input.LT(1);
            	        	Match(input,COMMA,FOLLOW_COMMA_in_tables_01669); 
            	        	stream_COMMA.Add(COMMA95);

            	        	PushFollow(FOLLOW_table_in_tables_01671);
            	        	table96 = table();
            	        	followingStackPointer_--;
            	        	
            	        	stream_table.Add(table96.Tree);
            	        	
            	        	// AST REWRITE
            	        	// elements:          table
            	        	// token labels:      
            	        	// rule labels:       retval
            	        	// token list labels: 
            	        	// rule list labels:  
            	        	retval.tree = root_0;
            	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	        	
            	        	root_0 = (Expression)adaptor.GetNilNode();
            	        	// 182:24: -> table
            	        	{
            	        	    adaptor.AddChild(root_0, stream_table.Next());
            	        	
            	        	}
            	        	

            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:182:35: join
            	        {
            	        	PushFollow(FOLLOW_join_in_tables_01679);
            	        	join97 = join();
            	        	followingStackPointer_--;
            	        	
            	        	stream_join.Add(join97.Tree);
            	        	
            	        	// AST REWRITE
            	        	// elements:          join
            	        	// token labels:      
            	        	// rule labels:       retval
            	        	// token list labels: 
            	        	// rule list labels:  
            	        	retval.tree = root_0;
            	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	        	
            	        	root_0 = (Expression)adaptor.GetNilNode();
            	        	// 182:40: -> join
            	        	{
            	        	    adaptor.AddChild(root_0, stream_join.Next());
            	        	
            	        	}
            	        	

            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end tables_0

    public class table_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start table
    // OQL.g:183:1: table : ( subQuery ( tableAlias )? -> ^( Table subQuery ( tableAlias )? ) | identifier ( tableAlias )? -> ^( Table identifier ( tableAlias )? ) );
    public table_return table() // throws RecognitionException [1]
    {   
        table_return retval = new table_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        subQuery_return subQuery98 = null;

        tableAlias_return tableAlias99 = null;

        identifier_return identifier100 = null;

        tableAlias_return tableAlias101 = null;
        
        
        RewriteRuleSubtreeStream stream_subQuery = new RewriteRuleSubtreeStream(adaptor,"rule subQuery");
        RewriteRuleSubtreeStream stream_tableAlias = new RewriteRuleSubtreeStream(adaptor,"rule tableAlias");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try 
    	{
            // OQL.g:184:5: ( subQuery ( tableAlias )? -> ^( Table subQuery ( tableAlias )? ) | identifier ( tableAlias )? -> ^( Table identifier ( tableAlias )? ) )
            int alt33 = 2;
            int LA33_0 = input.LA(1);
            
            if ( (LA33_0 == LPAREN) )
            {
                alt33 = 1;
            }
            else if ( ((LA33_0 >= QuotedIdentifier && LA33_0 <= NonQuotedIdentifier)) )
            {
                alt33 = 2;
            }
            else 
            {
                NoViableAltException nvae_d33s0 =
                    new NoViableAltException("183:1: table : ( subQuery ( tableAlias )? -> ^( Table subQuery ( tableAlias )? ) | identifier ( tableAlias )? -> ^( Table identifier ( tableAlias )? ) );", 33, 0, input);
            
                throw nvae_d33s0;
            }
            switch (alt33) 
            {
                case 1 :
                    // OQL.g:184:7: subQuery ( tableAlias )?
                    {
                    	PushFollow(FOLLOW_subQuery_in_table1696);
                    	subQuery98 = subQuery();
                    	followingStackPointer_--;
                    	
                    	stream_subQuery.Add(subQuery98.Tree);
                    	// OQL.g:184:16: ( tableAlias )?
                    	int alt31 = 2;
                    	int LA31_0 = input.LA(1);
                    	
                    	if ( (LA31_0 == AS || (LA31_0 >= QuotedIdentifier && LA31_0 <= NonQuotedIdentifier)) )
                    	{
                    	    alt31 = 1;
                    	}
                    	switch (alt31) 
                    	{
                    	    case 1 :
                    	        // OQL.g:184:16: tableAlias
                    	        {
                    	        	PushFollow(FOLLOW_tableAlias_in_table1698);
                    	        	tableAlias99 = tableAlias();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_tableAlias.Add(tableAlias99.Tree);
                    	        
                    	        }
                    	        break;
                    	
                    	}

                    	
                    	// AST REWRITE
                    	// elements:          subQuery, tableAlias
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 184:28: -> ^( Table subQuery ( tableAlias )? )
                    	{
                    	    // OQL.g:184:31: ^( Table subQuery ( tableAlias )? )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Table, "Table"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_subQuery.Next());
                    	    // OQL.g:184:48: ( tableAlias )?
                    	    if ( stream_tableAlias.HasNext() )
                    	    {
                    	        adaptor.AddChild(root_1, stream_tableAlias.Next());
                    	    
                    	    }
                    	    stream_tableAlias.Reset();
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
                case 2 :
                    // OQL.g:185:7: identifier ( tableAlias )?
                    {
                    	PushFollow(FOLLOW_identifier_in_table1719);
                    	identifier100 = identifier();
                    	followingStackPointer_--;
                    	
                    	stream_identifier.Add(identifier100.Tree);
                    	// OQL.g:185:18: ( tableAlias )?
                    	int alt32 = 2;
                    	int LA32_0 = input.LA(1);
                    	
                    	if ( (LA32_0 == AS || (LA32_0 >= QuotedIdentifier && LA32_0 <= NonQuotedIdentifier)) )
                    	{
                    	    alt32 = 1;
                    	}
                    	switch (alt32) 
                    	{
                    	    case 1 :
                    	        // OQL.g:185:18: tableAlias
                    	        {
                    	        	PushFollow(FOLLOW_tableAlias_in_table1721);
                    	        	tableAlias101 = tableAlias();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_tableAlias.Add(tableAlias101.Tree);
                    	        
                    	        }
                    	        break;
                    	
                    	}

                    	
                    	// AST REWRITE
                    	// elements:          tableAlias, identifier
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 186:7: -> ^( Table identifier ( tableAlias )? )
                    	{
                    	    // OQL.g:186:10: ^( Table identifier ( tableAlias )? )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Table, "Table"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_identifier.Next());
                    	    // OQL.g:186:29: ( tableAlias )?
                    	    if ( stream_tableAlias.HasNext() )
                    	    {
                    	        adaptor.AddChild(root_1, stream_tableAlias.Next());
                    	    
                    	    }
                    	    stream_tableAlias.Reset();
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end table

    public class join_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start join
    // OQL.g:188:1: join : ( CROSS JOIN table | ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )? ) -> {joinType==1}? ^( JoinedTable CROSS JOIN table ) -> {joinType==2}? ^( JoinedTable INNER JOIN table ( ^( ON condition ) )? ) -> {joinType==3}? ^( JoinedTable LEFT ( OUTER )? JOIN table ( ^( ON condition ) )? ) -> {joinType==4}? ^( JoinedTable RIGHT ( OUTER )? JOIN table ( ^( ON condition ) )? ) ->;
    public join_return join() // throws RecognitionException [1]
    {   
        join_return retval = new join_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken CROSS102 = null;
        IToken JOIN103 = null;
        IToken INNER105 = null;
        IToken LEFT106 = null;
        IToken RIGHT107 = null;
        IToken OUTER108 = null;
        IToken JOIN109 = null;
        IToken ON111 = null;
        table_return table104 = null;

        table_return table110 = null;

        condition_return condition112 = null;
        
        
        Expression CROSS102_tree=null;
        Expression JOIN103_tree=null;
        Expression INNER105_tree=null;
        Expression LEFT106_tree=null;
        Expression RIGHT107_tree=null;
        Expression OUTER108_tree=null;
        Expression JOIN109_tree=null;
        Expression ON111_tree=null;
        RewriteRuleTokenStream stream_OUTER = new RewriteRuleTokenStream(adaptor,"token OUTER");
        RewriteRuleTokenStream stream_ON = new RewriteRuleTokenStream(adaptor,"token ON");
        RewriteRuleTokenStream stream_RIGHT = new RewriteRuleTokenStream(adaptor,"token RIGHT");
        RewriteRuleTokenStream stream_INNER = new RewriteRuleTokenStream(adaptor,"token INNER");
        RewriteRuleTokenStream stream_CROSS = new RewriteRuleTokenStream(adaptor,"token CROSS");
        RewriteRuleTokenStream stream_JOIN = new RewriteRuleTokenStream(adaptor,"token JOIN");
        RewriteRuleTokenStream stream_LEFT = new RewriteRuleTokenStream(adaptor,"token LEFT");
        RewriteRuleSubtreeStream stream_condition = new RewriteRuleSubtreeStream(adaptor,"rule condition");
        RewriteRuleSubtreeStream stream_table = new RewriteRuleSubtreeStream(adaptor,"rule table");
        try 
    	{
            // OQL.g:189:5: ( ( CROSS JOIN table | ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )? ) -> {joinType==1}? ^( JoinedTable CROSS JOIN table ) -> {joinType==2}? ^( JoinedTable INNER JOIN table ( ^( ON condition ) )? ) -> {joinType==3}? ^( JoinedTable LEFT ( OUTER )? JOIN table ( ^( ON condition ) )? ) -> {joinType==4}? ^( JoinedTable RIGHT ( OUTER )? JOIN table ( ^( ON condition ) )? ) ->)
            // OQL.g:189:7: ( CROSS JOIN table | ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )? )
            {
            	int joinType=1;
            	// OQL.g:190:5: ( CROSS JOIN table | ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )? )
            	int alt38 = 2;
            	int LA38_0 = input.LA(1);
            	
            	if ( (LA38_0 == CROSS) )
            	{
            	    alt38 = 1;
            	}
            	else if ( (LA38_0 == INNER || LA38_0 == LEFT || LA38_0 == RIGHT) )
            	{
            	    alt38 = 2;
            	}
            	else 
            	{
            	    NoViableAltException nvae_d38s0 =
            	        new NoViableAltException("190:5: ( CROSS JOIN table | ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )? )", 38, 0, input);
            	
            	    throw nvae_d38s0;
            	}
            	switch (alt38) 
            	{
            	    case 1 :
            	        // OQL.g:190:7: CROSS JOIN table
            	        {
            	        	CROSS102 = (IToken)input.LT(1);
            	        	Match(input,CROSS,FOLLOW_CROSS_in_join1765); 
            	        	stream_CROSS.Add(CROSS102);

            	        	JOIN103 = (IToken)input.LT(1);
            	        	Match(input,JOIN,FOLLOW_JOIN_in_join1767); 
            	        	stream_JOIN.Add(JOIN103);

            	        	PushFollow(FOLLOW_table_in_join1769);
            	        	table104 = table();
            	        	followingStackPointer_--;
            	        	
            	        	stream_table.Add(table104.Tree);
            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:191:7: ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? ) JOIN table ( ON condition )?
            	        {
            	        	// OQL.g:191:7: ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? )
            	        	int alt36 = 2;
            	        	int LA36_0 = input.LA(1);
            	        	
            	        	if ( (LA36_0 == INNER) )
            	        	{
            	        	    alt36 = 1;
            	        	}
            	        	else if ( (LA36_0 == LEFT || LA36_0 == RIGHT) )
            	        	{
            	        	    alt36 = 2;
            	        	}
            	        	else 
            	        	{
            	        	    NoViableAltException nvae_d36s0 =
            	        	        new NoViableAltException("191:7: ( ( INNER ) | ( ( LEFT ) | ( RIGHT ) ) ( OUTER )? )", 36, 0, input);
            	        	
            	        	    throw nvae_d36s0;
            	        	}
            	        	switch (alt36) 
            	        	{
            	        	    case 1 :
            	        	        // OQL.g:191:8: ( INNER )
            	        	        {
            	        	        	// OQL.g:191:8: ( INNER )
            	        	        	// OQL.g:191:9: INNER
            	        	        	{
            	        	        		INNER105 = (IToken)input.LT(1);
            	        	        		Match(input,INNER,FOLLOW_INNER_in_join1779); 
            	        	        		stream_INNER.Add(INNER105);

            	        	        		joinType=2;
            	        	        	
            	        	        	}

            	        	        
            	        	        }
            	        	        break;
            	        	    case 2 :
            	        	        // OQL.g:191:32: ( ( LEFT ) | ( RIGHT ) ) ( OUTER )?
            	        	        {
            	        	        	// OQL.g:191:32: ( ( LEFT ) | ( RIGHT ) )
            	        	        	int alt34 = 2;
            	        	        	int LA34_0 = input.LA(1);
            	        	        	
            	        	        	if ( (LA34_0 == LEFT) )
            	        	        	{
            	        	        	    alt34 = 1;
            	        	        	}
            	        	        	else if ( (LA34_0 == RIGHT) )
            	        	        	{
            	        	        	    alt34 = 2;
            	        	        	}
            	        	        	else 
            	        	        	{
            	        	        	    NoViableAltException nvae_d34s0 =
            	        	        	        new NoViableAltException("191:32: ( ( LEFT ) | ( RIGHT ) )", 34, 0, input);
            	        	        	
            	        	        	    throw nvae_d34s0;
            	        	        	}
            	        	        	switch (alt34) 
            	        	        	{
            	        	        	    case 1 :
            	        	        	        // OQL.g:191:33: ( LEFT )
            	        	        	        {
            	        	        	        	// OQL.g:191:33: ( LEFT )
            	        	        	        	// OQL.g:191:34: LEFT
            	        	        	        	{
            	        	        	        		LEFT106 = (IToken)input.LT(1);
            	        	        	        		Match(input,LEFT,FOLLOW_LEFT_in_join1788); 
            	        	        	        		stream_LEFT.Add(LEFT106);

            	        	        	        		joinType=3;
            	        	        	        	
            	        	        	        	}

            	        	        	        
            	        	        	        }
            	        	        	        break;
            	        	        	    case 2 :
            	        	        	        // OQL.g:191:56: ( RIGHT )
            	        	        	        {
            	        	        	        	// OQL.g:191:56: ( RIGHT )
            	        	        	        	// OQL.g:191:57: RIGHT
            	        	        	        	{
            	        	        	        		RIGHT107 = (IToken)input.LT(1);
            	        	        	        		Match(input,RIGHT,FOLLOW_RIGHT_in_join1796); 
            	        	        	        		stream_RIGHT.Add(RIGHT107);

            	        	        	        		joinType=4;
            	        	        	        	
            	        	        	        	}

            	        	        	        
            	        	        	        }
            	        	        	        break;
            	        	        	
            	        	        	}

            	        	        	// OQL.g:191:79: ( OUTER )?
            	        	        	int alt35 = 2;
            	        	        	int LA35_0 = input.LA(1);
            	        	        	
            	        	        	if ( (LA35_0 == OUTER) )
            	        	        	{
            	        	        	    alt35 = 1;
            	        	        	}
            	        	        	switch (alt35) 
            	        	        	{
            	        	        	    case 1 :
            	        	        	        // OQL.g:191:79: OUTER
            	        	        	        {
            	        	        	        	OUTER108 = (IToken)input.LT(1);
            	        	        	        	Match(input,OUTER,FOLLOW_OUTER_in_join1802); 
            	        	        	        	stream_OUTER.Add(OUTER108);

            	        	        	        
            	        	        	        }
            	        	        	        break;
            	        	        	
            	        	        	}

            	        	        
            	        	        }
            	        	        break;
            	        	
            	        	}

            	        	JOIN109 = (IToken)input.LT(1);
            	        	Match(input,JOIN,FOLLOW_JOIN_in_join1806); 
            	        	stream_JOIN.Add(JOIN109);

            	        	PushFollow(FOLLOW_table_in_join1808);
            	        	table110 = table();
            	        	followingStackPointer_--;
            	        	
            	        	stream_table.Add(table110.Tree);
            	        	// OQL.g:191:98: ( ON condition )?
            	        	int alt37 = 2;
            	        	int LA37_0 = input.LA(1);
            	        	
            	        	if ( (LA37_0 == ON) )
            	        	{
            	        	    alt37 = 1;
            	        	}
            	        	switch (alt37) 
            	        	{
            	        	    case 1 :
            	        	        // OQL.g:191:99: ON condition
            	        	        {
            	        	        	ON111 = (IToken)input.LT(1);
            	        	        	Match(input,ON,FOLLOW_ON_in_join1811); 
            	        	        	stream_ON.Add(ON111);

            	        	        	PushFollow(FOLLOW_condition_in_join1813);
            	        	        	condition112 = condition();
            	        	        	followingStackPointer_--;
            	        	        	
            	        	        	stream_condition.Add(condition112.Tree);
            	        	        
            	        	        }
            	        	        break;
            	        	
            	        	}

            	        
            	        }
            	        break;
            	
            	}

            	
            	// AST REWRITE
            	// elements:          condition, condition, condition, table, OUTER, ON, JOIN, table, JOIN, CROSS, ON, RIGHT, ON, LEFT, INNER, JOIN, OUTER, JOIN, table, table
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 193:7: -> {joinType==1}? ^( JoinedTable CROSS JOIN table )
            	if (joinType==1)
            	{
            	    // OQL.g:193:24: ^( JoinedTable CROSS JOIN table )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(JoinedTable, "JoinedTable"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_CROSS.Next());
            	    adaptor.AddChild(root_1, stream_JOIN.Next());
            	    adaptor.AddChild(root_1, stream_table.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 194:7: -> {joinType==2}? ^( JoinedTable INNER JOIN table ( ^( ON condition ) )? )
            	if (joinType==2)
            	{
            	    // OQL.g:194:24: ^( JoinedTable INNER JOIN table ( ^( ON condition ) )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(JoinedTable, "JoinedTable"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_INNER.Next());
            	    adaptor.AddChild(root_1, stream_JOIN.Next());
            	    adaptor.AddChild(root_1, stream_table.Next());
            	    // OQL.g:194:55: ( ^( ON condition ) )?
            	    if ( stream_condition.HasNext() || stream_ON.HasNext() )
            	    {
            	        // OQL.g:194:55: ^( ON condition )
            	        {
            	        Expression root_2 = (Expression)adaptor.GetNilNode();
            	        root_2 = (Expression)adaptor.BecomeRoot(stream_ON.Next(), root_2);
            	        
            	        adaptor.AddChild(root_2, stream_condition.Next());
            	        
            	        adaptor.AddChild(root_1, root_2);
            	        }
            	    
            	    }
            	    stream_condition.Reset();
            	    stream_ON.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 195:7: -> {joinType==3}? ^( JoinedTable LEFT ( OUTER )? JOIN table ( ^( ON condition ) )? )
            	if (joinType==3)
            	{
            	    // OQL.g:195:24: ^( JoinedTable LEFT ( OUTER )? JOIN table ( ^( ON condition ) )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(JoinedTable, "JoinedTable"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_LEFT.Next());
            	    // OQL.g:195:43: ( OUTER )?
            	    if ( stream_OUTER.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_OUTER.Next());
            	    
            	    }
            	    stream_OUTER.Reset();
            	    adaptor.AddChild(root_1, stream_JOIN.Next());
            	    adaptor.AddChild(root_1, stream_table.Next());
            	    // OQL.g:195:61: ( ^( ON condition ) )?
            	    if ( stream_condition.HasNext() || stream_ON.HasNext() )
            	    {
            	        // OQL.g:195:61: ^( ON condition )
            	        {
            	        Expression root_2 = (Expression)adaptor.GetNilNode();
            	        root_2 = (Expression)adaptor.BecomeRoot(stream_ON.Next(), root_2);
            	        
            	        adaptor.AddChild(root_2, stream_condition.Next());
            	        
            	        adaptor.AddChild(root_1, root_2);
            	        }
            	    
            	    }
            	    stream_condition.Reset();
            	    stream_ON.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 196:7: -> {joinType==4}? ^( JoinedTable RIGHT ( OUTER )? JOIN table ( ^( ON condition ) )? )
            	if (joinType==4)
            	{
            	    // OQL.g:196:24: ^( JoinedTable RIGHT ( OUTER )? JOIN table ( ^( ON condition ) )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(JoinedTable, "JoinedTable"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_RIGHT.Next());
            	    // OQL.g:196:44: ( OUTER )?
            	    if ( stream_OUTER.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_OUTER.Next());
            	    
            	    }
            	    stream_OUTER.Reset();
            	    adaptor.AddChild(root_1, stream_JOIN.Next());
            	    adaptor.AddChild(root_1, stream_table.Next());
            	    // OQL.g:196:62: ( ^( ON condition ) )?
            	    if ( stream_condition.HasNext() || stream_ON.HasNext() )
            	    {
            	        // OQL.g:196:62: ^( ON condition )
            	        {
            	        Expression root_2 = (Expression)adaptor.GetNilNode();
            	        root_2 = (Expression)adaptor.BecomeRoot(stream_ON.Next(), root_2);
            	        
            	        adaptor.AddChild(root_2, stream_condition.Next());
            	        
            	        adaptor.AddChild(root_1, root_2);
            	        }
            	    
            	    }
            	    stream_condition.Reset();
            	    stream_ON.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 197:7: ->
            	{
            	    root_0 = null;
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end join

    public class columnAlias_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start columnAlias
    // OQL.g:201:1: columnAlias : ( AS )? identifier -> ^( Alias ( AS )? identifier ) ;
    public columnAlias_return columnAlias() // throws RecognitionException [1]
    {   
        columnAlias_return retval = new columnAlias_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken AS113 = null;
        identifier_return identifier114 = null;
        
        
        Expression AS113_tree=null;
        RewriteRuleTokenStream stream_AS = new RewriteRuleTokenStream(adaptor,"token AS");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try 
    	{
            // OQL.g:201:12: ( ( AS )? identifier -> ^( Alias ( AS )? identifier ) )
            // OQL.g:201:14: ( AS )? identifier
            {
            	// OQL.g:201:14: ( AS )?
            	int alt39 = 2;
            	int LA39_0 = input.LA(1);
            	
            	if ( (LA39_0 == AS) )
            	{
            	    alt39 = 1;
            	}
            	switch (alt39) 
            	{
            	    case 1 :
            	        // OQL.g:201:14: AS
            	        {
            	        	AS113 = (IToken)input.LT(1);
            	        	Match(input,AS,FOLLOW_AS_in_columnAlias1946); 
            	        	stream_AS.Add(AS113);

            	        
            	        }
            	        break;
            	
            	}

            	PushFollow(FOLLOW_identifier_in_columnAlias1949);
            	identifier114 = identifier();
            	followingStackPointer_--;
            	
            	stream_identifier.Add(identifier114.Tree);
            	
            	// AST REWRITE
            	// elements:          AS, identifier
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 201:29: -> ^( Alias ( AS )? identifier )
            	{
            	    // OQL.g:201:32: ^( Alias ( AS )? identifier )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Alias, "Alias"), root_1);
            	    
            	    // OQL.g:201:40: ( AS )?
            	    if ( stream_AS.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_AS.Next());
            	    
            	    }
            	    stream_AS.Reset();
            	    adaptor.AddChild(root_1, stream_identifier.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end columnAlias

    public class tableAlias_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start tableAlias
    // OQL.g:203:1: tableAlias : ( AS )? identifier -> ^( Alias identifier ) ;
    public tableAlias_return tableAlias() // throws RecognitionException [1]
    {   
        tableAlias_return retval = new tableAlias_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken AS115 = null;
        identifier_return identifier116 = null;
        
        
        Expression AS115_tree=null;
        RewriteRuleTokenStream stream_AS = new RewriteRuleTokenStream(adaptor,"token AS");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try 
    	{
            // OQL.g:203:11: ( ( AS )? identifier -> ^( Alias identifier ) )
            // OQL.g:203:13: ( AS )? identifier
            {
            	// OQL.g:203:13: ( AS )?
            	int alt40 = 2;
            	int LA40_0 = input.LA(1);
            	
            	if ( (LA40_0 == AS) )
            	{
            	    alt40 = 1;
            	}
            	switch (alt40) 
            	{
            	    case 1 :
            	        // OQL.g:203:13: AS
            	        {
            	        	AS115 = (IToken)input.LT(1);
            	        	Match(input,AS,FOLLOW_AS_in_tableAlias1967); 
            	        	stream_AS.Add(AS115);

            	        
            	        }
            	        break;
            	
            	}

            	PushFollow(FOLLOW_identifier_in_tableAlias1970);
            	identifier116 = identifier();
            	followingStackPointer_--;
            	
            	stream_identifier.Add(identifier116.Tree);
            	
            	// AST REWRITE
            	// elements:          identifier
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 203:28: -> ^( Alias identifier )
            	{
            	    // OQL.g:203:31: ^( Alias identifier )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Alias, "Alias"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_identifier.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end tableAlias

    public class condition_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start condition
    // OQL.g:204:1: condition : subCondition ( ( AND | OR ) subCondition )* ;
    public condition_return condition() // throws RecognitionException [1]
    {   
        condition_return retval = new condition_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken AND118 = null;
        IToken OR119 = null;
        subCondition_return subCondition117 = null;

        subCondition_return subCondition120 = null;
        
        
        Expression AND118_tree=null;
        Expression OR119_tree=null;
    
        try 
    	{
            // OQL.g:204:10: ( subCondition ( ( AND | OR ) subCondition )* )
            // OQL.g:204:12: subCondition ( ( AND | OR ) subCondition )*
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_subCondition_in_condition1984);
            	subCondition117 = subCondition();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, subCondition117.Tree);
            	// OQL.g:204:25: ( ( AND | OR ) subCondition )*
            	do 
            	{
            	    int alt42 = 2;
            	    int LA42_0 = input.LA(1);
            	    
            	    if ( (LA42_0 == AND || LA42_0 == OR) )
            	    {
            	        alt42 = 1;
            	    }
            	    
            	
            	    switch (alt42) 
            		{
            			case 1 :
            			    // OQL.g:204:26: ( AND | OR ) subCondition
            			    {
            			    	// OQL.g:204:26: ( AND | OR )
            			    	int alt41 = 2;
            			    	int LA41_0 = input.LA(1);
            			    	
            			    	if ( (LA41_0 == AND) )
            			    	{
            			    	    alt41 = 1;
            			    	}
            			    	else if ( (LA41_0 == OR) )
            			    	{
            			    	    alt41 = 2;
            			    	}
            			    	else 
            			    	{
            			    	    NoViableAltException nvae_d41s0 =
            			    	        new NoViableAltException("204:26: ( AND | OR )", 41, 0, input);
            			    	
            			    	    throw nvae_d41s0;
            			    	}
            			    	switch (alt41) 
            			    	{
            			    	    case 1 :
            			    	        // OQL.g:204:27: AND
            			    	        {
            			    	        	AND118 = (IToken)input.LT(1);
            			    	        	Match(input,AND,FOLLOW_AND_in_condition1988); 
            			    	        	AND118_tree = (Expression)adaptor.Create(AND118);
            			    	        	root_0 = (Expression)adaptor.BecomeRoot(AND118_tree, root_0);

            			    	        
            			    	        }
            			    	        break;
            			    	    case 2 :
            			    	        // OQL.g:204:35: OR
            			    	        {
            			    	        	OR119 = (IToken)input.LT(1);
            			    	        	Match(input,OR,FOLLOW_OR_in_condition1994); 
            			    	        	OR119_tree = (Expression)adaptor.Create(OR119);
            			    	        	root_0 = (Expression)adaptor.BecomeRoot(OR119_tree, root_0);

            			    	        
            			    	        }
            			    	        break;
            			    	
            			    	}

            			    	PushFollow(FOLLOW_subCondition_in_condition1999);
            			    	subCondition120 = subCondition();
            			    	followingStackPointer_--;
            			    	
            			    	adaptor.AddChild(root_0, subCondition120.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop42;
            	    }
            	} while (true);
            	
            	loop42:
            		;	// Stops C# compiler whinging that label 'loop42' has no statements

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end condition

    public class subCondition_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start subCondition
    // OQL.g:205:1: subCondition : ( NOT )? ( LPAREN condition RPAREN | e= predicate ) -> {prefixNot && isGroup}? ^( NOT ^( Group condition ) ) -> {prefixNot && !isGroup}? ^( NOT $e) -> {!prefixNot && isGroup}? ^( Group condition ) -> {!prefixNot && !isGroup}? $e ->;
    public subCondition_return subCondition() // throws RecognitionException [1]
    {   
        subCondition_return retval = new subCondition_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken NOT121 = null;
        IToken LPAREN122 = null;
        IToken RPAREN124 = null;
        predicate_return e = null;

        condition_return condition123 = null;
        
        
        Expression NOT121_tree=null;
        Expression LPAREN122_tree=null;
        Expression RPAREN124_tree=null;
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_NOT = new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_condition = new RewriteRuleSubtreeStream(adaptor,"rule condition");
        RewriteRuleSubtreeStream stream_predicate = new RewriteRuleSubtreeStream(adaptor,"rule predicate");
        try 
    	{
            // OQL.g:205:13: ( ( NOT )? ( LPAREN condition RPAREN | e= predicate ) -> {prefixNot && isGroup}? ^( NOT ^( Group condition ) ) -> {prefixNot && !isGroup}? ^( NOT $e) -> {!prefixNot && isGroup}? ^( Group condition ) -> {!prefixNot && !isGroup}? $e ->)
            // OQL.g:206:2: ( NOT )? ( LPAREN condition RPAREN | e= predicate )
            {
            	bool prefixNot=false;bool isGroup=false;
            	// OQL.g:206:44: ( NOT )?
            	int alt43 = 2;
            	int LA43_0 = input.LA(1);
            	
            	if ( (LA43_0 == NOT) )
            	{
            	    alt43 = 1;
            	}
            	switch (alt43) 
            	{
            	    case 1 :
            	        // OQL.g:206:45: NOT
            	        {
            	        	NOT121 = (IToken)input.LT(1);
            	        	Match(input,NOT,FOLLOW_NOT_in_subCondition2011); 
            	        	stream_NOT.Add(NOT121);

            	        	prefixNot=true;
            	        
            	        }
            	        break;
            	
            	}

            	// OQL.g:206:69: ( LPAREN condition RPAREN | e= predicate )
            	int alt44 = 2;
            	int LA44_0 = input.LA(1);
            	
            	if ( (LA44_0 == LPAREN) )
            	{
            	    int LA44_1 = input.LA(2);
            	    
            	    if ( (LA44_1 == MINUS || LA44_1 == LPAREN || LA44_1 == CASE || LA44_1 == EXISTS || (LA44_1 >= NOT && LA44_1 <= NULL) || (LA44_1 >= SUM && LA44_1 <= LEN) || (LA44_1 >= QuotedIdentifier && LA44_1 <= UserVariable)) )
            	    {
            	        alt44 = 1;
            	    }
            	    else if ( (LA44_1 == SELECT) )
            	    {
            	        alt44 = 2;
            	    }
            	    else 
            	    {
            	        NoViableAltException nvae_d44s1 =
            	            new NoViableAltException("206:69: ( LPAREN condition RPAREN | e= predicate )", 44, 1, input);
            	    
            	        throw nvae_d44s1;
            	    }
            	}
            	else if ( (LA44_0 == MINUS || LA44_0 == CASE || LA44_0 == EXISTS || LA44_0 == NULL || (LA44_0 >= SUM && LA44_0 <= LEN) || (LA44_0 >= QuotedIdentifier && LA44_0 <= UserVariable)) )
            	{
            	    alt44 = 2;
            	}
            	else 
            	{
            	    NoViableAltException nvae_d44s0 =
            	        new NoViableAltException("206:69: ( LPAREN condition RPAREN | e= predicate )", 44, 0, input);
            	
            	    throw nvae_d44s0;
            	}
            	switch (alt44) 
            	{
            	    case 1 :
            	        // OQL.g:207:4: LPAREN condition RPAREN
            	        {
            	        	LPAREN122 = (IToken)input.LT(1);
            	        	Match(input,LPAREN,FOLLOW_LPAREN_in_subCondition2022); 
            	        	stream_LPAREN.Add(LPAREN122);

            	        	PushFollow(FOLLOW_condition_in_subCondition2024);
            	        	condition123 = condition();
            	        	followingStackPointer_--;
            	        	
            	        	stream_condition.Add(condition123.Tree);
            	        	RPAREN124 = (IToken)input.LT(1);
            	        	Match(input,RPAREN,FOLLOW_RPAREN_in_subCondition2026); 
            	        	stream_RPAREN.Add(RPAREN124);

            	        	isGroup=true;
            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:208:6: e= predicate
            	        {
            	        	PushFollow(FOLLOW_predicate_in_subCondition2037);
            	        	e = predicate();
            	        	followingStackPointer_--;
            	        	
            	        	stream_predicate.Add(e.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	
            	// AST REWRITE
            	// elements:          e, NOT, NOT, e, condition, condition
            	// token labels:      
            	// rule labels:       retval, e
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	RewriteRuleSubtreeStream stream_e = new RewriteRuleSubtreeStream(adaptor, "token e", (e!=null ? e.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 210:2: -> {prefixNot && isGroup}? ^( NOT ^( Group condition ) )
            	if (prefixNot && isGroup)
            	{
            	    // OQL.g:210:29: ^( NOT ^( Group condition ) )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(stream_NOT.Next(), root_1);
            	    
            	    // OQL.g:210:35: ^( Group condition )
            	    {
            	    Expression root_2 = (Expression)adaptor.GetNilNode();
            	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(Group, "Group"), root_2);
            	    
            	    adaptor.AddChild(root_2, stream_condition.Next());
            	    
            	    adaptor.AddChild(root_1, root_2);
            	    }
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 211:2: -> {prefixNot && !isGroup}? ^( NOT $e)
            	if (prefixNot && !isGroup)
            	{
            	    // OQL.g:211:30: ^( NOT $e)
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(stream_NOT.Next(), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_e.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 212:2: -> {!prefixNot && isGroup}? ^( Group condition )
            	if (!prefixNot && isGroup)
            	{
            	    // OQL.g:212:30: ^( Group condition )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Group, "Group"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_condition.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	else // 213:2: -> {!prefixNot && !isGroup}? $e
            	if (!prefixNot && !isGroup)
            	{
            	    adaptor.AddChild(root_0, stream_e.Next());
            	
            	}
            	else // 214:2: ->
            	{
            	    root_0 = null;
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end subCondition

    public class predicate_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start predicate
    // OQL.g:216:1: predicate : ( expressions ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) ) | EXISTS subQuery -> ^( EXISTS subQuery ) );
    public predicate_return predicate() // throws RecognitionException [1]
    {   
        predicate_return retval = new predicate_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken IS128 = null;
        IToken NOT129 = null;
        IToken NULL130 = null;
        IToken NOT131 = null;
        IToken IN132 = null;
        IToken LPAREN133 = null;
        IToken COMMA135 = null;
        IToken RPAREN137 = null;
        IToken NOT138 = null;
        IToken IN139 = null;
        IToken NOT141 = null;
        IToken BETWEEN142 = null;
        IToken AND144 = null;
        IToken EXISTS146 = null;
        expressions_return expressions125 = null;

        comparisonOperator_return comparisonOperator126 = null;

        expressions_return expressions127 = null;

        expressions_0_return expressions_0134 = null;

        expressions_1_return expressions_1136 = null;

        subQuery_return subQuery140 = null;

        expressions_return expressions143 = null;

        expressions_return expressions145 = null;

        subQuery_return subQuery147 = null;
        
        
        Expression IS128_tree=null;
        Expression NOT129_tree=null;
        Expression NULL130_tree=null;
        Expression NOT131_tree=null;
        Expression IN132_tree=null;
        Expression LPAREN133_tree=null;
        Expression COMMA135_tree=null;
        Expression RPAREN137_tree=null;
        Expression NOT138_tree=null;
        Expression IN139_tree=null;
        Expression NOT141_tree=null;
        Expression BETWEEN142_tree=null;
        Expression AND144_tree=null;
        Expression EXISTS146_tree=null;
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_IN = new RewriteRuleTokenStream(adaptor,"token IN");
        RewriteRuleTokenStream stream_EXISTS = new RewriteRuleTokenStream(adaptor,"token EXISTS");
        RewriteRuleTokenStream stream_NOT = new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_AND = new RewriteRuleTokenStream(adaptor,"token AND");
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_IS = new RewriteRuleTokenStream(adaptor,"token IS");
        RewriteRuleTokenStream stream_BETWEEN = new RewriteRuleTokenStream(adaptor,"token BETWEEN");
        RewriteRuleTokenStream stream_NULL = new RewriteRuleTokenStream(adaptor,"token NULL");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_expressions_1 = new RewriteRuleSubtreeStream(adaptor,"rule expressions_1");
        RewriteRuleSubtreeStream stream_expressions_0 = new RewriteRuleSubtreeStream(adaptor,"rule expressions_0");
        RewriteRuleSubtreeStream stream_subQuery = new RewriteRuleSubtreeStream(adaptor,"rule subQuery");
        RewriteRuleSubtreeStream stream_comparisonOperator = new RewriteRuleSubtreeStream(adaptor,"rule comparisonOperator");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:217:2: ( expressions ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) ) | EXISTS subQuery -> ^( EXISTS subQuery ) )
            int alt51 = 2;
            int LA51_0 = input.LA(1);
            
            if ( (LA51_0 == MINUS || LA51_0 == LPAREN || LA51_0 == CASE || LA51_0 == NULL || (LA51_0 >= SUM && LA51_0 <= LEN) || (LA51_0 >= QuotedIdentifier && LA51_0 <= UserVariable)) )
            {
                alt51 = 1;
            }
            else if ( (LA51_0 == EXISTS) )
            {
                alt51 = 2;
            }
            else 
            {
                NoViableAltException nvae_d51s0 =
                    new NoViableAltException("216:1: predicate : ( expressions ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) ) | EXISTS subQuery -> ^( EXISTS subQuery ) );", 51, 0, input);
            
                throw nvae_d51s0;
            }
            switch (alt51) 
            {
                case 1 :
                    // OQL.g:217:4: expressions ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )
                    {
                    	PushFollow(FOLLOW_expressions_in_predicate2099);
                    	expressions125 = expressions();
                    	followingStackPointer_--;
                    	
                    	stream_expressions.Add(expressions125.Tree);
                    	// OQL.g:217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )
                    	int alt50 = 5;
                    	switch ( input.LA(1) ) 
                    	{
                    	case Eq:
                    	case Neq1:
                    	case Neq2:
                    	case Le1:
                    	case Le2:
                    	case Lt:
                    	case Ge1:
                    	case Ge2:
                    	case Gt:
                    	case LIKE:
                    		{
                    	    alt50 = 1;
                    	    }
                    	    break;
                    	case IS:
                    		{
                    	    alt50 = 2;
                    	    }
                    	    break;
                    	case NOT:
                    		{
                    	    int LA50_3 = input.LA(2);
                    	    
                    	    if ( (LA50_3 == IN) )
                    	    {
                    	        int LA50_4 = input.LA(3);
                    	        
                    	        if ( (LA50_4 == LPAREN) )
                    	        {
                    	            int LA50_6 = input.LA(4);
                    	            
                    	            if ( (LA50_6 == SELECT) )
                    	            {
                    	                alt50 = 4;
                    	            }
                    	            else if ( (LA50_6 == MINUS || LA50_6 == LPAREN || LA50_6 == CASE || LA50_6 == NULL || (LA50_6 >= SUM && LA50_6 <= LEN) || (LA50_6 >= QuotedIdentifier && LA50_6 <= UserVariable)) )
                    	            {
                    	                alt50 = 3;
                    	            }
                    	            else 
                    	            {
                    	                NoViableAltException nvae_d50s6 =
                    	                    new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 6, input);
                    	            
                    	                throw nvae_d50s6;
                    	            }
                    	        }
                    	        else 
                    	        {
                    	            NoViableAltException nvae_d50s4 =
                    	                new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 4, input);
                    	        
                    	            throw nvae_d50s4;
                    	        }
                    	    }
                    	    else if ( (LA50_3 == BETWEEN) )
                    	    {
                    	        alt50 = 5;
                    	    }
                    	    else 
                    	    {
                    	        NoViableAltException nvae_d50s3 =
                    	            new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 3, input);
                    	    
                    	        throw nvae_d50s3;
                    	    }
                    	    }
                    	    break;
                    	case IN:
                    		{
                    	    int LA50_4 = input.LA(2);
                    	    
                    	    if ( (LA50_4 == LPAREN) )
                    	    {
                    	        int LA50_6 = input.LA(3);
                    	        
                    	        if ( (LA50_6 == SELECT) )
                    	        {
                    	            alt50 = 4;
                    	        }
                    	        else if ( (LA50_6 == MINUS || LA50_6 == LPAREN || LA50_6 == CASE || LA50_6 == NULL || (LA50_6 >= SUM && LA50_6 <= LEN) || (LA50_6 >= QuotedIdentifier && LA50_6 <= UserVariable)) )
                    	        {
                    	            alt50 = 3;
                    	        }
                    	        else 
                    	        {
                    	            NoViableAltException nvae_d50s6 =
                    	                new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 6, input);
                    	        
                    	            throw nvae_d50s6;
                    	        }
                    	    }
                    	    else 
                    	    {
                    	        NoViableAltException nvae_d50s4 =
                    	            new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 4, input);
                    	    
                    	        throw nvae_d50s4;
                    	    }
                    	    }
                    	    break;
                    	case BETWEEN:
                    		{
                    	    alt50 = 5;
                    	    }
                    	    break;
                    		default:
                    		    NoViableAltException nvae_d50s0 =
                    		        new NoViableAltException("217:16: ( comparisonOperator expressions -> ^( Predicate expressions comparisonOperator expressions ) | IS ( NOT )? NULL -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) ) | ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* ) | ( NOT )? IN subQuery -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery ) | ( NOT )? BETWEEN expressions AND expressions -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions ) )", 50, 0, input);
                    	
                    		    throw nvae_d50s0;
                    	}
                    	
                    	switch (alt50) 
                    	{
                    	    case 1 :
                    	        // OQL.g:217:17: comparisonOperator expressions
                    	        {
                    	        	PushFollow(FOLLOW_comparisonOperator_in_predicate2102);
                    	        	comparisonOperator126 = comparisonOperator();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_comparisonOperator.Add(comparisonOperator126.Tree);
                    	        	PushFollow(FOLLOW_expressions_in_predicate2105);
                    	        	expressions127 = expressions();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_expressions.Add(expressions127.Tree);
                    	        	
                    	        	// AST REWRITE
                    	        	// elements:          comparisonOperator, expressions, expressions
                    	        	// token labels:      
                    	        	// rule labels:       retval
                    	        	// token list labels: 
                    	        	// rule list labels:  
                    	        	retval.tree = root_0;
                    	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	        	
                    	        	root_0 = (Expression)adaptor.GetNilNode();
                    	        	// 218:4: -> ^( Predicate expressions comparisonOperator expressions )
                    	        	{
                    	        	    // OQL.g:218:7: ^( Predicate expressions comparisonOperator expressions )
                    	        	    {
                    	        	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	        	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Predicate, "Predicate"), root_1);
                    	        	    
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    adaptor.AddChild(root_1, stream_comparisonOperator.Next());
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_0, root_1);
                    	        	    }
                    	        	
                    	        	}
                    	        	

                    	        
                    	        }
                    	        break;
                    	    case 2 :
                    	        // OQL.g:219:4: IS ( NOT )? NULL
                    	        {
                    	        	IS128 = (IToken)input.LT(1);
                    	        	Match(input,IS,FOLLOW_IS_in_predicate2127); 
                    	        	stream_IS.Add(IS128);

                    	        	// OQL.g:219:7: ( NOT )?
                    	        	int alt45 = 2;
                    	        	int LA45_0 = input.LA(1);
                    	        	
                    	        	if ( (LA45_0 == NOT) )
                    	        	{
                    	        	    alt45 = 1;
                    	        	}
                    	        	switch (alt45) 
                    	        	{
                    	        	    case 1 :
                    	        	        // OQL.g:219:8: NOT
                    	        	        {
                    	        	        	NOT129 = (IToken)input.LT(1);
                    	        	        	Match(input,NOT,FOLLOW_NOT_in_predicate2130); 
                    	        	        	stream_NOT.Add(NOT129);

                    	        	        
                    	        	        }
                    	        	        break;
                    	        	
                    	        	}

                    	        	NULL130 = (IToken)input.LT(1);
                    	        	Match(input,NULL,FOLLOW_NULL_in_predicate2134); 
                    	        	stream_NULL.Add(NULL130);

                    	        	
                    	        	// AST REWRITE
                    	        	// elements:          NULL, IS, expressions, NOT
                    	        	// token labels:      
                    	        	// rule labels:       retval
                    	        	// token list labels: 
                    	        	// rule list labels:  
                    	        	retval.tree = root_0;
                    	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	        	
                    	        	root_0 = (Expression)adaptor.GetNilNode();
                    	        	// 220:4: -> ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) )
                    	        	{
                    	        	    // OQL.g:220:7: ^( Predicate_Is expressions ^( TextNode IS ( NOT )? NULL ) )
                    	        	    {
                    	        	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	        	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(Predicate_Is, "Predicate_Is"), root_1);
                    	        	    
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    // OQL.g:220:34: ^( TextNode IS ( NOT )? NULL )
                    	        	    {
                    	        	    Expression root_2 = (Expression)adaptor.GetNilNode();
                    	        	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
                    	        	    
                    	        	    adaptor.AddChild(root_2, stream_IS.Next());
                    	        	    // OQL.g:220:48: ( NOT )?
                    	        	    if ( stream_NOT.HasNext() )
                    	        	    {
                    	        	        adaptor.AddChild(root_2, stream_NOT.Next());
                    	        	    
                    	        	    }
                    	        	    stream_NOT.Reset();
                    	        	    adaptor.AddChild(root_2, stream_NULL.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_1, root_2);
                    	        	    }
                    	        	    
                    	        	    adaptor.AddChild(root_0, root_1);
                    	        	    }
                    	        	
                    	        	}
                    	        	

                    	        
                    	        }
                    	        break;
                    	    case 3 :
                    	        // OQL.g:221:4: ( NOT )? IN LPAREN expressions_0 ( COMMA expressions_1 )* RPAREN
                    	        {
                    	        	// OQL.g:221:4: ( NOT )?
                    	        	int alt46 = 2;
                    	        	int LA46_0 = input.LA(1);
                    	        	
                    	        	if ( (LA46_0 == NOT) )
                    	        	{
                    	        	    alt46 = 1;
                    	        	}
                    	        	switch (alt46) 
                    	        	{
                    	        	    case 1 :
                    	        	        // OQL.g:221:4: NOT
                    	        	        {
                    	        	        	NOT131 = (IToken)input.LT(1);
                    	        	        	Match(input,NOT,FOLLOW_NOT_in_predicate2164); 
                    	        	        	stream_NOT.Add(NOT131);

                    	        	        
                    	        	        }
                    	        	        break;
                    	        	
                    	        	}

                    	        	IN132 = (IToken)input.LT(1);
                    	        	Match(input,IN,FOLLOW_IN_in_predicate2167); 
                    	        	stream_IN.Add(IN132);

                    	        	LPAREN133 = (IToken)input.LT(1);
                    	        	Match(input,LPAREN,FOLLOW_LPAREN_in_predicate2169); 
                    	        	stream_LPAREN.Add(LPAREN133);

                    	        	PushFollow(FOLLOW_expressions_0_in_predicate2171);
                    	        	expressions_0134 = expressions_0();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_expressions_0.Add(expressions_0134.Tree);
                    	        	// OQL.g:221:33: ( COMMA expressions_1 )*
                    	        	do 
                    	        	{
                    	        	    int alt47 = 2;
                    	        	    int LA47_0 = input.LA(1);
                    	        	    
                    	        	    if ( (LA47_0 == COMMA) )
                    	        	    {
                    	        	        alt47 = 1;
                    	        	    }
                    	        	    
                    	        	
                    	        	    switch (alt47) 
                    	        		{
                    	        			case 1 :
                    	        			    // OQL.g:221:34: COMMA expressions_1
                    	        			    {
                    	        			    	COMMA135 = (IToken)input.LT(1);
                    	        			    	Match(input,COMMA,FOLLOW_COMMA_in_predicate2174); 
                    	        			    	stream_COMMA.Add(COMMA135);

                    	        			    	PushFollow(FOLLOW_expressions_1_in_predicate2176);
                    	        			    	expressions_1136 = expressions_1();
                    	        			    	followingStackPointer_--;
                    	        			    	
                    	        			    	stream_expressions_1.Add(expressions_1136.Tree);
                    	        			    
                    	        			    }
                    	        			    break;
                    	        	
                    	        			default:
                    	        			    goto loop47;
                    	        	    }
                    	        	} while (true);
                    	        	
                    	        	loop47:
                    	        		;	// Stops C# compiler whinging that label 'loop47' has no statements

                    	        	RPAREN137 = (IToken)input.LT(1);
                    	        	Match(input,RPAREN,FOLLOW_RPAREN_in_predicate2180); 
                    	        	stream_RPAREN.Add(RPAREN137);

                    	        	
                    	        	// AST REWRITE
                    	        	// elements:          expressions_0, expressions_1, IN, IN, NOT, expressions
                    	        	// token labels:      
                    	        	// rule labels:       retval
                    	        	// token list labels: 
                    	        	// rule list labels:  
                    	        	retval.tree = root_0;
                    	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	        	
                    	        	root_0 = (Expression)adaptor.GetNilNode();
                    	        	// 222:4: -> ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* )
                    	        	{
                    	        	    // OQL.g:222:7: ^( IN ^( TextNode ( NOT )? IN ) expressions expressions_0 ( expressions_1 )* )
                    	        	    {
                    	        	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	        	    root_1 = (Expression)adaptor.BecomeRoot(stream_IN.Next(), root_1);
                    	        	    
                    	        	    // OQL.g:222:12: ^( TextNode ( NOT )? IN )
                    	        	    {
                    	        	    Expression root_2 = (Expression)adaptor.GetNilNode();
                    	        	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
                    	        	    
                    	        	    // OQL.g:222:23: ( NOT )?
                    	        	    if ( stream_NOT.HasNext() )
                    	        	    {
                    	        	        adaptor.AddChild(root_2, stream_NOT.Next());
                    	        	    
                    	        	    }
                    	        	    stream_NOT.Reset();
                    	        	    adaptor.AddChild(root_2, stream_IN.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_1, root_2);
                    	        	    }
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    adaptor.AddChild(root_1, stream_expressions_0.Next());
                    	        	    // OQL.g:222:58: ( expressions_1 )*
                    	        	    while ( stream_expressions_1.HasNext() )
                    	        	    {
                    	        	        adaptor.AddChild(root_1, stream_expressions_1.Next());
                    	        	    
                    	        	    }
                    	        	    stream_expressions_1.Reset();
                    	        	    
                    	        	    adaptor.AddChild(root_0, root_1);
                    	        	    }
                    	        	
                    	        	}
                    	        	

                    	        
                    	        }
                    	        break;
                    	    case 4 :
                    	        // OQL.g:223:4: ( NOT )? IN subQuery
                    	        {
                    	        	// OQL.g:223:4: ( NOT )?
                    	        	int alt48 = 2;
                    	        	int LA48_0 = input.LA(1);
                    	        	
                    	        	if ( (LA48_0 == NOT) )
                    	        	{
                    	        	    alt48 = 1;
                    	        	}
                    	        	switch (alt48) 
                    	        	{
                    	        	    case 1 :
                    	        	        // OQL.g:223:4: NOT
                    	        	        {
                    	        	        	NOT138 = (IToken)input.LT(1);
                    	        	        	Match(input,NOT,FOLLOW_NOT_in_predicate2210); 
                    	        	        	stream_NOT.Add(NOT138);

                    	        	        
                    	        	        }
                    	        	        break;
                    	        	
                    	        	}

                    	        	IN139 = (IToken)input.LT(1);
                    	        	Match(input,IN,FOLLOW_IN_in_predicate2213); 
                    	        	stream_IN.Add(IN139);

                    	        	PushFollow(FOLLOW_subQuery_in_predicate2215);
                    	        	subQuery140 = subQuery();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_subQuery.Add(subQuery140.Tree);
                    	        	
                    	        	// AST REWRITE
                    	        	// elements:          subQuery, NOT, IN, IN, expressions
                    	        	// token labels:      
                    	        	// rule labels:       retval
                    	        	// token list labels: 
                    	        	// rule list labels:  
                    	        	retval.tree = root_0;
                    	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	        	
                    	        	root_0 = (Expression)adaptor.GetNilNode();
                    	        	// 224:4: -> ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery )
                    	        	{
                    	        	    // OQL.g:224:7: ^( IN ^( TextNode ( NOT )? IN ) expressions subQuery )
                    	        	    {
                    	        	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	        	    root_1 = (Expression)adaptor.BecomeRoot(stream_IN.Next(), root_1);
                    	        	    
                    	        	    // OQL.g:224:12: ^( TextNode ( NOT )? IN )
                    	        	    {
                    	        	    Expression root_2 = (Expression)adaptor.GetNilNode();
                    	        	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
                    	        	    
                    	        	    // OQL.g:224:23: ( NOT )?
                    	        	    if ( stream_NOT.HasNext() )
                    	        	    {
                    	        	        adaptor.AddChild(root_2, stream_NOT.Next());
                    	        	    
                    	        	    }
                    	        	    stream_NOT.Reset();
                    	        	    adaptor.AddChild(root_2, stream_IN.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_1, root_2);
                    	        	    }
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    adaptor.AddChild(root_1, stream_subQuery.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_0, root_1);
                    	        	    }
                    	        	
                    	        	}
                    	        	

                    	        
                    	        }
                    	        break;
                    	    case 5 :
                    	        // OQL.g:225:4: ( NOT )? BETWEEN expressions AND expressions
                    	        {
                    	        	// OQL.g:225:4: ( NOT )?
                    	        	int alt49 = 2;
                    	        	int LA49_0 = input.LA(1);
                    	        	
                    	        	if ( (LA49_0 == NOT) )
                    	        	{
                    	        	    alt49 = 1;
                    	        	}
                    	        	switch (alt49) 
                    	        	{
                    	        	    case 1 :
                    	        	        // OQL.g:225:4: NOT
                    	        	        {
                    	        	        	NOT141 = (IToken)input.LT(1);
                    	        	        	Match(input,NOT,FOLLOW_NOT_in_predicate2242); 
                    	        	        	stream_NOT.Add(NOT141);

                    	        	        
                    	        	        }
                    	        	        break;
                    	        	
                    	        	}

                    	        	BETWEEN142 = (IToken)input.LT(1);
                    	        	Match(input,BETWEEN,FOLLOW_BETWEEN_in_predicate2245); 
                    	        	stream_BETWEEN.Add(BETWEEN142);

                    	        	PushFollow(FOLLOW_expressions_in_predicate2247);
                    	        	expressions143 = expressions();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_expressions.Add(expressions143.Tree);
                    	        	AND144 = (IToken)input.LT(1);
                    	        	Match(input,AND,FOLLOW_AND_in_predicate2249); 
                    	        	stream_AND.Add(AND144);

                    	        	PushFollow(FOLLOW_expressions_in_predicate2251);
                    	        	expressions145 = expressions();
                    	        	followingStackPointer_--;
                    	        	
                    	        	stream_expressions.Add(expressions145.Tree);
                    	        	
                    	        	// AST REWRITE
                    	        	// elements:          expressions, BETWEEN, NOT, AND, expressions, expressions, BETWEEN
                    	        	// token labels:      
                    	        	// rule labels:       retval
                    	        	// token list labels: 
                    	        	// rule list labels:  
                    	        	retval.tree = root_0;
                    	        	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	        	
                    	        	root_0 = (Expression)adaptor.GetNilNode();
                    	        	// 226:4: -> ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions )
                    	        	{
                    	        	    // OQL.g:226:7: ^( BETWEEN ^( TextNode ( NOT )? BETWEEN ) expressions expressions ^( TextNode AND ) expressions )
                    	        	    {
                    	        	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	        	    root_1 = (Expression)adaptor.BecomeRoot(stream_BETWEEN.Next(), root_1);
                    	        	    
                    	        	    // OQL.g:226:17: ^( TextNode ( NOT )? BETWEEN )
                    	        	    {
                    	        	    Expression root_2 = (Expression)adaptor.GetNilNode();
                    	        	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
                    	        	    
                    	        	    // OQL.g:226:28: ( NOT )?
                    	        	    if ( stream_NOT.HasNext() )
                    	        	    {
                    	        	        adaptor.AddChild(root_2, stream_NOT.Next());
                    	        	    
                    	        	    }
                    	        	    stream_NOT.Reset();
                    	        	    adaptor.AddChild(root_2, stream_BETWEEN.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_1, root_2);
                    	        	    }
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    // OQL.g:226:66: ^( TextNode AND )
                    	        	    {
                    	        	    Expression root_2 = (Expression)adaptor.GetNilNode();
                    	        	    root_2 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_2);
                    	        	    
                    	        	    adaptor.AddChild(root_2, stream_AND.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_1, root_2);
                    	        	    }
                    	        	    adaptor.AddChild(root_1, stream_expressions.Next());
                    	        	    
                    	        	    adaptor.AddChild(root_0, root_1);
                    	        	    }
                    	        	
                    	        	}
                    	        	

                    	        
                    	        }
                    	        break;
                    	
                    	}

                    
                    }
                    break;
                case 2 :
                    // OQL.g:228:4: EXISTS subQuery
                    {
                    	EXISTS146 = (IToken)input.LT(1);
                    	Match(input,EXISTS,FOLLOW_EXISTS_in_predicate2289); 
                    	stream_EXISTS.Add(EXISTS146);

                    	PushFollow(FOLLOW_subQuery_in_predicate2291);
                    	subQuery147 = subQuery();
                    	followingStackPointer_--;
                    	
                    	stream_subQuery.Add(subQuery147.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          EXISTS, subQuery
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 228:20: -> ^( EXISTS subQuery )
                    	{
                    	    // OQL.g:228:23: ^( EXISTS subQuery )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(stream_EXISTS.Next(), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_subQuery.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end predicate

    public class expressions_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start expressions
    // OQL.g:231:1: expressions : expression ( mathOperator expression )* ;
    public expressions_return expressions() // throws RecognitionException [1]
    {   
        expressions_return retval = new expressions_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        expression_return expression148 = null;

        mathOperator_return mathOperator149 = null;

        expression_return expression150 = null;
        
        
    
        try 
    	{
            // OQL.g:231:12: ( expression ( mathOperator expression )* )
            // OQL.g:231:14: expression ( mathOperator expression )*
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_expression_in_expressions2308);
            	expression148 = expression();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, expression148.Tree);
            	// OQL.g:231:25: ( mathOperator expression )*
            	do 
            	{
            	    int alt52 = 2;
            	    int LA52_0 = input.LA(1);
            	    
            	    if ( ((LA52_0 >= DIV && LA52_0 <= MOD)) )
            	    {
            	        alt52 = 1;
            	    }
            	    
            	
            	    switch (alt52) 
            		{
            			case 1 :
            			    // OQL.g:231:26: mathOperator expression
            			    {
            			    	PushFollow(FOLLOW_mathOperator_in_expressions2311);
            			    	mathOperator149 = mathOperator();
            			    	followingStackPointer_--;
            			    	
            			    	adaptor.AddChild(root_0, mathOperator149.Tree);
            			    	PushFollow(FOLLOW_expression_in_expressions2313);
            			    	expression150 = expression();
            			    	followingStackPointer_--;
            			    	
            			    	adaptor.AddChild(root_0, expression150.Tree);
            			    
            			    }
            			    break;
            	
            			default:
            			    goto loop52;
            	    }
            	} while (true);
            	
            	loop52:
            		;	// Stops C# compiler whinging that label 'loop52' has no statements

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end expressions

    public class expressions_0_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start expressions_0
    // OQL.g:232:1: expressions_0 : expressions ;
    public expressions_0_return expressions_0() // throws RecognitionException [1]
    {   
        expressions_0_return retval = new expressions_0_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        expressions_return expressions151 = null;
        
        
    
        try 
    	{
            // OQL.g:232:14: ( expressions )
            // OQL.g:232:16: expressions
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_expressions_in_expressions_02322);
            	expressions151 = expressions();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, expressions151.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end expressions_0

    public class expressions_1_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start expressions_1
    // OQL.g:233:1: expressions_1 : expressions ;
    public expressions_1_return expressions_1() // throws RecognitionException [1]
    {   
        expressions_1_return retval = new expressions_1_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        expressions_return expressions152 = null;
        
        
    
        try 
    	{
            // OQL.g:233:14: ( expressions )
            // OQL.g:233:16: expressions
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	PushFollow(FOLLOW_expressions_in_expressions_12328);
            	expressions152 = expressions();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, expressions152.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end expressions_1

    public class expression_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start expression
    // OQL.g:234:1: expression : ( function | constant | userVariable | identifier | subQuery );
    public expression_return expression() // throws RecognitionException [1]
    {   
        expression_return retval = new expression_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        function_return function153 = null;

        constant_return constant154 = null;

        userVariable_return userVariable155 = null;

        identifier_return identifier156 = null;

        subQuery_return subQuery157 = null;
        
        
    
        try 
    	{
            // OQL.g:235:5: ( function | constant | userVariable | identifier | subQuery )
            int alt53 = 5;
            switch ( input.LA(1) ) 
            {
            case CASE:
            case SUM:
            case AVG:
            case MAX:
            case MIN:
            case COUNT:
            case LEN:
            	{
                alt53 = 1;
                }
                break;
            case QuotedIdentifier:
            	{
                int LA53_2 = input.LA(2);
                
                if ( (LA53_2 == LPAREN) )
                {
                    alt53 = 1;
                }
                else if ( (LA53_2 == EOF || (LA53_2 >= Eq && LA53_2 <= MOD) || LA53_2 == RPAREN || (LA53_2 >= COMMA && LA53_2 <= SEMI) || (LA53_2 >= AND && LA53_2 <= BETWEEN) || (LA53_2 >= CROSS && LA53_2 <= DESC) || (LA53_2 >= ELSE && LA53_2 <= END) || (LA53_2 >= FROM && LA53_2 <= INSERT) || LA53_2 == IS || (LA53_2 >= LEFT && LA53_2 <= NOT) || (LA53_2 >= OR && LA53_2 <= ORDER) || (LA53_2 >= RIGHT && LA53_2 <= SELECT) || (LA53_2 >= THEN && LA53_2 <= UPDATE) || (LA53_2 >= WHEN && LA53_2 <= TRUNCATE) || (LA53_2 >= QuotedIdentifier && LA53_2 <= NonQuotedIdentifier)) )
                {
                    alt53 = 4;
                }
                else 
                {
                    NoViableAltException nvae_d53s2 =
                        new NoViableAltException("234:1: expression : ( function | constant | userVariable | identifier | subQuery );", 53, 2, input);
                
                    throw nvae_d53s2;
                }
                }
                break;
            case NonQuotedIdentifier:
            	{
                int LA53_3 = input.LA(2);
                
                if ( (LA53_3 == LPAREN) )
                {
                    alt53 = 1;
                }
                else if ( (LA53_3 == EOF || (LA53_3 >= Eq && LA53_3 <= MOD) || LA53_3 == RPAREN || (LA53_3 >= COMMA && LA53_3 <= SEMI) || (LA53_3 >= AND && LA53_3 <= BETWEEN) || (LA53_3 >= CROSS && LA53_3 <= DESC) || (LA53_3 >= ELSE && LA53_3 <= END) || (LA53_3 >= FROM && LA53_3 <= INSERT) || LA53_3 == IS || (LA53_3 >= LEFT && LA53_3 <= NOT) || (LA53_3 >= OR && LA53_3 <= ORDER) || (LA53_3 >= RIGHT && LA53_3 <= SELECT) || (LA53_3 >= THEN && LA53_3 <= UPDATE) || (LA53_3 >= WHEN && LA53_3 <= TRUNCATE) || (LA53_3 >= QuotedIdentifier && LA53_3 <= NonQuotedIdentifier)) )
                {
                    alt53 = 4;
                }
                else 
                {
                    NoViableAltException nvae_d53s3 =
                        new NoViableAltException("234:1: expression : ( function | constant | userVariable | identifier | subQuery );", 53, 3, input);
                
                    throw nvae_d53s3;
                }
                }
                break;
            case MINUS:
            case NULL:
            case Integer:
            case StringLiteral:
            case Real:
            	{
                alt53 = 2;
                }
                break;
            case UserVariable:
            	{
                alt53 = 3;
                }
                break;
            case LPAREN:
            	{
                alt53 = 5;
                }
                break;
            	default:
            	    NoViableAltException nvae_d53s0 =
            	        new NoViableAltException("234:1: expression : ( function | constant | userVariable | identifier | subQuery );", 53, 0, input);
            
            	    throw nvae_d53s0;
            }
            
            switch (alt53) 
            {
                case 1 :
                    // OQL.g:236:6: function
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_function_in_expression2345);
                    	function153 = function();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, function153.Tree);
                    
                    }
                    break;
                case 2 :
                    // OQL.g:238:8: constant
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_constant_in_expression2364);
                    	constant154 = constant();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, constant154.Tree);
                    
                    }
                    break;
                case 3 :
                    // OQL.g:239:8: userVariable
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_userVariable_in_expression2374);
                    	userVariable155 = userVariable();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, userVariable155.Tree);
                    
                    }
                    break;
                case 4 :
                    // OQL.g:240:8: identifier
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_identifier_in_expression2383);
                    	identifier156 = identifier();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, identifier156.Tree);
                    
                    }
                    break;
                case 5 :
                    // OQL.g:241:8: subQuery
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_subQuery_in_expression2392);
                    	subQuery157 = subQuery();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, subQuery157.Tree);
                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end expression

    public class mathOperator_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start mathOperator
    // OQL.g:243:1: mathOperator : ( PLUS | MINUS | MUL | DIV | MOD );
    public mathOperator_return mathOperator() // throws RecognitionException [1]
    {   
        mathOperator_return retval = new mathOperator_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken set158 = null;
        
        Expression set158_tree=null;
    
        try 
    	{
            // OQL.g:243:14: ( PLUS | MINUS | MUL | DIV | MOD )
            // OQL.g:
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	set158 = (IToken)input.LT(1);
            	if ( (input.LA(1) >= DIV && input.LA(1) <= MOD) ) 
            	{
            	    input.Consume();
            	    adaptor.AddChild(root_0, adaptor.Create(set158));
            	    errorRecovery = false;
            	}
            	else 
            	{
            	    MismatchedSetException mse =
            	        new MismatchedSetException(null,input);
            	    RecoverFromMismatchedSet(input,mse,FOLLOW_set_in_mathOperator0);    throw mse;
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end mathOperator

    public class comparisonOperator_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start comparisonOperator
    // OQL.g:244:1: comparisonOperator : ( Eq | Neq1 | Neq2 | Le1 | Le2 | Lt | Ge1 | Ge2 | Gt | LIKE );
    public comparisonOperator_return comparisonOperator() // throws RecognitionException [1]
    {   
        comparisonOperator_return retval = new comparisonOperator_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken set159 = null;
        
        Expression set159_tree=null;
    
        try 
    	{
            // OQL.g:244:20: ( Eq | Neq1 | Neq2 | Le1 | Le2 | Lt | Ge1 | Ge2 | Gt | LIKE )
            // OQL.g:
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	set159 = (IToken)input.LT(1);
            	if ( (input.LA(1) >= Eq && input.LA(1) <= Gt) || input.LA(1) == LIKE ) 
            	{
            	    input.Consume();
            	    adaptor.AddChild(root_0, adaptor.Create(set159));
            	    errorRecovery = false;
            	}
            	else 
            	{
            	    MismatchedSetException mse =
            	        new MismatchedSetException(null,input);
            	    RecoverFromMismatchedSet(input,mse,FOLLOW_set_in_comparisonOperator0);    throw mse;
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end comparisonOperator

    public class function_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start function
    // OQL.g:247:1: function : ( systemFunction | userFunction );
    public function_return function() // throws RecognitionException [1]
    {   
        function_return retval = new function_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        systemFunction_return systemFunction160 = null;

        userFunction_return userFunction161 = null;
        
        
    
        try 
    	{
            // OQL.g:247:9: ( systemFunction | userFunction )
            int alt54 = 2;
            int LA54_0 = input.LA(1);
            
            if ( (LA54_0 == CASE || (LA54_0 >= SUM && LA54_0 <= LEN)) )
            {
                alt54 = 1;
            }
            else if ( ((LA54_0 >= QuotedIdentifier && LA54_0 <= NonQuotedIdentifier)) )
            {
                alt54 = 2;
            }
            else 
            {
                NoViableAltException nvae_d54s0 =
                    new NoViableAltException("247:1: function : ( systemFunction | userFunction );", 54, 0, input);
            
                throw nvae_d54s0;
            }
            switch (alt54) 
            {
                case 1 :
                    // OQL.g:247:11: systemFunction
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_systemFunction_in_function2494);
                    	systemFunction160 = systemFunction();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, systemFunction160.Tree);
                    
                    }
                    break;
                case 2 :
                    // OQL.g:247:28: userFunction
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_userFunction_in_function2498);
                    	userFunction161 = userFunction();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, userFunction161.Tree);
                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end function

    public class userFunction_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start userFunction
    // OQL.g:248:1: userFunction : identifier LPAREN ( expressions ( COMMA expressions_0 )* )? RPAREN -> ^( UserFunction identifier ( expressions ( expressions_0 )* )? ) ;
    public userFunction_return userFunction() // throws RecognitionException [1]
    {   
        userFunction_return retval = new userFunction_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken LPAREN163 = null;
        IToken COMMA165 = null;
        IToken RPAREN167 = null;
        identifier_return identifier162 = null;

        expressions_return expressions164 = null;

        expressions_0_return expressions_0166 = null;
        
        
        Expression LPAREN163_tree=null;
        Expression COMMA165_tree=null;
        Expression RPAREN167_tree=null;
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_COMMA = new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_expressions_0 = new RewriteRuleSubtreeStream(adaptor,"rule expressions_0");
        RewriteRuleSubtreeStream stream_identifier = new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:249:2: ( identifier LPAREN ( expressions ( COMMA expressions_0 )* )? RPAREN -> ^( UserFunction identifier ( expressions ( expressions_0 )* )? ) )
            // OQL.g:249:4: identifier LPAREN ( expressions ( COMMA expressions_0 )* )? RPAREN
            {
            	PushFollow(FOLLOW_identifier_in_userFunction2507);
            	identifier162 = identifier();
            	followingStackPointer_--;
            	
            	stream_identifier.Add(identifier162.Tree);
            	LPAREN163 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_userFunction2509); 
            	stream_LPAREN.Add(LPAREN163);

            	// OQL.g:249:22: ( expressions ( COMMA expressions_0 )* )?
            	int alt56 = 2;
            	int LA56_0 = input.LA(1);
            	
            	if ( (LA56_0 == MINUS || LA56_0 == LPAREN || LA56_0 == CASE || LA56_0 == NULL || (LA56_0 >= SUM && LA56_0 <= LEN) || (LA56_0 >= QuotedIdentifier && LA56_0 <= UserVariable)) )
            	{
            	    alt56 = 1;
            	}
            	switch (alt56) 
            	{
            	    case 1 :
            	        // OQL.g:249:23: expressions ( COMMA expressions_0 )*
            	        {
            	        	PushFollow(FOLLOW_expressions_in_userFunction2512);
            	        	expressions164 = expressions();
            	        	followingStackPointer_--;
            	        	
            	        	stream_expressions.Add(expressions164.Tree);
            	        	// OQL.g:249:35: ( COMMA expressions_0 )*
            	        	do 
            	        	{
            	        	    int alt55 = 2;
            	        	    int LA55_0 = input.LA(1);
            	        	    
            	        	    if ( (LA55_0 == COMMA) )
            	        	    {
            	        	        alt55 = 1;
            	        	    }
            	        	    
            	        	
            	        	    switch (alt55) 
            	        		{
            	        			case 1 :
            	        			    // OQL.g:249:36: COMMA expressions_0
            	        			    {
            	        			    	COMMA165 = (IToken)input.LT(1);
            	        			    	Match(input,COMMA,FOLLOW_COMMA_in_userFunction2515); 
            	        			    	stream_COMMA.Add(COMMA165);

            	        			    	PushFollow(FOLLOW_expressions_0_in_userFunction2517);
            	        			    	expressions_0166 = expressions_0();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	stream_expressions_0.Add(expressions_0166.Tree);
            	        			    
            	        			    }
            	        			    break;
            	        	
            	        			default:
            	        			    goto loop55;
            	        	    }
            	        	} while (true);
            	        	
            	        	loop55:
            	        		;	// Stops C# compiler whinging that label 'loop55' has no statements

            	        
            	        }
            	        break;
            	
            	}

            	RPAREN167 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_userFunction2523); 
            	stream_RPAREN.Add(RPAREN167);

            	
            	// AST REWRITE
            	// elements:          expressions, expressions_0, identifier
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 250:4: -> ^( UserFunction identifier ( expressions ( expressions_0 )* )? )
            	{
            	    // OQL.g:250:7: ^( UserFunction identifier ( expressions ( expressions_0 )* )? )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(UserFunction, "UserFunction"), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_identifier.Next());
            	    // OQL.g:250:33: ( expressions ( expressions_0 )* )?
            	    if ( stream_expressions.HasNext() || stream_expressions_0.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_expressions.Next());
            	        // OQL.g:250:46: ( expressions_0 )*
            	        while ( stream_expressions_0.HasNext() )
            	        {
            	            adaptor.AddChild(root_1, stream_expressions_0.Next());
            	        
            	        }
            	        stream_expressions_0.Reset();
            	    
            	    }
            	    stream_expressions.Reset();
            	    stream_expressions_0.Reset();
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end userFunction

    public class systemFunction_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start systemFunction
    // OQL.g:252:1: systemFunction : ( fnCase | unitarySysFun | fnLen );
    public systemFunction_return systemFunction() // throws RecognitionException [1]
    {   
        systemFunction_return retval = new systemFunction_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        fnCase_return fnCase168 = null;

        unitarySysFun_return unitarySysFun169 = null;

        fnLen_return fnLen170 = null;
        
        
    
        try 
    	{
            // OQL.g:252:15: ( fnCase | unitarySysFun | fnLen )
            int alt57 = 3;
            switch ( input.LA(1) ) 
            {
            case CASE:
            	{
                alt57 = 1;
                }
                break;
            case SUM:
            case AVG:
            case MAX:
            case MIN:
            case COUNT:
            	{
                alt57 = 2;
                }
                break;
            case LEN:
            	{
                alt57 = 3;
                }
                break;
            	default:
            	    NoViableAltException nvae_d57s0 =
            	        new NoViableAltException("252:1: systemFunction : ( fnCase | unitarySysFun | fnLen );", 57, 0, input);
            
            	    throw nvae_d57s0;
            }
            
            switch (alt57) 
            {
                case 1 :
                    // OQL.g:252:17: fnCase
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_fnCase_in_systemFunction2550);
                    	fnCase168 = fnCase();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, fnCase168.Tree);
                    
                    }
                    break;
                case 2 :
                    // OQL.g:252:26: unitarySysFun
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_unitarySysFun_in_systemFunction2554);
                    	unitarySysFun169 = unitarySysFun();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, unitarySysFun169.Tree);
                    
                    }
                    break;
                case 3 :
                    // OQL.g:252:42: fnLen
                    {
                    	root_0 = (Expression)adaptor.GetNilNode();
                    
                    	PushFollow(FOLLOW_fnLen_in_systemFunction2558);
                    	fnLen170 = fnLen();
                    	followingStackPointer_--;
                    	
                    	adaptor.AddChild(root_0, fnLen170.Tree);
                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end systemFunction

    public class fnCase_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start fnCase
    // OQL.g:255:1: fnCase : CASE ( expressions ( WHEN expressions THEN expressions )+ | ( WHEN condition THEN expressions )+ ) ( ELSE expressions )? END ;
    public fnCase_return fnCase() // throws RecognitionException [1]
    {   
        fnCase_return retval = new fnCase_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken CASE171 = null;
        IToken WHEN173 = null;
        IToken THEN175 = null;
        IToken WHEN177 = null;
        IToken THEN179 = null;
        IToken ELSE181 = null;
        IToken END183 = null;
        expressions_return expressions172 = null;

        expressions_return expressions174 = null;

        expressions_return expressions176 = null;

        condition_return condition178 = null;

        expressions_return expressions180 = null;

        expressions_return expressions182 = null;
        
        
        Expression CASE171_tree=null;
        Expression WHEN173_tree=null;
        Expression THEN175_tree=null;
        Expression WHEN177_tree=null;
        Expression THEN179_tree=null;
        Expression ELSE181_tree=null;
        Expression END183_tree=null;
    
        try 
    	{
            // OQL.g:256:5: ( CASE ( expressions ( WHEN expressions THEN expressions )+ | ( WHEN condition THEN expressions )+ ) ( ELSE expressions )? END )
            // OQL.g:256:7: CASE ( expressions ( WHEN expressions THEN expressions )+ | ( WHEN condition THEN expressions )+ ) ( ELSE expressions )? END
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	CASE171 = (IToken)input.LT(1);
            	Match(input,CASE,FOLLOW_CASE_in_fnCase2571); 
            	CASE171_tree = (Expression)adaptor.Create(CASE171);
            	root_0 = (Expression)adaptor.BecomeRoot(CASE171_tree, root_0);

            	// OQL.g:256:13: ( expressions ( WHEN expressions THEN expressions )+ | ( WHEN condition THEN expressions )+ )
            	int alt60 = 2;
            	int LA60_0 = input.LA(1);
            	
            	if ( (LA60_0 == MINUS || LA60_0 == LPAREN || LA60_0 == CASE || LA60_0 == NULL || (LA60_0 >= SUM && LA60_0 <= LEN) || (LA60_0 >= QuotedIdentifier && LA60_0 <= UserVariable)) )
            	{
            	    alt60 = 1;
            	}
            	else if ( (LA60_0 == WHEN) )
            	{
            	    alt60 = 2;
            	}
            	else 
            	{
            	    NoViableAltException nvae_d60s0 =
            	        new NoViableAltException("256:13: ( expressions ( WHEN expressions THEN expressions )+ | ( WHEN condition THEN expressions )+ )", 60, 0, input);
            	
            	    throw nvae_d60s0;
            	}
            	switch (alt60) 
            	{
            	    case 1 :
            	        // OQL.g:257:11: expressions ( WHEN expressions THEN expressions )+
            	        {
            	        	PushFollow(FOLLOW_expressions_in_fnCase2586);
            	        	expressions172 = expressions();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, expressions172.Tree);
            	        	// OQL.g:257:23: ( WHEN expressions THEN expressions )+
            	        	int cnt58 = 0;
            	        	do 
            	        	{
            	        	    int alt58 = 2;
            	        	    int LA58_0 = input.LA(1);
            	        	    
            	        	    if ( (LA58_0 == WHEN) )
            	        	    {
            	        	        alt58 = 1;
            	        	    }
            	        	    
            	        	
            	        	    switch (alt58) 
            	        		{
            	        			case 1 :
            	        			    // OQL.g:257:24: WHEN expressions THEN expressions
            	        			    {
            	        			    	WHEN173 = (IToken)input.LT(1);
            	        			    	Match(input,WHEN,FOLLOW_WHEN_in_fnCase2589); 
            	        			    	WHEN173_tree = (Expression)adaptor.Create(WHEN173);
            	        			    	adaptor.AddChild(root_0, WHEN173_tree);

            	        			    	PushFollow(FOLLOW_expressions_in_fnCase2591);
            	        			    	expressions174 = expressions();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, expressions174.Tree);
            	        			    	THEN175 = (IToken)input.LT(1);
            	        			    	Match(input,THEN,FOLLOW_THEN_in_fnCase2593); 
            	        			    	THEN175_tree = (Expression)adaptor.Create(THEN175);
            	        			    	adaptor.AddChild(root_0, THEN175_tree);

            	        			    	PushFollow(FOLLOW_expressions_in_fnCase2595);
            	        			    	expressions176 = expressions();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, expressions176.Tree);
            	        			    
            	        			    }
            	        			    break;
            	        	
            	        			default:
            	        			    if ( cnt58 >= 1 ) goto loop58;
            	        		            EarlyExitException eee =
            	        		                new EarlyExitException(58, input);
            	        		            throw eee;
            	        	    }
            	        	    cnt58++;
            	        	} while (true);
            	        	
            	        	loop58:
            	        		;	// Stops C# compiler whinging that label 'loop58' has no statements

            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:258:11: ( WHEN condition THEN expressions )+
            	        {
            	        	// OQL.g:258:11: ( WHEN condition THEN expressions )+
            	        	int cnt59 = 0;
            	        	do 
            	        	{
            	        	    int alt59 = 2;
            	        	    int LA59_0 = input.LA(1);
            	        	    
            	        	    if ( (LA59_0 == WHEN) )
            	        	    {
            	        	        alt59 = 1;
            	        	    }
            	        	    
            	        	
            	        	    switch (alt59) 
            	        		{
            	        			case 1 :
            	        			    // OQL.g:258:12: WHEN condition THEN expressions
            	        			    {
            	        			    	WHEN177 = (IToken)input.LT(1);
            	        			    	Match(input,WHEN,FOLLOW_WHEN_in_fnCase2610); 
            	        			    	WHEN177_tree = (Expression)adaptor.Create(WHEN177);
            	        			    	adaptor.AddChild(root_0, WHEN177_tree);

            	        			    	PushFollow(FOLLOW_condition_in_fnCase2612);
            	        			    	condition178 = condition();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, condition178.Tree);
            	        			    	THEN179 = (IToken)input.LT(1);
            	        			    	Match(input,THEN,FOLLOW_THEN_in_fnCase2614); 
            	        			    	THEN179_tree = (Expression)adaptor.Create(THEN179);
            	        			    	adaptor.AddChild(root_0, THEN179_tree);

            	        			    	PushFollow(FOLLOW_expressions_in_fnCase2616);
            	        			    	expressions180 = expressions();
            	        			    	followingStackPointer_--;
            	        			    	
            	        			    	adaptor.AddChild(root_0, expressions180.Tree);
            	        			    
            	        			    }
            	        			    break;
            	        	
            	        			default:
            	        			    if ( cnt59 >= 1 ) goto loop59;
            	        		            EarlyExitException eee =
            	        		                new EarlyExitException(59, input);
            	        		            throw eee;
            	        	    }
            	        	    cnt59++;
            	        	} while (true);
            	        	
            	        	loop59:
            	        		;	// Stops C# compiler whinging that label 'loop59' has no statements

            	        
            	        }
            	        break;
            	
            	}

            	// OQL.g:260:5: ( ELSE expressions )?
            	int alt61 = 2;
            	int LA61_0 = input.LA(1);
            	
            	if ( (LA61_0 == ELSE) )
            	{
            	    alt61 = 1;
            	}
            	switch (alt61) 
            	{
            	    case 1 :
            	        // OQL.g:260:6: ELSE expressions
            	        {
            	        	ELSE181 = (IToken)input.LT(1);
            	        	Match(input,ELSE,FOLLOW_ELSE_in_fnCase2639); 
            	        	ELSE181_tree = (Expression)adaptor.Create(ELSE181);
            	        	adaptor.AddChild(root_0, ELSE181_tree);

            	        	PushFollow(FOLLOW_expressions_in_fnCase2641);
            	        	expressions182 = expressions();
            	        	followingStackPointer_--;
            	        	
            	        	adaptor.AddChild(root_0, expressions182.Tree);
            	        
            	        }
            	        break;
            	
            	}

            	END183 = (IToken)input.LT(1);
            	Match(input,END,FOLLOW_END_in_fnCase2645); 
            	END183_tree = (Expression)adaptor.Create(END183);
            	adaptor.AddChild(root_0, END183_tree);

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end fnCase

    public class fnLen_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start fnLen
    // OQL.g:262:1: fnLen : LEN LPAREN expressions RPAREN -> ^( LEN expressions ) ;
    public fnLen_return fnLen() // throws RecognitionException [1]
    {   
        fnLen_return retval = new fnLen_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken LEN184 = null;
        IToken LPAREN185 = null;
        IToken RPAREN187 = null;
        expressions_return expressions186 = null;
        
        
        Expression LEN184_tree=null;
        Expression LPAREN185_tree=null;
        Expression RPAREN187_tree=null;
        RewriteRuleTokenStream stream_LEN = new RewriteRuleTokenStream(adaptor,"token LEN");
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:263:2: ( LEN LPAREN expressions RPAREN -> ^( LEN expressions ) )
            // OQL.g:263:4: LEN LPAREN expressions RPAREN
            {
            	LEN184 = (IToken)input.LT(1);
            	Match(input,LEN,FOLLOW_LEN_in_fnLen2658); 
            	stream_LEN.Add(LEN184);

            	LPAREN185 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_fnLen2660); 
            	stream_LPAREN.Add(LPAREN185);

            	PushFollow(FOLLOW_expressions_in_fnLen2662);
            	expressions186 = expressions();
            	followingStackPointer_--;
            	
            	stream_expressions.Add(expressions186.Tree);
            	RPAREN187 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_fnLen2664); 
            	stream_RPAREN.Add(RPAREN187);

            	
            	// AST REWRITE
            	// elements:          expressions, LEN
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 264:4: -> ^( LEN expressions )
            	{
            	    // OQL.g:264:7: ^( LEN expressions )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(stream_LEN.Next(), root_1);
            	    
            	    adaptor.AddChild(root_1, stream_expressions.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end fnLen

    public class unitarySysFun_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start unitarySysFun
    // OQL.g:266:1: unitarySysFun : ( SUM | AVG | MAX | MIN | COUNT ) unitarySysFun_0 ;
    public unitarySysFun_return unitarySysFun() // throws RecognitionException [1]
    {   
        unitarySysFun_return retval = new unitarySysFun_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken SUM188 = null;
        IToken AVG189 = null;
        IToken MAX190 = null;
        IToken MIN191 = null;
        IToken COUNT192 = null;
        unitarySysFun_0_return unitarySysFun_0193 = null;
        
        
        Expression SUM188_tree=null;
        Expression AVG189_tree=null;
        Expression MAX190_tree=null;
        Expression MIN191_tree=null;
        Expression COUNT192_tree=null;
    
        try 
    	{
            // OQL.g:266:14: ( ( SUM | AVG | MAX | MIN | COUNT ) unitarySysFun_0 )
            // OQL.g:266:16: ( SUM | AVG | MAX | MIN | COUNT ) unitarySysFun_0
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	// OQL.g:266:16: ( SUM | AVG | MAX | MIN | COUNT )
            	int alt62 = 5;
            	switch ( input.LA(1) ) 
            	{
            	case SUM:
            		{
            	    alt62 = 1;
            	    }
            	    break;
            	case AVG:
            		{
            	    alt62 = 2;
            	    }
            	    break;
            	case MAX:
            		{
            	    alt62 = 3;
            	    }
            	    break;
            	case MIN:
            		{
            	    alt62 = 4;
            	    }
            	    break;
            	case COUNT:
            		{
            	    alt62 = 5;
            	    }
            	    break;
            		default:
            		    NoViableAltException nvae_d62s0 =
            		        new NoViableAltException("266:16: ( SUM | AVG | MAX | MIN | COUNT )", 62, 0, input);
            	
            		    throw nvae_d62s0;
            	}
            	
            	switch (alt62) 
            	{
            	    case 1 :
            	        // OQL.g:266:17: SUM
            	        {
            	        	SUM188 = (IToken)input.LT(1);
            	        	Match(input,SUM,FOLLOW_SUM_in_unitarySysFun2684); 
            	        	SUM188_tree = (Expression)adaptor.Create(SUM188);
            	        	root_0 = (Expression)adaptor.BecomeRoot(SUM188_tree, root_0);

            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:266:24: AVG
            	        {
            	        	AVG189 = (IToken)input.LT(1);
            	        	Match(input,AVG,FOLLOW_AVG_in_unitarySysFun2689); 
            	        	AVG189_tree = (Expression)adaptor.Create(AVG189);
            	        	root_0 = (Expression)adaptor.BecomeRoot(AVG189_tree, root_0);

            	        
            	        }
            	        break;
            	    case 3 :
            	        // OQL.g:266:31: MAX
            	        {
            	        	MAX190 = (IToken)input.LT(1);
            	        	Match(input,MAX,FOLLOW_MAX_in_unitarySysFun2694); 
            	        	MAX190_tree = (Expression)adaptor.Create(MAX190);
            	        	root_0 = (Expression)adaptor.BecomeRoot(MAX190_tree, root_0);

            	        
            	        }
            	        break;
            	    case 4 :
            	        // OQL.g:266:38: MIN
            	        {
            	        	MIN191 = (IToken)input.LT(1);
            	        	Match(input,MIN,FOLLOW_MIN_in_unitarySysFun2699); 
            	        	MIN191_tree = (Expression)adaptor.Create(MIN191);
            	        	root_0 = (Expression)adaptor.BecomeRoot(MIN191_tree, root_0);

            	        
            	        }
            	        break;
            	    case 5 :
            	        // OQL.g:266:45: COUNT
            	        {
            	        	COUNT192 = (IToken)input.LT(1);
            	        	Match(input,COUNT,FOLLOW_COUNT_in_unitarySysFun2704); 
            	        	COUNT192_tree = (Expression)adaptor.Create(COUNT192);
            	        	root_0 = (Expression)adaptor.BecomeRoot(COUNT192_tree, root_0);

            	        
            	        }
            	        break;
            	
            	}

            	PushFollow(FOLLOW_unitarySysFun_0_in_unitarySysFun2708);
            	unitarySysFun_0193 = unitarySysFun_0();
            	followingStackPointer_--;
            	
            	adaptor.AddChild(root_0, unitarySysFun_0193.Tree);
            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end unitarySysFun

    public class unitarySysFun_0_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start unitarySysFun_0
    // OQL.g:267:1: unitarySysFun_0 : LPAREN ( ( MUL ) | ( expressions ) )? RPAREN -> {paramType==1}? -> {paramType==2}? MUL -> {paramType==3}? expressions ->;
    public unitarySysFun_0_return unitarySysFun_0() // throws RecognitionException [1]
    {   
        unitarySysFun_0_return retval = new unitarySysFun_0_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken LPAREN194 = null;
        IToken MUL195 = null;
        IToken RPAREN197 = null;
        expressions_return expressions196 = null;
        
        
        Expression LPAREN194_tree=null;
        Expression MUL195_tree=null;
        Expression RPAREN197_tree=null;
        RewriteRuleTokenStream stream_RPAREN = new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_MUL = new RewriteRuleTokenStream(adaptor,"token MUL");
        RewriteRuleTokenStream stream_LPAREN = new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_expressions = new RewriteRuleSubtreeStream(adaptor,"rule expressions");
        try 
    	{
            // OQL.g:268:2: ( LPAREN ( ( MUL ) | ( expressions ) )? RPAREN -> {paramType==1}? -> {paramType==2}? MUL -> {paramType==3}? expressions ->)
            // OQL.g:268:4: LPAREN ( ( MUL ) | ( expressions ) )? RPAREN
            {
            	int paramType=1;
            	LPAREN194 = (IToken)input.LT(1);
            	Match(input,LPAREN,FOLLOW_LPAREN_in_unitarySysFun_02718); 
            	stream_LPAREN.Add(LPAREN194);

            	// OQL.g:268:30: ( ( MUL ) | ( expressions ) )?
            	int alt63 = 3;
            	int LA63_0 = input.LA(1);
            	
            	if ( (LA63_0 == MUL) )
            	{
            	    alt63 = 1;
            	}
            	else if ( (LA63_0 == MINUS || LA63_0 == LPAREN || LA63_0 == CASE || LA63_0 == NULL || (LA63_0 >= SUM && LA63_0 <= LEN) || (LA63_0 >= QuotedIdentifier && LA63_0 <= UserVariable)) )
            	{
            	    alt63 = 2;
            	}
            	switch (alt63) 
            	{
            	    case 1 :
            	        // OQL.g:268:31: ( MUL )
            	        {
            	        	// OQL.g:268:31: ( MUL )
            	        	// OQL.g:268:32: MUL
            	        	{
            	        		MUL195 = (IToken)input.LT(1);
            	        		Match(input,MUL,FOLLOW_MUL_in_unitarySysFun_02722); 
            	        		stream_MUL.Add(MUL195);

            	        		paramType=2;
            	        	
            	        	}

            	        
            	        }
            	        break;
            	    case 2 :
            	        // OQL.g:268:54: ( expressions )
            	        {
            	        	// OQL.g:268:54: ( expressions )
            	        	// OQL.g:268:55: expressions
            	        	{
            	        		PushFollow(FOLLOW_expressions_in_unitarySysFun_02730);
            	        		expressions196 = expressions();
            	        		followingStackPointer_--;
            	        		
            	        		stream_expressions.Add(expressions196.Tree);
            	        		paramType=3;
            	        	
            	        	}

            	        
            	        }
            	        break;
            	
            	}

            	RPAREN197 = (IToken)input.LT(1);
            	Match(input,RPAREN,FOLLOW_RPAREN_in_unitarySysFun_02737); 
            	stream_RPAREN.Add(RPAREN197);

            	
            	// AST REWRITE
            	// elements:          MUL, expressions
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 269:4: -> {paramType==1}?
            	if (paramType==1)
            	{
            	    root_0 = null;
            	}
            	else // 270:4: -> {paramType==2}? MUL
            	if (paramType==2)
            	{
            	    adaptor.AddChild(root_0, stream_MUL.Next());
            	
            	}
            	else // 271:4: -> {paramType==3}? expressions
            	if (paramType==3)
            	{
            	    adaptor.AddChild(root_0, stream_expressions.Next());
            	
            	}
            	else // 272:4: ->
            	{
            	    root_0 = null;
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end unitarySysFun_0

    public class identifier_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start identifier
    // OQL.g:277:1: identifier : ( QuotedIdentifier -> | NonQuotedIdentifier ->);
    public identifier_return identifier() // throws RecognitionException [1]
    {   
        identifier_return retval = new identifier_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken QuotedIdentifier198 = null;
        IToken NonQuotedIdentifier199 = null;
        
        Expression QuotedIdentifier198_tree=null;
        Expression NonQuotedIdentifier199_tree=null;
        RewriteRuleTokenStream stream_NonQuotedIdentifier = new RewriteRuleTokenStream(adaptor,"token NonQuotedIdentifier");
        RewriteRuleTokenStream stream_QuotedIdentifier = new RewriteRuleTokenStream(adaptor,"token QuotedIdentifier");
    
        try 
    	{
            // OQL.g:278:2: ( QuotedIdentifier -> | NonQuotedIdentifier ->)
            int alt64 = 2;
            int LA64_0 = input.LA(1);
            
            if ( (LA64_0 == QuotedIdentifier) )
            {
                alt64 = 1;
            }
            else if ( (LA64_0 == NonQuotedIdentifier) )
            {
                alt64 = 2;
            }
            else 
            {
                NoViableAltException nvae_d64s0 =
                    new NoViableAltException("277:1: identifier : ( QuotedIdentifier -> | NonQuotedIdentifier ->);", 64, 0, input);
            
                throw nvae_d64s0;
            }
            switch (alt64) 
            {
                case 1 :
                    // OQL.g:278:4: QuotedIdentifier
                    {
                    	QuotedIdentifier198 = (IToken)input.LT(1);
                    	Match(input,QuotedIdentifier,FOLLOW_QuotedIdentifier_in_identifier2777); 
                    	stream_QuotedIdentifier.Add(QuotedIdentifier198);

                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 278:21: ->
                    	{
                    	    adaptor.AddChild(root_0, new Identifier(QuotedIdentifier198));
                    	
                    	}
                    	

                    
                    }
                    break;
                case 2 :
                    // OQL.g:279:4: NonQuotedIdentifier
                    {
                    	NonQuotedIdentifier199 = (IToken)input.LT(1);
                    	Match(input,NonQuotedIdentifier,FOLLOW_NonQuotedIdentifier_in_identifier2786); 
                    	stream_NonQuotedIdentifier.Add(NonQuotedIdentifier199);

                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 279:24: ->
                    	{
                    	    adaptor.AddChild(root_0, new Identifier(NonQuotedIdentifier199));
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end identifier

    public class datatype_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start datatype
    // OQL.g:281:1: datatype : ( datatypeNParam -> ^( DataType datatypeNParam ) | datatypeOneParam -> ^( DataType datatypeOneParam ) | datatypeNoParam -> ^( DataType datatypeNoParam ) );
    public datatype_return datatype() // throws RecognitionException [1]
    {   
        datatype_return retval = new datatype_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        datatypeNParam_return datatypeNParam200 = null;

        datatypeOneParam_return datatypeOneParam201 = null;

        datatypeNoParam_return datatypeNoParam202 = null;
        
        
        RewriteRuleSubtreeStream stream_datatypeNoParam = new RewriteRuleSubtreeStream(adaptor,"rule datatypeNoParam");
        RewriteRuleSubtreeStream stream_datatypeOneParam = new RewriteRuleSubtreeStream(adaptor,"rule datatypeOneParam");
        RewriteRuleSubtreeStream stream_datatypeNParam = new RewriteRuleSubtreeStream(adaptor,"rule datatypeNParam");
        try 
    	{
            // OQL.g:282:2: ( datatypeNParam -> ^( DataType datatypeNParam ) | datatypeOneParam -> ^( DataType datatypeOneParam ) | datatypeNoParam -> ^( DataType datatypeNoParam ) )
            int alt65 = 3;
            switch ( input.LA(1) ) 
            {
            case DECIMAL:
            	{
                alt65 = 1;
                }
                break;
            case CHAR:
            case NCHAR:
            case VARCHAR:
            case NVARCHAR:
            case TEXT:
            case NTEXT:
            case BINARY:
            	{
                alt65 = 2;
                }
                break;
            case DATETIME:
            case INT:
            	{
                alt65 = 3;
                }
                break;
            	default:
            	    NoViableAltException nvae_d65s0 =
            	        new NoViableAltException("281:1: datatype : ( datatypeNParam -> ^( DataType datatypeNParam ) | datatypeOneParam -> ^( DataType datatypeOneParam ) | datatypeNoParam -> ^( DataType datatypeNoParam ) );", 65, 0, input);
            
            	    throw nvae_d65s0;
            }
            
            switch (alt65) 
            {
                case 1 :
                    // OQL.g:282:4: datatypeNParam
                    {
                    	PushFollow(FOLLOW_datatypeNParam_in_datatype2800);
                    	datatypeNParam200 = datatypeNParam();
                    	followingStackPointer_--;
                    	
                    	stream_datatypeNParam.Add(datatypeNParam200.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          datatypeNParam
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 282:19: -> ^( DataType datatypeNParam )
                    	{
                    	    // OQL.g:282:22: ^( DataType datatypeNParam )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(DataType, "DataType"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_datatypeNParam.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
                case 2 :
                    // OQL.g:283:4: datatypeOneParam
                    {
                    	PushFollow(FOLLOW_datatypeOneParam_in_datatype2813);
                    	datatypeOneParam201 = datatypeOneParam();
                    	followingStackPointer_--;
                    	
                    	stream_datatypeOneParam.Add(datatypeOneParam201.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          datatypeOneParam
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 283:21: -> ^( DataType datatypeOneParam )
                    	{
                    	    // OQL.g:283:24: ^( DataType datatypeOneParam )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(DataType, "DataType"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_datatypeOneParam.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
                case 3 :
                    // OQL.g:284:4: datatypeNoParam
                    {
                    	PushFollow(FOLLOW_datatypeNoParam_in_datatype2826);
                    	datatypeNoParam202 = datatypeNoParam();
                    	followingStackPointer_--;
                    	
                    	stream_datatypeNoParam.Add(datatypeNoParam202.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          datatypeNoParam
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 284:20: -> ^( DataType datatypeNoParam )
                    	{
                    	    // OQL.g:284:23: ^( DataType datatypeNoParam )
                    	    {
                    	    Expression root_1 = (Expression)adaptor.GetNilNode();
                    	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(DataType, "DataType"), root_1);
                    	    
                    	    adaptor.AddChild(root_1, stream_datatypeNoParam.Next());
                    	    
                    	    adaptor.AddChild(root_0, root_1);
                    	    }
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end datatype

    public class datatypeNoParam_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start datatypeNoParam
    // OQL.g:286:1: datatypeNoParam : ( INT | DATETIME );
    public datatypeNoParam_return datatypeNoParam() // throws RecognitionException [1]
    {   
        datatypeNoParam_return retval = new datatypeNoParam_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken set203 = null;
        
        Expression set203_tree=null;
    
        try 
    	{
            // OQL.g:286:16: ( INT | DATETIME )
            // OQL.g:
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	set203 = (IToken)input.LT(1);
            	if ( (input.LA(1) >= DATETIME && input.LA(1) <= INT) ) 
            	{
            	    input.Consume();
            	    adaptor.AddChild(root_0, adaptor.Create(set203));
            	    errorRecovery = false;
            	}
            	else 
            	{
            	    MismatchedSetException mse =
            	        new MismatchedSetException(null,input);
            	    RecoverFromMismatchedSet(input,mse,FOLLOW_set_in_datatypeNoParam0);    throw mse;
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end datatypeNoParam

    public class datatypeOneParam_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start datatypeOneParam
    // OQL.g:287:1: datatypeOneParam : ( CHAR | NCHAR | VARCHAR | NVARCHAR | TEXT | NTEXT | BINARY ) ( LPAREN Integer RPAREN )? ;
    public datatypeOneParam_return datatypeOneParam() // throws RecognitionException [1]
    {   
        datatypeOneParam_return retval = new datatypeOneParam_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken set204 = null;
        IToken LPAREN205 = null;
        IToken Integer206 = null;
        IToken RPAREN207 = null;
        
        Expression set204_tree=null;
        Expression LPAREN205_tree=null;
        Expression Integer206_tree=null;
        Expression RPAREN207_tree=null;
    
        try 
    	{
            // OQL.g:288:2: ( ( CHAR | NCHAR | VARCHAR | NVARCHAR | TEXT | NTEXT | BINARY ) ( LPAREN Integer RPAREN )? )
            // OQL.g:288:4: ( CHAR | NCHAR | VARCHAR | NVARCHAR | TEXT | NTEXT | BINARY ) ( LPAREN Integer RPAREN )?
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	set204 = (IToken)input.LT(1);
            	if ( (input.LA(1) >= CHAR && input.LA(1) <= NTEXT) || input.LA(1) == BINARY ) 
            	{
            	    input.Consume();
            	    adaptor.AddChild(root_0, adaptor.Create(set204));
            	    errorRecovery = false;
            	}
            	else 
            	{
            	    MismatchedSetException mse =
            	        new MismatchedSetException(null,input);
            	    RecoverFromMismatchedSet(input,mse,FOLLOW_set_in_datatypeOneParam2855);    throw mse;
            	}

            	// OQL.g:289:4: ( LPAREN Integer RPAREN )?
            	int alt66 = 2;
            	int LA66_0 = input.LA(1);
            	
            	if ( (LA66_0 == LPAREN) )
            	{
            	    alt66 = 1;
            	}
            	switch (alt66) 
            	{
            	    case 1 :
            	        // OQL.g:289:5: LPAREN Integer RPAREN
            	        {
            	        	LPAREN205 = (IToken)input.LT(1);
            	        	Match(input,LPAREN,FOLLOW_LPAREN_in_datatypeOneParam2887); 
            	        	LPAREN205_tree = (Expression)adaptor.Create(LPAREN205);
            	        	adaptor.AddChild(root_0, LPAREN205_tree);

            	        	Integer206 = (IToken)input.LT(1);
            	        	Match(input,Integer,FOLLOW_Integer_in_datatypeOneParam2889); 
            	        	Integer206_tree = (Expression)adaptor.Create(Integer206);
            	        	adaptor.AddChild(root_0, Integer206_tree);

            	        	RPAREN207 = (IToken)input.LT(1);
            	        	Match(input,RPAREN,FOLLOW_RPAREN_in_datatypeOneParam2891); 
            	        	RPAREN207_tree = (Expression)adaptor.Create(RPAREN207);
            	        	adaptor.AddChild(root_0, RPAREN207_tree);

            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end datatypeOneParam

    public class datatypeNParam_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start datatypeNParam
    // OQL.g:291:1: datatypeNParam : ( DECIMAL ) ( LPAREN Integer ( COMMA Integer )? RPAREN )? ;
    public datatypeNParam_return datatypeNParam() // throws RecognitionException [1]
    {   
        datatypeNParam_return retval = new datatypeNParam_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken DECIMAL208 = null;
        IToken LPAREN209 = null;
        IToken Integer210 = null;
        IToken COMMA211 = null;
        IToken Integer212 = null;
        IToken RPAREN213 = null;
        
        Expression DECIMAL208_tree=null;
        Expression LPAREN209_tree=null;
        Expression Integer210_tree=null;
        Expression COMMA211_tree=null;
        Expression Integer212_tree=null;
        Expression RPAREN213_tree=null;
    
        try 
    	{
            // OQL.g:292:2: ( ( DECIMAL ) ( LPAREN Integer ( COMMA Integer )? RPAREN )? )
            // OQL.g:292:4: ( DECIMAL ) ( LPAREN Integer ( COMMA Integer )? RPAREN )?
            {
            	root_0 = (Expression)adaptor.GetNilNode();
            
            	// OQL.g:292:4: ( DECIMAL )
            	// OQL.g:292:5: DECIMAL
            	{
            		DECIMAL208 = (IToken)input.LT(1);
            		Match(input,DECIMAL,FOLLOW_DECIMAL_in_datatypeNParam2904); 
            		DECIMAL208_tree = (Expression)adaptor.Create(DECIMAL208);
            		adaptor.AddChild(root_0, DECIMAL208_tree);

            	
            	}

            	// OQL.g:293:4: ( LPAREN Integer ( COMMA Integer )? RPAREN )?
            	int alt68 = 2;
            	int LA68_0 = input.LA(1);
            	
            	if ( (LA68_0 == LPAREN) )
            	{
            	    alt68 = 1;
            	}
            	switch (alt68) 
            	{
            	    case 1 :
            	        // OQL.g:293:5: LPAREN Integer ( COMMA Integer )? RPAREN
            	        {
            	        	LPAREN209 = (IToken)input.LT(1);
            	        	Match(input,LPAREN,FOLLOW_LPAREN_in_datatypeNParam2911); 
            	        	LPAREN209_tree = (Expression)adaptor.Create(LPAREN209);
            	        	adaptor.AddChild(root_0, LPAREN209_tree);

            	        	Integer210 = (IToken)input.LT(1);
            	        	Match(input,Integer,FOLLOW_Integer_in_datatypeNParam2913); 
            	        	Integer210_tree = (Expression)adaptor.Create(Integer210);
            	        	adaptor.AddChild(root_0, Integer210_tree);

            	        	// OQL.g:293:20: ( COMMA Integer )?
            	        	int alt67 = 2;
            	        	int LA67_0 = input.LA(1);
            	        	
            	        	if ( (LA67_0 == COMMA) )
            	        	{
            	        	    alt67 = 1;
            	        	}
            	        	switch (alt67) 
            	        	{
            	        	    case 1 :
            	        	        // OQL.g:293:21: COMMA Integer
            	        	        {
            	        	        	COMMA211 = (IToken)input.LT(1);
            	        	        	Match(input,COMMA,FOLLOW_COMMA_in_datatypeNParam2916); 
            	        	        	COMMA211_tree = (Expression)adaptor.Create(COMMA211);
            	        	        	adaptor.AddChild(root_0, COMMA211_tree);

            	        	        	Integer212 = (IToken)input.LT(1);
            	        	        	Match(input,Integer,FOLLOW_Integer_in_datatypeNParam2918); 
            	        	        	Integer212_tree = (Expression)adaptor.Create(Integer212);
            	        	        	adaptor.AddChild(root_0, Integer212_tree);

            	        	        
            	        	        }
            	        	        break;
            	        	
            	        	}

            	        	RPAREN213 = (IToken)input.LT(1);
            	        	Match(input,RPAREN,FOLLOW_RPAREN_in_datatypeNParam2922); 
            	        	RPAREN213_tree = (Expression)adaptor.Create(RPAREN213);
            	        	adaptor.AddChild(root_0, RPAREN213_tree);

            	        
            	        }
            	        break;
            	
            	}

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end datatypeNParam

    public class constant_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start constant
    // OQL.g:296:1: constant : (e1= constant_real -> | e2= constant_int -> | NULL -> | StringLiteral ->);
    public constant_return constant() // throws RecognitionException [1]
    {   
        constant_return retval = new constant_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken NULL214 = null;
        IToken StringLiteral215 = null;
        constant_real_return e1 = null;

        constant_int_return e2 = null;
        
        
        Expression NULL214_tree=null;
        Expression StringLiteral215_tree=null;
        RewriteRuleTokenStream stream_StringLiteral = new RewriteRuleTokenStream(adaptor,"token StringLiteral");
        RewriteRuleTokenStream stream_NULL = new RewriteRuleTokenStream(adaptor,"token NULL");
        RewriteRuleSubtreeStream stream_constant_int = new RewriteRuleSubtreeStream(adaptor,"rule constant_int");
        RewriteRuleSubtreeStream stream_constant_real = new RewriteRuleSubtreeStream(adaptor,"rule constant_real");
        try 
    	{
            // OQL.g:297:2: (e1= constant_real -> | e2= constant_int -> | NULL -> | StringLiteral ->)
            int alt69 = 4;
            switch ( input.LA(1) ) 
            {
            case MINUS:
            	{
                int LA69_1 = input.LA(2);
                
                if ( (LA69_1 == Real) )
                {
                    alt69 = 1;
                }
                else if ( (LA69_1 == Integer) )
                {
                    alt69 = 2;
                }
                else 
                {
                    NoViableAltException nvae_d69s1 =
                        new NoViableAltException("296:1: constant : (e1= constant_real -> | e2= constant_int -> | NULL -> | StringLiteral ->);", 69, 1, input);
                
                    throw nvae_d69s1;
                }
                }
                break;
            case Real:
            	{
                alt69 = 1;
                }
                break;
            case Integer:
            	{
                alt69 = 2;
                }
                break;
            case NULL:
            	{
                alt69 = 3;
                }
                break;
            case StringLiteral:
            	{
                alt69 = 4;
                }
                break;
            	default:
            	    NoViableAltException nvae_d69s0 =
            	        new NoViableAltException("296:1: constant : (e1= constant_real -> | e2= constant_int -> | NULL -> | StringLiteral ->);", 69, 0, input);
            
            	    throw nvae_d69s0;
            }
            
            switch (alt69) 
            {
                case 1 :
                    // OQL.g:297:4: e1= constant_real
                    {
                    	PushFollow(FOLLOW_constant_real_in_constant2938);
                    	e1 = constant_real();
                    	followingStackPointer_--;
                    	
                    	stream_constant_real.Add(e1.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 297:21: ->
                    	{
                    	    adaptor.AddChild(root_0, new Constant(e1.tree));
                    	
                    	}
                    	

                    
                    }
                    break;
                case 2 :
                    // OQL.g:298:4: e2= constant_int
                    {
                    	PushFollow(FOLLOW_constant_int_in_constant2949);
                    	e2 = constant_int();
                    	followingStackPointer_--;
                    	
                    	stream_constant_int.Add(e2.Tree);
                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 298:20: ->
                    	{
                    	    adaptor.AddChild(root_0, new Constant(e2.tree));
                    	
                    	}
                    	

                    
                    }
                    break;
                case 3 :
                    // OQL.g:299:4: NULL
                    {
                    	NULL214 = (IToken)input.LT(1);
                    	Match(input,NULL,FOLLOW_NULL_in_constant2958); 
                    	stream_NULL.Add(NULL214);

                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 299:9: ->
                    	{
                    	    adaptor.AddChild(root_0, new Constant(NULL214));
                    	
                    	}
                    	

                    
                    }
                    break;
                case 4 :
                    // OQL.g:300:4: StringLiteral
                    {
                    	StringLiteral215 = (IToken)input.LT(1);
                    	Match(input,StringLiteral,FOLLOW_StringLiteral_in_constant2967); 
                    	stream_StringLiteral.Add(StringLiteral215);

                    	
                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	retval.tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
                    	
                    	root_0 = (Expression)adaptor.GetNilNode();
                    	// 300:18: ->
                    	{
                    	    adaptor.AddChild(root_0, new Constant(StringLiteral215));
                    	
                    	}
                    	

                    
                    }
                    break;
            
            }
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end constant

    public class constant_real_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start constant_real
    // OQL.g:301:1: constant_real : ( MINUS )? Real -> ^( TextNode ( MINUS )? Real ) ;
    public constant_real_return constant_real() // throws RecognitionException [1]
    {   
        constant_real_return retval = new constant_real_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken MINUS216 = null;
        IToken Real217 = null;
        
        Expression MINUS216_tree=null;
        Expression Real217_tree=null;
        RewriteRuleTokenStream stream_Real = new RewriteRuleTokenStream(adaptor,"token Real");
        RewriteRuleTokenStream stream_MINUS = new RewriteRuleTokenStream(adaptor,"token MINUS");
    
        try 
    	{
            // OQL.g:301:14: ( ( MINUS )? Real -> ^( TextNode ( MINUS )? Real ) )
            // OQL.g:301:16: ( MINUS )? Real
            {
            	// OQL.g:301:16: ( MINUS )?
            	int alt70 = 2;
            	int LA70_0 = input.LA(1);
            	
            	if ( (LA70_0 == MINUS) )
            	{
            	    alt70 = 1;
            	}
            	switch (alt70) 
            	{
            	    case 1 :
            	        // OQL.g:301:16: MINUS
            	        {
            	        	MINUS216 = (IToken)input.LT(1);
            	        	Match(input,MINUS,FOLLOW_MINUS_in_constant_real2977); 
            	        	stream_MINUS.Add(MINUS216);

            	        
            	        }
            	        break;
            	
            	}

            	Real217 = (IToken)input.LT(1);
            	Match(input,Real,FOLLOW_Real_in_constant_real2980); 
            	stream_Real.Add(Real217);

            	
            	// AST REWRITE
            	// elements:          MINUS, Real
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 301:28: -> ^( TextNode ( MINUS )? Real )
            	{
            	    // OQL.g:301:31: ^( TextNode ( MINUS )? Real )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_1);
            	    
            	    // OQL.g:301:42: ( MINUS )?
            	    if ( stream_MINUS.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_MINUS.Next());
            	    
            	    }
            	    stream_MINUS.Reset();
            	    adaptor.AddChild(root_1, stream_Real.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end constant_real

    public class constant_int_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start constant_int
    // OQL.g:302:1: constant_int : ( MINUS )? Integer -> ^( TextNode ( MINUS )? Integer ) ;
    public constant_int_return constant_int() // throws RecognitionException [1]
    {   
        constant_int_return retval = new constant_int_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken MINUS218 = null;
        IToken Integer219 = null;
        
        Expression MINUS218_tree=null;
        Expression Integer219_tree=null;
        RewriteRuleTokenStream stream_MINUS = new RewriteRuleTokenStream(adaptor,"token MINUS");
        RewriteRuleTokenStream stream_Integer = new RewriteRuleTokenStream(adaptor,"token Integer");
    
        try 
    	{
            // OQL.g:302:13: ( ( MINUS )? Integer -> ^( TextNode ( MINUS )? Integer ) )
            // OQL.g:302:15: ( MINUS )? Integer
            {
            	// OQL.g:302:15: ( MINUS )?
            	int alt71 = 2;
            	int LA71_0 = input.LA(1);
            	
            	if ( (LA71_0 == MINUS) )
            	{
            	    alt71 = 1;
            	}
            	switch (alt71) 
            	{
            	    case 1 :
            	        // OQL.g:302:15: MINUS
            	        {
            	        	MINUS218 = (IToken)input.LT(1);
            	        	Match(input,MINUS,FOLLOW_MINUS_in_constant_int2997); 
            	        	stream_MINUS.Add(MINUS218);

            	        
            	        }
            	        break;
            	
            	}

            	Integer219 = (IToken)input.LT(1);
            	Match(input,Integer,FOLLOW_Integer_in_constant_int3000); 
            	stream_Integer.Add(Integer219);

            	
            	// AST REWRITE
            	// elements:          MINUS, Integer
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 302:30: -> ^( TextNode ( MINUS )? Integer )
            	{
            	    // OQL.g:302:33: ^( TextNode ( MINUS )? Integer )
            	    {
            	    Expression root_1 = (Expression)adaptor.GetNilNode();
            	    root_1 = (Expression)adaptor.BecomeRoot(adaptor.Create(TextNode, "TextNode"), root_1);
            	    
            	    // OQL.g:302:44: ( MINUS )?
            	    if ( stream_MINUS.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_MINUS.Next());
            	    
            	    }
            	    stream_MINUS.Reset();
            	    adaptor.AddChild(root_1, stream_Integer.Next());
            	    
            	    adaptor.AddChild(root_0, root_1);
            	    }
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end constant_int

    public class userVariable_return : ParserRuleReturnScope 
    {
        internal Expression tree;
        override public object Tree
        {
        	get { return tree; }
        }
    };
    
    // $ANTLR start userVariable
    // OQL.g:303:1: userVariable : UserVariable ->;
    public userVariable_return userVariable() // throws RecognitionException [1]
    {   
        userVariable_return retval = new userVariable_return();
        retval.start = input.LT(1);
        
        Expression root_0 = null;
    
        IToken UserVariable220 = null;
        
        Expression UserVariable220_tree=null;
        RewriteRuleTokenStream stream_UserVariable = new RewriteRuleTokenStream(adaptor,"token UserVariable");
    
        try 
    	{
            // OQL.g:303:13: ( UserVariable ->)
            // OQL.g:303:15: UserVariable
            {
            	UserVariable220 = (IToken)input.LT(1);
            	Match(input,UserVariable,FOLLOW_UserVariable_in_userVariable3017); 
            	stream_UserVariable.Add(UserVariable220);

            	
            	// AST REWRITE
            	// elements:          
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	retval.tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "token retval", (retval!=null ? retval.Tree : null));
            	
            	root_0 = (Expression)adaptor.GetNilNode();
            	// 303:28: ->
            	{
            	    adaptor.AddChild(root_0, new UserVariable(UserVariable220));
            	
            	}
            	

            
            }
    
            retval.stop = input.LT(-1);
            
            	retval.tree = (Expression)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, retval.start, retval.stop);
    
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
        }
        finally 
    	{
        }
        return retval;
    }
    // $ANTLR end userVariable


	private void InitializeCyclicDFAs()
	{
	}

 

    public static readonly BitSet FOLLOW_statements_in_start938 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_statement_in_statements947 = new BitSet(new ulong[]{0x2001001004000000UL,0x0000000000000022UL});
    public static readonly BitSet FOLLOW_SEMI_in_statements950 = new BitSet(new ulong[]{0x2001001000000000UL,0x0000000000000022UL});
    public static readonly BitSet FOLLOW_EOF_in_statements957 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_selectStatement_in_statement971 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_updateStatement_in_statement976 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_deleteStatement_in_statement981 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_insertStatement_in_statement986 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_select_1_in_selectStatement999 = new BitSet(new ulong[]{0x0400000000000002UL,0x0000000000000001UL});
    public static readonly BitSet FOLLOW_UNION_in_selectStatement1002 = new BitSet(new ulong[]{0x2000000010000000UL});
    public static readonly BitSet FOLLOW_ALL_in_selectStatement1004 = new BitSet(new ulong[]{0x2000000000000000UL});
    public static readonly BitSet FOLLOW_select_2_in_selectStatement1007 = new BitSet(new ulong[]{0x0400000000000002UL,0x0000000000000001UL});
    public static readonly BitSet FOLLOW_orderBy_in_selectStatement1013 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_select_in_select_11080 = new BitSet(new ulong[]{0x0000180000000002UL,0x0000000000000010UL});
    public static readonly BitSet FOLLOW_from_in_select_11082 = new BitSet(new ulong[]{0x0000100000000002UL,0x0000000000000010UL});
    public static readonly BitSet FOLLOW_where_in_select_11085 = new BitSet(new ulong[]{0x0000100000000002UL});
    public static readonly BitSet FOLLOW_groupBy_in_select_11088 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_select_1_in_select_21095 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_LPAREN_in_subQuery1102 = new BitSet(new ulong[]{0x2000000000000000UL});
    public static readonly BitSet FOLLOW_selectStatement_in_subQuery1104 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_subQuery1106 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_update_in_updateStatement1117 = new BitSet(new ulong[]{0x0000080000000002UL,0x0000000000000010UL});
    public static readonly BitSet FOLLOW_from_in_updateStatement1119 = new BitSet(new ulong[]{0x0000000000000002UL,0x0000000000000010UL});
    public static readonly BitSet FOLLOW_where_in_updateStatement1122 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_delete_in_deleteStatement1129 = new BitSet(new ulong[]{0x0000000000000002UL,0x0000000000000010UL});
    public static readonly BitSet FOLLOW_where_in_deleteStatement1131 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_truncate_in_deleteStatement1136 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_insert_in_insertStatement1142 = new BitSet(new ulong[]{0x2000000000000000UL,0x0000000000000004UL});
    public static readonly BitSet FOLLOW_values_in_insertStatement1145 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_selectStatement_in_insertStatement1149 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_SELECT_in_select1162 = new BitSet(new ulong[]{0x0080004400418000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_DISTINCT_in_select1164 = new BitSet(new ulong[]{0x0080000400418000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_columns_in_select1167 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_FROM_in_from1189 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_tables_in_from1192 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_WHERE_in_where1199 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_condition_in_where1201 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_ORDER_in_orderBy1221 = new BitSet(new ulong[]{0x0000000200000000UL});
    public static readonly BitSet FOLLOW_BY_in_orderBy1223 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_orderBy_1_in_orderBy1225 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_COMMA_in_orderBy1228 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_orderBy_1_in_orderBy1230 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_expressions_in_orderBy_11259 = new BitSet(new ulong[]{0x0000002080000002UL});
    public static readonly BitSet FOLLOW_ASC_in_orderBy_11267 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_DESC_in_orderBy_11276 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_GROUP_in_groupBy1337 = new BitSet(new ulong[]{0x0000000200000000UL});
    public static readonly BitSet FOLLOW_BY_in_groupBy1339 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_groupBy1341 = new BitSet(new ulong[]{0x0000200002000002UL});
    public static readonly BitSet FOLLOW_COMMA_in_groupBy1344 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_groupBy1346 = new BitSet(new ulong[]{0x0000200002000002UL});
    public static readonly BitSet FOLLOW_having_in_groupBy1350 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_HAVING_in_having1376 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_condition_in_having1379 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_UPDATE_in_update1387 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_update1389 = new BitSet(new ulong[]{0x4000000000000000UL});
    public static readonly BitSet FOLLOW_SET_in_update1391 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_update1393 = new BitSet(new ulong[]{0x0000000000000010UL});
    public static readonly BitSet FOLLOW_Eq_in_update1395 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_update1397 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_update_1_in_update1399 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_COMMA_in_update_11438 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_update_11440 = new BitSet(new ulong[]{0x0000000000000010UL});
    public static readonly BitSet FOLLOW_Eq_in_update_11442 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_update_11444 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_DELETE_in_delete1467 = new BitSet(new ulong[]{0x0000080000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_FROM_in_delete1469 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_delete1472 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_TRUNCATE_in_truncate1495 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_truncate1497 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_INSERT_in_insert1517 = new BitSet(new ulong[]{0x0002000000000000UL});
    public static readonly BitSet FOLLOW_INTO_in_insert1519 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_insert1521 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_LPAREN_in_insert1523 = new BitSet(new ulong[]{0x0000000000800000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_insert1526 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_COMMA_in_insert1529 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_insert1531 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_insert1537 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_VALUES_in_values1543 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_LPAREN_in_values1545 = new BitSet(new ulong[]{0x0080000400C08000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_values1548 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_COMMA_in_values1551 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_values1553 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_values1559 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_column_in_columns1565 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_COMMA_in_columns1569 = new BitSet(new ulong[]{0x0080000400418000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_column_in_columns1571 = new BitSet(new ulong[]{0x0000000002000002UL});
    public static readonly BitSet FOLLOW_MUL_in_column1588 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_identifier_in_column1604 = new BitSet(new ulong[]{0x0000000008000000UL});
    public static readonly BitSet FOLLOW_DOT_in_column1606 = new BitSet(new ulong[]{0x0000000000010000UL});
    public static readonly BitSet FOLLOW_MUL_in_column1608 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_expressions_in_column1631 = new BitSet(new ulong[]{0x0000000040000002UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_columnAlias_in_column1633 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_table_in_tables1659 = new BitSet(new ulong[]{0x1010800802000002UL});
    public static readonly BitSet FOLLOW_tables_0_in_tables1661 = new BitSet(new ulong[]{0x1010800802000002UL});
    public static readonly BitSet FOLLOW_COMMA_in_tables_01669 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_tables_01671 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_join_in_tables_01679 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_subQuery_in_table1696 = new BitSet(new ulong[]{0x0000000040000002UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_tableAlias_in_table1698 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_identifier_in_table1719 = new BitSet(new ulong[]{0x0000000040000002UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_tableAlias_in_table1721 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_CROSS_in_join1765 = new BitSet(new ulong[]{0x0008000000000000UL});
    public static readonly BitSet FOLLOW_JOIN_in_join1767 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_join1769 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_INNER_in_join1779 = new BitSet(new ulong[]{0x0008000000000000UL});
    public static readonly BitSet FOLLOW_LEFT_in_join1788 = new BitSet(new ulong[]{0x0808000000000000UL});
    public static readonly BitSet FOLLOW_RIGHT_in_join1796 = new BitSet(new ulong[]{0x0808000000000000UL});
    public static readonly BitSet FOLLOW_OUTER_in_join1802 = new BitSet(new ulong[]{0x0008000000000000UL});
    public static readonly BitSet FOLLOW_JOIN_in_join1806 = new BitSet(new ulong[]{0x0000000000400000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_table_in_join1808 = new BitSet(new ulong[]{0x0100000000000002UL});
    public static readonly BitSet FOLLOW_ON_in_join1811 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_condition_in_join1813 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_AS_in_columnAlias1946 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_columnAlias1949 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_AS_in_tableAlias1967 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000C00000UL});
    public static readonly BitSet FOLLOW_identifier_in_tableAlias1970 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_subCondition_in_condition1984 = new BitSet(new ulong[]{0x0200000020000002UL});
    public static readonly BitSet FOLLOW_AND_in_condition1988 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_OR_in_condition1994 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_subCondition_in_condition1999 = new BitSet(new ulong[]{0x0200000020000002UL});
    public static readonly BitSet FOLLOW_NOT_in_subCondition2011 = new BitSet(new ulong[]{0x0080020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_LPAREN_in_subCondition2022 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_condition_in_subCondition2024 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_subCondition2026 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_predicate_in_subCondition2037 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_expressions_in_predicate2099 = new BitSet(new ulong[]{0x0064400100001FF0UL});
    public static readonly BitSet FOLLOW_comparisonOperator_in_predicate2102 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_predicate2105 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_IS_in_predicate2127 = new BitSet(new ulong[]{0x00C0000000000000UL});
    public static readonly BitSet FOLLOW_NOT_in_predicate2130 = new BitSet(new ulong[]{0x0080000000000000UL});
    public static readonly BitSet FOLLOW_NULL_in_predicate2134 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NOT_in_predicate2164 = new BitSet(new ulong[]{0x0000400000000000UL});
    public static readonly BitSet FOLLOW_IN_in_predicate2167 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_LPAREN_in_predicate2169 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_0_in_predicate2171 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_COMMA_in_predicate2174 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_1_in_predicate2176 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_predicate2180 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NOT_in_predicate2210 = new BitSet(new ulong[]{0x0000400000000000UL});
    public static readonly BitSet FOLLOW_IN_in_predicate2213 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_subQuery_in_predicate2215 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NOT_in_predicate2242 = new BitSet(new ulong[]{0x0000000100000000UL});
    public static readonly BitSet FOLLOW_BETWEEN_in_predicate2245 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_predicate2247 = new BitSet(new ulong[]{0x0000000020000000UL});
    public static readonly BitSet FOLLOW_AND_in_predicate2249 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_predicate2251 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_EXISTS_in_predicate2289 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_subQuery_in_predicate2291 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_expression_in_expressions2308 = new BitSet(new ulong[]{0x000000000003E002UL});
    public static readonly BitSet FOLLOW_mathOperator_in_expressions2311 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expression_in_expressions2313 = new BitSet(new ulong[]{0x000000000003E002UL});
    public static readonly BitSet FOLLOW_expressions_in_expressions_02322 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_expressions_in_expressions_12328 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_function_in_expression2345 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_constant_in_expression2364 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_userVariable_in_expression2374 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_identifier_in_expression2383 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_subQuery_in_expression2392 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_set_in_mathOperator0 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_set_in_comparisonOperator0 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_systemFunction_in_function2494 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_userFunction_in_function2498 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_identifier_in_userFunction2507 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_LPAREN_in_userFunction2509 = new BitSet(new ulong[]{0x0080000400C08000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_userFunction2512 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_COMMA_in_userFunction2515 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_0_in_userFunction2517 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_userFunction2523 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_fnCase_in_systemFunction2550 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_unitarySysFun_in_systemFunction2554 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_fnLen_in_systemFunction2558 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_CASE_in_fnCase2571 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC8UL});
    public static readonly BitSet FOLLOW_expressions_in_fnCase2586 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000000000008UL});
    public static readonly BitSet FOLLOW_WHEN_in_fnCase2589 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_fnCase2591 = new BitSet(new ulong[]{0x8000000000000000UL});
    public static readonly BitSet FOLLOW_THEN_in_fnCase2593 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_fnCase2595 = new BitSet(new ulong[]{0x0000018000000000UL,0x0000000000000008UL});
    public static readonly BitSet FOLLOW_WHEN_in_fnCase2610 = new BitSet(new ulong[]{0x00C0020400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_condition_in_fnCase2612 = new BitSet(new ulong[]{0x8000000000000000UL});
    public static readonly BitSet FOLLOW_THEN_in_fnCase2614 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_fnCase2616 = new BitSet(new ulong[]{0x0000018000000000UL,0x0000000000000008UL});
    public static readonly BitSet FOLLOW_ELSE_in_fnCase2639 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_fnCase2641 = new BitSet(new ulong[]{0x0000010000000000UL});
    public static readonly BitSet FOLLOW_END_in_fnCase2645 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_LEN_in_fnLen2658 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_LPAREN_in_fnLen2660 = new BitSet(new ulong[]{0x0080000400408000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_expressions_in_fnLen2662 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_fnLen2664 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_SUM_in_unitarySysFun2684 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_AVG_in_unitarySysFun2689 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_MAX_in_unitarySysFun2694 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_MIN_in_unitarySysFun2699 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_COUNT_in_unitarySysFun2704 = new BitSet(new ulong[]{0x0000000000400000UL});
    public static readonly BitSet FOLLOW_unitarySysFun_0_in_unitarySysFun2708 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_LPAREN_in_unitarySysFun_02718 = new BitSet(new ulong[]{0x0080000400C18000UL,0x000000000FC00FC0UL});
    public static readonly BitSet FOLLOW_MUL_in_unitarySysFun_02722 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_expressions_in_unitarySysFun_02730 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_unitarySysFun_02737 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_QuotedIdentifier_in_identifier2777 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NonQuotedIdentifier_in_identifier2786 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_datatypeNParam_in_datatype2800 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_datatypeOneParam_in_datatype2813 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_datatypeNoParam_in_datatype2826 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_set_in_datatypeNoParam0 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_set_in_datatypeOneParam2855 = new BitSet(new ulong[]{0x0000000000400002UL});
    public static readonly BitSet FOLLOW_LPAREN_in_datatypeOneParam2887 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000001000000UL});
    public static readonly BitSet FOLLOW_Integer_in_datatypeOneParam2889 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_datatypeOneParam2891 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_DECIMAL_in_datatypeNParam2904 = new BitSet(new ulong[]{0x0000000000400002UL});
    public static readonly BitSet FOLLOW_LPAREN_in_datatypeNParam2911 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000001000000UL});
    public static readonly BitSet FOLLOW_Integer_in_datatypeNParam2913 = new BitSet(new ulong[]{0x0000000002800000UL});
    public static readonly BitSet FOLLOW_COMMA_in_datatypeNParam2916 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000001000000UL});
    public static readonly BitSet FOLLOW_Integer_in_datatypeNParam2918 = new BitSet(new ulong[]{0x0000000000800000UL});
    public static readonly BitSet FOLLOW_RPAREN_in_datatypeNParam2922 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_constant_real_in_constant2938 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_constant_int_in_constant2949 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NULL_in_constant2958 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_StringLiteral_in_constant2967 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_MINUS_in_constant_real2977 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000004000000UL});
    public static readonly BitSet FOLLOW_Real_in_constant_real2980 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_MINUS_in_constant_int2997 = new BitSet(new ulong[]{0x0000000000000000UL,0x0000000001000000UL});
    public static readonly BitSet FOLLOW_Integer_in_constant_int3000 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_UserVariable_in_userVariable3017 = new BitSet(new ulong[]{0x0000000000000002UL});

}
}