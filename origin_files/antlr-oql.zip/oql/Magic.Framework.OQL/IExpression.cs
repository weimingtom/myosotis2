﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Magic.Framework.OQL
{
    public interface IExpression
    {
        void VisitSql(ISqlVisitor visitor);
        void VisitCompile(ICompileVisitor visitor);
    }
}
