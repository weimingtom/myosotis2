﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 5, 2008
//===============================================================================

using System.Collections;
using System.Collections.Generic;

namespace Magic.Framework.OQL
{
    /// <summary>
    /// An {nullable} enumerator for <see cref="ASTToken"/>, to provide consistency for operations on <see cref="IExpression"/>.
    /// </summary>
    public class ExpressionEnumerator : IEnumerator<Expression>
    {
        private Expression _target;
        private int _index = -1;

        internal ExpressionEnumerator(Expression exp)
        {
            this._target = exp;
        }

        /// <summary>
        /// 
        /// </summary>
        public Expression Current
        {
            get
            {
                return this._target.GetChild(this._index);
            }
        }
        object IEnumerator.Current
        {
            get
            {
                return this.Current;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool MoveNext()
        {
            this._index++;
            return this._target != null && this._index >= 0 && this._index < this._target.ChildCount;
        }
        /// <summary>
        /// 
        /// </summary>
        public void Reset()
        {
            this._index = -1;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            this._target = null;
        }
    }
}
