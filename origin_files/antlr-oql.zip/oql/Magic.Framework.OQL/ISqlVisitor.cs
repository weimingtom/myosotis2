﻿using System.Collections.Generic;

namespace Magic.Framework.OQL
{
    [System.Flags]
    public enum RequiredClause
    {
        /// <summary>
        /// Build all OQL clauses for ISqlVisitor
        /// </summary>
        All = 0x3E,
        /// <summary>
        /// Build select clause for ISqlVisitor
        /// </summary>
        Select = 0x02,
        /// <summary>
        /// Build from clause for ISqlVisitor
        /// </summary>
        From = 0x04,
        /// <summary>
        /// Build where rom clause for ISqlVisitor
        /// </summary>
        Where = 0x08,
        /// <summary>
        /// Build group by clause for ISqlVisitor
        /// </summary>
        GroupBy = 0x10,
        /// <summary>
        /// Build order by clause for ISqlVisitor
        /// </summary>
        OrderBy = 0x20,
    }

    public interface ISqlVisitor
    {
        /// <summary>
        /// Output sql text.
        /// </summary>
        /// <param name="sql"></param>
        void Sql(string sql);
        /// <summary>
        /// Output named variable.
        /// </summary>
        /// <param name="varName"></param>
        void NamedVariable(string varName);
        /// <summary>
        /// Output positioned variable.
        /// </summary>
        /// <param name="index"></param>
        void PositionedVariable(int index);
        /// <summary>
        /// Output object: table name or column name.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="alias"></param>
        void Table(string name);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="name"></param>
        /// <param name="guess">
        /// <para>false: The column name is from a select, insert, update list, it's mostly a true column name</para>
        /// <para>true: The column name is from other clauses, it maybe a true column name, or an alias.</para>
        /// </param>
        void Column(string table, string name, bool iAmSure);
        /// <summary>
        /// The column maybe comes from the <paramref name="tables"/>
        /// </summary>
        /// <param name="tables"></param>
        /// <param name="name"></param>
        void Column(IList<string> tables, string name);
        /// <summary>
        /// Request add a white space
        /// </summary>
        void Space();
        /// <summary>
        /// Which clauses the ISqlVisitor is requesting for.
        /// </summary>
        RequiredClause ClauseFlag { get; }
    }
}
