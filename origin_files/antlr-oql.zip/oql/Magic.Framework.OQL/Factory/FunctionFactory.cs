﻿//===============================================================================
// Magic OQL
//===============================================================================
// Copyright ?Magic Thought Corporation. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================
// Richie (http://www.cnblogs.com/RicCC)
// March 8, 2008
//===============================================================================

using Antlr.Runtime;
using Magic.Framework.OQL.Expressions.Function;

namespace Magic.Framework.OQL.Factory
{
    public class FunctionFactory : IExpressionFactory
    {
        public Expression Create(IToken token)
        {
            if (token == null) return new Expression(token);
            switch (token.Type)
            {
                case OQLParser.UserFunction:
                    return new UserFunction(token);
                case OQLParser.SUM:
                    return new Sum(token);
                case OQLParser.COUNT:
                    return new Count(token);
                case OQLParser.MIN:
                    return new Min(token);
                case OQLParser.MAX:
                    return new Max(token);
                case OQLParser.AVG:
                    return new Avg(token);
                //case OQLParser.CAST:
                //    return new Cast(token);
                //case OQLParser.CONVERT:
                //    return new Convert(token);
                case OQLParser.CASE:
                    return new Case(token);
                case OQLParser.LEN:
                    return new Len(token);
                default:
                    return new Expression();
            }
        }
    }
}