#ifdef	VM_ENUMDEF
#define	VMCODE0(code_, name_)	code_,
#define	VMCODE1(code_, name_)	code_,
#endif
#ifdef	VM_CREATE
#define	VMCODE0(code_, name_)	void name_()			{ statement.push_back(CVMCode(code_)); }
#define	VMCODE1(code_, name_)	void name_(int arg1)	{ statement.push_back(CVMCode(code_, arg1)); }
#endif
#ifdef	VM_EXEC
#define	VMCODE0(code_, name_)	void name_();
#define	VMCODE1(code_, name_)	void name_();
#endif
#ifdef	VM_EXECTABLE
#define	VMCODE0(code_, name_)	&vcpu::name_,
#define	VMCODE1(code_, name_)	&vcpu::name_,
#endif
#ifdef	VM_NAMETABLE
#define	VMCODE0(code_, name_)	#name_,
#define	VMCODE1(code_, name_)	#name_,
#endif

VMCODE1(VM_PUSHCONST,			PushConst)
VMCODE1(VM_PUSHVALUE,			PushValue)
VMCODE1(VM_POPVALUE,			PopValue)
VMCODE0(VM_POP,					OpPop)
VMCODE0(VM_NEG,					OpNeg)
VMCODE0(VM_EQ,					OpEq)
VMCODE0(VM_NE,					OpNe)
VMCODE0(VM_GT,					OpGt)
VMCODE0(VM_GE,					OpGe)
VMCODE0(VM_LT,					OpLt)
VMCODE0(VM_LE,					OpLe)
VMCODE0(VM_ADD,					OpAdd)
VMCODE0(VM_SUB,					OpSub)
VMCODE0(VM_MUL,					OpMul)
VMCODE0(VM_DIV,					OpDiv)
VMCODE0(VM_MOD,					OpMod)
VMCODE1(VM_JMP,					OpJmp)
VMCODE1(VM_JMPC,				OpJmpC)
VMCODE1(VM_JMPNC,				OpJmpNC)
VMCODE1(VM_PRINT,				OpPrint)
VMCODE0(VM_RAND,				OpRand)
VMCODE0(VM_HALT,				OpHalt)

#undef	VMCODE0
#undef	VMCODE1
