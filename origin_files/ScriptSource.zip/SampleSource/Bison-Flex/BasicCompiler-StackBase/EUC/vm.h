#ifndef	__VM_H__
#define	__VM_H__

#include <vector>
#include "vm_value.h"

#define	VM_ENUMDEF
enum	{
#include "vm_code.h"
	VM_MAXCOMMAND,
} ;
#undef	VM_ENUMDEF

namespace vm {

	class data {
	  public:
		data(): command_(0)
		{
		}
		~data()
		{
			delete[] command_;
		}

	  public:
		unsigned char *command_;	// ���ޥ�ɥơ��֥�
		int command_size_;			// ���ޥ�ɥ�����
		int value_size_;			// �������Х��ѿ�������
	} ;

	class vcpu {
	  public:
		const static int STACK_SIZE = 1000;

	  public:
		vcpu(data &mem)
			: data_(mem)
		{
		}
		~vcpu()
		{
		}

		int run();

	  private:
#define	VM_EXEC
#include "vm_code.h"
#undef	VM_EXEC

	  private:
		int value() { int v = *(int *)command_ptr_; command_ptr_ += 4; return v; }
		int addr() const { return (int)(command_ptr_ - command_); }
		void jmp(int addr) { command_ptr_ = command_ + addr; }
		void push(int v) { stack.push(v); }
		void pop() { stack.pop(); }
		const int top() const { return stack.top(); }
		int &top() { return stack.top(); }

	  private:
		data &data_;
		unsigned char *command_;
		unsigned char *command_ptr_;
		int command_size_;
		bool active;

		vm::stack<int, STACK_SIZE> stack;
		std::vector<int> global_value;

		static void (vcpu::*cmd_[])();
	} ;

}

#endif
