#include <iostream>
#include "compiler.h"
#include "vm.h"

int main(int argc, char *argv[])
{
	for (++argv; argv[0]; ++argv) {
		vm::data data;
		bool compile_result;
		{
			compiler driver;
			compile_result = driver.compile(*argv, data);
#ifdef	_DEBUG
			if (compile_result)
				driver.debug_dump();
#endif
		}
		if (compile_result) {
			vm::vcpu machine(data);
			int result = machine.run();
			std::cout << "result = " << result << std::endl;
		}
	}
	return 0;
}
