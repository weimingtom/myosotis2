/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison LALR(1) parsers in C++

   Copyright (C) 2002, 2003, 2004, 2005, 2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


#include "script-parser.hh"

/* User implementation prologue.  */
#line 44 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"

#include "compiler.h"


/* Line 317 of lalr1.cc.  */
#line 46 "script-parser.cc"

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* FIXME: INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#define YYUSE(e) ((void) (e))

/* A pseudo ostream that takes yydebug_ into account.  */
# define YYCDEBUG							\
  for (bool yydebugcond_ = yydebug_; yydebugcond_; yydebugcond_ = false)	\
    (*yycdebug_)

/* Enable debugging if requested.  */
#if YYDEBUG

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)	\
do {							\
  if (yydebug_)						\
    {							\
      *yycdebug_ << Title << ' ';			\
      yy_symbol_print_ ((Type), (Value), (Location));	\
      *yycdebug_ << std::endl;				\
    }							\
} while (false)

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug_)				\
    yy_reduce_print_ (Rule);		\
} while (false)

# define YY_STACK_PRINT()		\
do {					\
  if (yydebug_)				\
    yystack_print_ ();			\
} while (false)

#else /* !YYDEBUG */

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_REDUCE_PRINT(Rule)
# define YY_STACK_PRINT()

#endif /* !YYDEBUG */

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab

namespace yy
{
#if YYERROR_VERBOSE

  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  script_parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr = "";
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              /* Fall through.  */
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }

#endif

  /// Build a parser object.
  script_parser::script_parser (compiler& driver_yyarg)
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
      driver (driver_yyarg)
  {
  }

  script_parser::~script_parser ()
  {
  }

#if YYDEBUG
  /*--------------------------------.
  | Print this symbol on YYOUTPUT.  |
  `--------------------------------*/

  inline void
  script_parser::yy_symbol_value_print_ (int yytype,
			   const semantic_type* yyvaluep, const location_type* yylocationp)
  {
    YYUSE (yylocationp);
    YYUSE (yyvaluep);
    switch (yytype)
      {
         default:
	  break;
      }
  }


  void
  script_parser::yy_symbol_print_ (int yytype,
			   const semantic_type* yyvaluep, const location_type* yylocationp)
  {
    *yycdebug_ << (yytype < yyntokens_ ? "token" : "nterm")
	       << ' ' << yytname_[yytype] << " ("
	       << *yylocationp << ": ";
    yy_symbol_value_print_ (yytype, yyvaluep, yylocationp);
    *yycdebug_ << ')';
  }
#endif /* ! YYDEBUG */

  void
  script_parser::yydestruct_ (const char* yymsg,
			   int yytype, semantic_type* yyvaluep, location_type* yylocationp)
  {
    YYUSE (yylocationp);
    YYUSE (yymsg);
    YYUSE (yyvaluep);

    YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

    switch (yytype)
      {
        case 4: /* "\"identifier\"" */
#line 92 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->sval); };
#line 206 "script-parser.cc"
	break;
      case 5: /* "\"sval\"" */
#line 93 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->sval); };
#line 211 "script-parser.cc"
	break;
      case 55: /* "value_list" */
#line 95 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->value_list); };
#line 216 "script-parser.cc"
	break;
      case 56: /* "arglist" */
#line 96 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->arglist); };
#line 221 "script-parser.cc"
	break;
      case 57: /* "arg" */
#line 97 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->argdef); };
#line 226 "script-parser.cc"
	break;
      case 60: /* "block" */
#line 101 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->block); };
#line 231 "script-parser.cc"
	break;
      case 61: /* "decl_list" */
#line 98 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->decls); };
#line 236 "script-parser.cc"
	break;
      case 62: /* "state_list" */
#line 99 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->states); };
#line 241 "script-parser.cc"
	break;
      case 63: /* "decls" */
#line 98 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->decls); };
#line 246 "script-parser.cc"
	break;
      case 64: /* "states" */
#line 99 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->states); };
#line 251 "script-parser.cc"
	break;
      case 65: /* "statement" */
#line 103 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->statement); };
#line 256 "script-parser.cc"
	break;
      case 66: /* "assign" */
#line 102 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->assign); };
#line 261 "script-parser.cc"
	break;
      case 67: /* "expr" */
#line 105 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->expr); };
#line 266 "script-parser.cc"
	break;
      case 68: /* "value" */
#line 104 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->value); };
#line 271 "script-parser.cc"
	break;
      case 69: /* "args" */
#line 100 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
	{ delete (yyvaluep->args); };
#line 276 "script-parser.cc"
	break;

	default:
	  break;
      }
  }

  void
  script_parser::yypop_ (unsigned int n)
  {
    yystate_stack_.pop (n);
    yysemantic_stack_.pop (n);
    yylocation_stack_.pop (n);
  }

  std::ostream&
  script_parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  script_parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  script_parser::debug_level_type
  script_parser::debug_level () const
  {
    return yydebug_;
  }

  void
  script_parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }


  int
  script_parser::parse ()
  {
    /// Look-ahead and look-ahead in internal form.
    int yychar = yyempty_;
    int yytoken = 0;

    /* State.  */
    int yyn;
    int yylen = 0;
    int yystate = 0;

    /* Error handling.  */
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// Semantic value of the look-ahead.
    semantic_type yylval;
    /// Location of the look-ahead.
    location_type yylloc;
    /// The locations where the error started and ended.
    location yyerror_range[2];

    /// $$.
    semantic_type yyval;
    /// @$.
    location_type yyloc;

    int yyresult;

    YYCDEBUG << "Starting parse" << std::endl;


    /* User initialization code.  */
    #line 19 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
{
	// ���P�[�V����������
	yylloc.begin.filename = yylloc.end.filename = &driver.get_filename();
}
  /* Line 555 of yacc.c.  */
#line 358 "script-parser.cc"
    /* Initialize the stacks.  The initial state will be pushed in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystate_stack_ = state_stack_type (0);
    yysemantic_stack_ = semantic_stack_type (0);
    yylocation_stack_ = location_stack_type (0);
    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yylloc);

    /* New state.  */
  yynewstate:
    yystate_stack_.push (yystate);
    YYCDEBUG << "Entering state " << yystate << std::endl;
    goto yybackup;

    /* Backup.  */
  yybackup:

    /* Try to take a decision without look-ahead.  */
    yyn = yypact_[yystate];
    if (yyn == yypact_ninf_)
      goto yydefault;

    /* Read a look-ahead token.  */
    if (yychar == yyempty_)
      {
	YYCDEBUG << "Reading a token: ";
	yychar = yylex (&yylval, &yylloc, driver);
      }


    /* Convert token to internal form.  */
    if (yychar <= yyeof_)
      {
	yychar = yytoken = yyeof_;
	YYCDEBUG << "Now at end of input." << std::endl;
      }
    else
      {
	yytoken = yytranslate_ (yychar);
	YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
      }

    /* If the proper action on seeing token YYTOKEN is to reduce or to
       detect an error, take that action.  */
    yyn += yytoken;
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yytoken)
      goto yydefault;

    /* Reduce or error.  */
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
	if (yyn == 0 || yyn == yytable_ninf_)
	goto yyerrlab;
	yyn = -yyn;
	goto yyreduce;
      }

    /* Accept?  */
    if (yyn == yyfinal_)
      goto yyacceptlab;

    /* Shift the look-ahead token.  */
    YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

    /* Discard the token being shifted unless it is eof.  */
    if (yychar != yyeof_)
      yychar = yyempty_;

    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yylloc);

    /* Count tokens shifted since error; after three, turn off error
       status.  */
    if (yyerrstatus_)
      --yyerrstatus_;

    yystate = yyn;
    goto yynewstate;

  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[yystate];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;

  /*-----------------------------.
  | yyreduce -- Do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    /* If YYLEN is nonzero, implement the default value of the action:
       `$$ = $1'.  Otherwise, use the top of the stack.

       Otherwise, the following line sets YYVAL to garbage.
       This behavior is undocumented and Bison
       users should not rely upon it.  */
    if (yylen)
      yyval = yysemantic_stack_[yylen - 1];
    else
      yyval = yysemantic_stack_[0];

    {
      slice<location_type, location_stack_type> slice (yylocation_stack_, yylen);
      YYLLOC_DEFAULT (yyloc, slice, yylen);
    }
    YY_REDUCE_PRINT (yyn);
    switch (yyn)
      {
	  case 7:
#line 127 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.DefineValue((yylocation_stack_[(3) - (2)]), (yysemantic_stack_[(3) - (1)].type), (yysemantic_stack_[(3) - (2)].value_list)); ;}
    break;

  case 8:
#line 128 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.DefineFunction((yylocation_stack_[(5) - (2)]), (yysemantic_stack_[(5) - (1)].type), (yysemantic_stack_[(5) - (2)].sval), NULL); ;}
    break;

  case 9:
#line 129 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.DefineFunction((yylocation_stack_[(6) - (2)]), (yysemantic_stack_[(6) - (1)].type), (yysemantic_stack_[(6) - (2)].sval), (yysemantic_stack_[(6) - (4)].arglist)); ;}
    break;

  case 10:
#line 130 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.DefineFunction((yylocation_stack_[(5) - (2)]), TYPE_VOID, (yysemantic_stack_[(5) - (2)].sval), NULL); ;}
    break;

  case 11:
#line 131 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.DefineFunction((yylocation_stack_[(6) - (2)]), TYPE_VOID, (yysemantic_stack_[(6) - (2)].sval), (yysemantic_stack_[(6) - (4)].arglist)); ;}
    break;

  case 12:
#line 134 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.value_list) = new CValueList((yysemantic_stack_[(1) - (1)].value)); ;}
    break;

  case 13:
#line 135 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.value_list) = (yysemantic_stack_[(3) - (1)].value_list)->Add((yysemantic_stack_[(3) - (3)].value)); ;}
    break;

  case 14:
#line 138 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.arglist) = new CArgList((yysemantic_stack_[(1) - (1)].argdef)); ;}
    break;

  case 15:
#line 139 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.arglist) = (yysemantic_stack_[(3) - (1)].arglist)->Add((yysemantic_stack_[(3) - (3)].argdef)); ;}
    break;

  case 16:
#line 142 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(1) - (1)]), (yysemantic_stack_[(1) - (1)].type), NULL); ;}
    break;

  case 17:
#line 143 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(2) - (1)]), TypeToRef((yysemantic_stack_[(2) - (1)].type)), NULL); ;}
    break;

  case 18:
#line 144 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(2) - (1)]), (yysemantic_stack_[(2) - (1)].type), (yysemantic_stack_[(2) - (2)].sval)); ;}
    break;

  case 19:
#line 145 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(3) - (1)]), TypeToRef((yysemantic_stack_[(3) - (1)].type)), (yysemantic_stack_[(3) - (3)].sval)); ;}
    break;

  case 20:
#line 146 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(4) - (1)]), TypeToRef((yysemantic_stack_[(4) - (1)].type)), (yysemantic_stack_[(4) - (2)].sval)); ;}
    break;

  case 21:
#line 147 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.argdef) = new CArgDef((yylocation_stack_[(5) - (1)]), TypeToRef((yysemantic_stack_[(5) - (1)].type)), (yysemantic_stack_[(5) - (3)].sval)); ;}
    break;

  case 22:
#line 150 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.AddFunction((yylocation_stack_[(5) - (1)]), (yysemantic_stack_[(5) - (1)].type), (yysemantic_stack_[(5) - (2)].sval), NULL, (yysemantic_stack_[(5) - (5)].block)); ;}
    break;

  case 23:
#line 151 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.AddFunction((yylocation_stack_[(6) - (1)]), (yysemantic_stack_[(6) - (1)].type), (yysemantic_stack_[(6) - (2)].sval), (yysemantic_stack_[(6) - (4)].arglist), (yysemantic_stack_[(6) - (6)].block)); ;}
    break;

  case 24:
#line 152 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.AddFunction((yylocation_stack_[(5) - (1)]), TYPE_VOID, (yysemantic_stack_[(5) - (2)].sval), NULL, (yysemantic_stack_[(5) - (5)].block)); ;}
    break;

  case 25:
#line 153 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { driver.AddFunction((yylocation_stack_[(6) - (1)]), TYPE_VOID, (yysemantic_stack_[(6) - (2)].sval), (yysemantic_stack_[(6) - (4)].arglist), (yysemantic_stack_[(6) - (6)].block)); ;}
    break;

  case 26:
#line 156 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.type) = TYPE_INTEGER; ;}
    break;

  case 27:
#line 157 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.type) = TYPE_STRING; ;}
    break;

  case 28:
#line 160 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.block) = new CStateBlock((yysemantic_stack_[(4) - (2)].decls), (yysemantic_stack_[(4) - (3)].states)); ;}
    break;

  case 29:
#line 163 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.decls) = NULL ;}
    break;

  case 30:
#line 164 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.decls) = (yysemantic_stack_[(1) - (1)].decls) ;}
    break;

  case 31:
#line 167 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.states) = NULL ;}
    break;

  case 32:
#line 168 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.states) = (yysemantic_stack_[(1) - (1)].states) ;}
    break;

  case 33:
#line 171 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.decls) = new CDeclList(new CDecl((yysemantic_stack_[(3) - (1)].type), (yysemantic_stack_[(3) - (2)].value_list))); ;}
    break;

  case 34:
#line 172 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.decls) = (yysemantic_stack_[(4) - (1)].decls)->Add(new CDecl((yysemantic_stack_[(4) - (2)].type), (yysemantic_stack_[(4) - (3)].value_list))); ;}
    break;

  case 35:
#line 175 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.states) = new CStateList((yysemantic_stack_[(1) - (1)].statement)); ;}
    break;

  case 36:
#line 176 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.states) = (yysemantic_stack_[(2) - (1)].states)->Add((yysemantic_stack_[(2) - (2)].statement)); ;}
    break;

  case 37:
#line 179 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CNopStatement((yylocation_stack_[(1) - (1)])); ;}
    break;

  case 38:
#line 180 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CAssignStatement((yylocation_stack_[(2) - (1)]), (yysemantic_stack_[(2) - (1)].assign)); ;}
    break;

  case 39:
#line 181 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CFunctionStatement((yylocation_stack_[(5) - (1)]), (yysemantic_stack_[(5) - (1)].sval), (yysemantic_stack_[(5) - (3)].args)); ;}
    break;

  case 40:
#line 182 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CFunctionStatement((yylocation_stack_[(4) - (1)]), (yysemantic_stack_[(4) - (1)].sval), NULL); ;}
    break;

  case 41:
#line 183 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CCaseStatement((yylocation_stack_[(3) - (1)]), (yysemantic_stack_[(3) - (2)].expr)); ;}
    break;

  case 42:
#line 184 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CDefaultStatement((yylocation_stack_[(2) - (1)])); ;}
    break;

  case 43:
#line 185 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CBreakStatement((yylocation_stack_[(2) - (1)])); ;}
    break;

  case 44:
#line 186 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CReturnStatement((yylocation_stack_[(2) - (1)]), NULL); ;}
    break;

  case 45:
#line 187 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CReturnStatement((yylocation_stack_[(3) - (1)]), (yysemantic_stack_[(3) - (2)].expr)); ;}
    break;

  case 46:
#line 188 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CIfStatement((yylocation_stack_[(5) - (1)]), (yysemantic_stack_[(5) - (3)].expr), (yysemantic_stack_[(5) - (5)].statement)); ;}
    break;

  case 47:
#line 189 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CIfStatement((yylocation_stack_[(7) - (1)]), (yysemantic_stack_[(7) - (3)].expr), (yysemantic_stack_[(7) - (5)].statement), (yysemantic_stack_[(7) - (7)].statement)); ;}
    break;

  case 48:
#line 191 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CForStatement((yylocation_stack_[(9) - (1)]), (yysemantic_stack_[(9) - (3)].assign), (yysemantic_stack_[(9) - (5)].expr), (yysemantic_stack_[(9) - (7)].assign), (yysemantic_stack_[(9) - (9)].statement)); ;}
    break;

  case 49:
#line 192 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CWhileStatement((yylocation_stack_[(5) - (1)]), (yysemantic_stack_[(5) - (3)].expr), (yysemantic_stack_[(5) - (5)].statement)); ;}
    break;

  case 50:
#line 193 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CSwitchStatement((yylocation_stack_[(7) - (1)]), (yysemantic_stack_[(7) - (3)].expr), (yysemantic_stack_[(7) - (6)].states)); ;}
    break;

  case 51:
#line 194 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.statement) = new CBlockStatement((yylocation_stack_[(1) - (1)]), (yysemantic_stack_[(1) - (1)].block)); ;}
    break;

  case 52:
#line 197 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '=', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 53:
#line 198 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '+', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 54:
#line 199 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '-', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 55:
#line 200 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '*', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 56:
#line 201 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '/', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 57:
#line 202 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.assign) = new CAssign((yylocation_stack_[(3) - (1)]), '%', (yysemantic_stack_[(3) - (1)].value), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 58:
#line 205 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_LOGAND, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 59:
#line 206 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_LOGOR, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 60:
#line 207 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_EQ, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 61:
#line 208 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_NE, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 62:
#line 209 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_GT, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 63:
#line 210 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_GE, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 64:
#line 211 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_LT, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 65:
#line 212 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_LE, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 66:
#line 213 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_AND, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 67:
#line 214 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_OR, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 68:
#line 215 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_LSHIFT, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 69:
#line 216 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_RSHIFT, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 70:
#line 217 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_MINUS, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 71:
#line 218 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_PLUS, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 72:
#line 219 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_TIMES, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 73:
#line 220 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_DIVIDE, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 74:
#line 221 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(3) - (2)]), OP_MOD, (yysemantic_stack_[(3) - (1)].expr), (yysemantic_stack_[(3) - (3)].expr)); ;}
    break;

  case 75:
#line 222 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = CNode::MakeNode(driver, (yylocation_stack_[(2) - (2)]), OP_NEG, (yysemantic_stack_[(2) - (2)].expr)); ;}
    break;

  case 76:
#line 223 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = (yysemantic_stack_[(3) - (2)].expr); ;}
    break;

  case 77:
#line 224 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = (yysemantic_stack_[(1) - (1)].value); ;}
    break;

  case 78:
#line 225 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = new CNode((yylocation_stack_[(1) - (1)]), OP_CONST, (yysemantic_stack_[(1) - (1)].ival)); ;}
    break;

  case 79:
#line 226 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = new CNode((yylocation_stack_[(1) - (1)]), OP_STRING, (yysemantic_stack_[(1) - (1)].sval)); ;}
    break;

  case 80:
#line 227 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = new CFunctionNode((yylocation_stack_[(4) - (1)]), (yysemantic_stack_[(4) - (1)].sval), (yysemantic_stack_[(4) - (3)].args)); ;}
    break;

  case 81:
#line 228 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.expr) = new CFunctionNode((yylocation_stack_[(3) - (1)]), (yysemantic_stack_[(3) - (1)].sval), NULL); ;}
    break;

  case 82:
#line 231 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.value) = new CValueNode((yylocation_stack_[(1) - (1)]), (yysemantic_stack_[(1) - (1)].sval)); ;}
    break;

  case 83:
#line 232 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.value) = new CValueNode((yylocation_stack_[(4) - (1)]), (yysemantic_stack_[(4) - (1)].sval), (yysemantic_stack_[(4) - (3)].expr)); ;}
    break;

  case 84:
#line 235 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.args) = new CArgs((yysemantic_stack_[(1) - (1)].expr)); ;}
    break;

  case 85:
#line 236 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"
    { (yyval.args) = (yysemantic_stack_[(3) - (1)].args)->Add((yysemantic_stack_[(3) - (3)].expr)); ;}
    break;


    /* Line 675 of lalr1.cc.  */
#line 870 "script-parser.cc"
	default: break;
      }
    YY_SYMBOL_PRINT ("-> $$ =", yyr1_[yyn], &yyval, &yyloc);

    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();

    yysemantic_stack_.push (yyval);
    yylocation_stack_.push (yyloc);

    /* Shift the result of the reduction.  */
    yyn = yyr1_[yyn];
    yystate = yypgoto_[yyn - yyntokens_] + yystate_stack_[0];
    if (0 <= yystate && yystate <= yylast_
	&& yycheck_[yystate] == yystate_stack_[0])
      yystate = yytable_[yystate];
    else
      yystate = yydefgoto_[yyn - yyntokens_];
    goto yynewstate;

  /*------------------------------------.
  | yyerrlab -- here on detecting error |
  `------------------------------------*/
  yyerrlab:
    /* If not already recovering from an error, report this error.  */
    if (!yyerrstatus_)
      {
	++yynerrs_;
	error (yylloc, yysyntax_error_ (yystate, yytoken));
      }

    yyerror_range[0] = yylloc;
    if (yyerrstatus_ == 3)
      {
	/* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

	if (yychar <= yyeof_)
	  {
	  /* Return failure if at end of input.  */
	  if (yychar == yyeof_)
	    YYABORT;
	  }
	else
	  {
	    yydestruct_ ("Error: discarding", yytoken, &yylval, &yylloc);
	    yychar = yyempty_;
	  }
      }

    /* Else will try to reuse look-ahead token after shifting the error
       token.  */
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if (false)
      goto yyerrorlab;

    yyerror_range[0] = yylocation_stack_[yylen - 1];
    /* Do not reclaim the symbols of the rule which action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    yystate = yystate_stack_[0];
    goto yyerrlab1;

  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;	/* Each real token shifted decrements this.  */

    for (;;)
      {
	yyn = yypact_[yystate];
	if (yyn != yypact_ninf_)
	{
	  yyn += yyterror_;
	  if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yyterror_)
	    {
	      yyn = yytable_[yyn];
	      if (0 < yyn)
		break;
	    }
	}

	/* Pop the current state because it cannot handle the error token.  */
	if (yystate_stack_.height () == 1)
	YYABORT;

	yyerror_range[0] = yylocation_stack_[0];
	yydestruct_ ("Error: popping",
		     yystos_[yystate],
		     &yysemantic_stack_[0], &yylocation_stack_[0]);
	yypop_ ();
	yystate = yystate_stack_[0];
	YY_STACK_PRINT ();
      }

    if (yyn == yyfinal_)
      goto yyacceptlab;

    yyerror_range[1] = yylloc;
    // Using YYLLOC is tempting, but would change the location of
    // the look-ahead.  YYLOC is available though.
    YYLLOC_DEFAULT (yyloc, (yyerror_range - 1), 2);
    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yyloc);

    /* Shift the error token.  */
    YY_SYMBOL_PRINT ("Shifting", yystos_[yyn],
		   &yysemantic_stack_[0], &yylocation_stack_[0]);

    yystate = yyn;
    goto yynewstate;

    /* Accept.  */
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    /* Abort.  */
  yyabortlab:
    yyresult = 1;
    goto yyreturn;

  yyreturn:
    if (yychar != yyeof_ && yychar != yyempty_)
      yydestruct_ ("Cleanup: discarding lookahead", yytoken, &yylval, &yylloc);

    /* Do not reclaim the symbols of the rule which action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (yystate_stack_.height () != 1)
      {
	yydestruct_ ("Cleanup: popping",
		   yystos_[yystate_stack_[0]],
		   &yysemantic_stack_[0],
		   &yylocation_stack_[0]);
	yypop_ ();
      }

    return yyresult;
  }

  // Generate an error message.
  std::string
  script_parser::yysyntax_error_ (int yystate, int tok)
  {
    std::string res;
    YYUSE (yystate);
#if YYERROR_VERBOSE
    int yyn = yypact_[yystate];
    if (yypact_ninf_ < yyn && yyn <= yylast_)
      {
	/* Start YYX at -YYN if negative to avoid negative indexes in
	   YYCHECK.  */
	int yyxbegin = yyn < 0 ? -yyn : 0;

	/* Stay within bounds of both yycheck and yytname.  */
	int yychecklim = yylast_ - yyn + 1;
	int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
	int count = 0;
	for (int x = yyxbegin; x < yyxend; ++x)
	  if (yycheck_[x + yyn] == x && x != yyterror_)
	    ++count;

	// FIXME: This method of building the message is not compatible
	// with internationalization.  It should work like yacc.c does it.
	// That is, first build a string that looks like this:
	// "syntax error, unexpected %s or %s or %s"
	// Then, invoke YY_ on this string.
	// Finally, use the string as a format to output
	// yytname_[tok], etc.
	// Until this gets fixed, this message appears in English only.
	res = "syntax error, unexpected ";
	res += yytnamerr_ (yytname_[tok]);
	if (count < 5)
	  {
	    count = 0;
	    for (int x = yyxbegin; x < yyxend; ++x)
	      if (yycheck_[x + yyn] == x && x != yyterror_)
		{
		  res += (!count++) ? ", expecting " : " or ";
		  res += yytnamerr_ (yytname_[x]);
		}
	  }
      }
    else
#endif
      res = YY_("syntax error");
    return res;
  }


  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
  const signed char script_parser::yypact_ninf_ = -121;
  const short int
  script_parser::yypact_[] =
  {
        54,   -24,  -121,  -121,    27,   158,  -121,  -121,  -121,    84,
    -121,    16,  -121,  -121,   -16,   -14,  -121,    36,   111,   143,
    -121,   100,   -37,    93,  -121,    24,   -32,    99,  -121,    47,
    -121,   143,   143,   162,  -121,    21,  -121,  -121,   122,  -121,
      39,   122,    78,   124,  -121,  -121,    44,    20,  -121,   203,
     143,   143,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   143,   143,   143,  -121,   100,   108,
     122,  -121,  -121,  -121,    98,   120,  -121,  -121,  -121,   352,
     133,  -121,   361,   393,   402,   402,   402,   402,   182,   182,
     402,   402,   168,   168,   -31,   -31,  -121,  -121,  -121,    69,
      96,   114,   136,   142,   149,   143,   117,   161,    73,  -121,
    -121,   183,   108,  -121,   189,     4,   100,  -121,   144,  -121,
     143,  -121,   121,   143,   143,   100,   143,    62,  -121,  -121,
    -121,   305,  -121,  -121,  -121,   143,   143,   143,   143,   143,
     143,   148,  -121,   352,   191,   139,   216,   254,   192,   267,
    -121,  -121,   352,   352,   352,   352,   352,   352,  -121,  -121,
     202,   108,   108,   143,   197,  -121,   225,  -121,   316,   108,
     108,   100,   208,  -121,   214,  -121,   108,  -121
  };

  /* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
     doesn't specify something else to do.  Zero means the default is an
     error.  */
  const unsigned char
  script_parser::yydefact_[] =
  {
         0,     0,    26,    27,     0,     0,     2,     6,     5,     0,
       4,     0,     1,     3,    82,     0,    12,     0,     0,     0,
       7,     0,     0,     0,    14,    16,     0,     0,    78,    82,
      79,     0,     0,     0,    77,    82,    13,    10,    29,    24,
       0,     0,    18,    17,     8,    22,     0,     0,    75,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    83,     0,    31,
      30,    11,    25,    15,     0,    19,     9,    23,    81,    84,
       0,    76,    59,    58,    60,    61,    63,    65,    68,    69,
      62,    64,    66,    67,    71,    70,    72,    73,    74,     0,
      82,     0,     0,     0,     0,     0,     0,     0,     0,    37,
      51,     0,    32,    35,     0,     0,     0,    20,     0,    80,
       0,    33,     0,     0,     0,     0,     0,     0,    42,    43,
      44,     0,    28,    36,    38,     0,     0,     0,     0,     0,
       0,     0,    21,    85,     0,     0,     0,     0,     0,     0,
      41,    45,    53,    54,    55,    56,    57,    52,    34,    40,
       0,     0,     0,     0,     0,    39,    46,    49,     0,    31,
       0,     0,     0,    47,     0,    50,     0,    48
  };

  /* YYPGOTO[NTERM-NUM].  */
  const short int
  script_parser::yypgoto_[] =
  {
      -121,  -121,   253,  -121,   -66,   250,   228,  -121,    11,   420,
    -121,   101,  -121,  -121,  -109,  -120,   -18,    -9,   150
  };

  /* YYDEFGOTO[NTERM-NUM].  */
  const signed char
  script_parser::yydefgoto_[] =
  {
        -1,     5,     6,     7,    15,    23,    24,     8,    25,   110,
      69,   111,    70,   112,   113,   114,    79,    34,    80
  };

  /* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule which
     number is the opposite.  If zero, do what YYDEFACT says.  */
  const signed char script_parser::yytable_ninf_ = -1;
  const short int
  script_parser::yytable_[] =
  {
        16,    33,    99,   133,    37,   148,    64,    65,    66,    44,
      38,     9,    36,    48,    49,    38,     9,    10,   135,   136,
     137,   138,   139,    28,    29,    30,    18,    20,    42,    19,
      21,    11,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    96,    97,    98,    68,
     141,   174,   166,   167,   140,     1,    31,    43,    17,    16,
     115,   173,    32,    78,     2,     3,    19,   177,    50,    51,
      52,    53,    54,    55,    56,    57,    28,    29,    30,    22,
      71,   116,     2,     3,     4,    76,    38,   127,    14,    47,
     131,    38,    19,    58,    59,    60,    61,    62,    63,    64,
      65,    66,   143,   115,    35,   146,   147,    16,   149,    31,
     121,   150,   100,    21,   130,    32,   115,   152,   153,   154,
     155,   156,   157,    74,    28,    29,    30,   101,    75,   102,
     103,   104,   105,   106,   107,   108,    40,    41,   122,     2,
       3,    19,    46,    41,   117,   168,    28,    29,    30,   109,
       2,     3,   115,   115,    26,    38,   123,    31,    12,     1,
     115,   115,   115,    32,   144,   118,   128,   115,    50,    51,
      52,    53,    54,    55,    56,    57,   119,   120,   124,    31,
      56,    57,   160,   120,   125,    32,     2,     3,     4,   158,
     142,   126,    21,    58,    59,    60,    61,    62,    63,    64,
      65,    66,   129,    62,    63,    64,    65,    66,    67,    50,
      51,    52,    53,    54,    55,    56,    57,    62,    63,    64,
      65,    66,    50,    51,    52,    53,    54,    55,    56,    57,
     134,   132,   159,   163,    58,    59,    60,    61,    62,    63,
      64,    65,    66,   165,   169,   170,    81,    58,    59,    60,
      61,    62,    63,    64,    65,    66,   175,   176,    13,   161,
      50,    51,    52,    53,    54,    55,    56,    57,    27,    73,
     172,     0,   145,    50,    51,    52,    53,    54,    55,    56,
      57,     0,     0,     0,     0,    58,    59,    60,    61,    62,
      63,    64,    65,    66,     0,     0,     0,   162,    58,    59,
      60,    61,    62,    63,    64,    65,    66,     0,     0,     0,
     164,    50,    51,    52,    53,    54,    55,    56,    57,     0,
       0,     0,    50,    51,    52,    53,    54,    55,    56,    57,
       0,     0,     0,     0,     0,     0,    58,    59,    60,    61,
      62,    63,    64,    65,    66,     0,   151,    58,    59,    60,
      61,    62,    63,    64,    65,    66,     0,   171,    50,    51,
      52,    53,    54,    55,    56,    57,     0,     0,    51,    52,
      53,    54,    55,    56,    57,     0,     0,     0,     0,     0,
       0,     0,     0,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    52,    53,    54,    55,    56,    57,     0,     0,     0,
      -1,    -1,    -1,    -1,    56,    57,     0,     0,     0,     0,
       0,     0,     0,     0,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    -1,    -1,    60,    61,    62,    63,    64,
      65,    66,    39,     0,     0,     0,    45,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      72,     0,     0,     0,     0,     0,    77
  };

  /* YYCHECK.  */
  const short int
  script_parser::yycheck_[] =
  {
         9,    19,    68,   112,    41,   125,    37,    38,    39,    41,
      47,     0,    21,    31,    32,    47,     5,    41,    14,    15,
      16,    17,    18,     3,     4,     5,    42,    41,     4,    45,
      44,     4,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    38,
     116,   171,   161,   162,    50,     1,    36,    33,    42,    68,
      69,   170,    42,    43,    28,    29,    45,   176,     6,     7,
       8,     9,    10,    11,    12,    13,     3,     4,     5,    43,
      41,    70,    28,    29,    30,    41,    47,   105,     4,    42,
     108,    47,    45,    31,    32,    33,    34,    35,    36,    37,
      38,    39,   120,   112,     4,   123,   124,   116,   126,    36,
      41,    49,     4,    44,    41,    42,   125,   135,   136,   137,
     138,   139,   140,    45,     3,     4,     5,    19,     4,    21,
      22,    23,    24,    25,    26,    27,    43,    44,    42,    28,
      29,    45,    43,    44,    46,   163,     3,     4,     5,    41,
      28,    29,   161,   162,    43,    47,    42,    36,     0,     1,
     169,   170,   171,    42,    43,    45,    49,   176,     6,     7,
       8,     9,    10,    11,    12,    13,    43,    44,    42,    36,
      12,    13,    43,    44,    42,    42,    28,    29,    30,    41,
      46,    42,    44,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    41,    35,    36,    37,    38,    39,    46,     6,
       7,     8,     9,    10,    11,    12,    13,    35,    36,    37,
      38,    39,     6,     7,     8,     9,    10,    11,    12,    13,
      41,    48,    41,    41,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    41,    47,    20,    43,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    48,    43,     5,    43,
       6,     7,     8,     9,    10,    11,    12,    13,    18,    41,
     169,    -1,   122,     6,     7,     8,     9,    10,    11,    12,
      13,    -1,    -1,    -1,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    -1,    -1,    -1,    43,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    -1,    -1,    -1,
      43,     6,     7,     8,     9,    10,    11,    12,    13,    -1,
      -1,    -1,     6,     7,     8,     9,    10,    11,    12,    13,
      -1,    -1,    -1,    -1,    -1,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    -1,    41,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    -1,    41,     6,     7,
       8,     9,    10,    11,    12,    13,    -1,    -1,     7,     8,
       9,    10,    11,    12,    13,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    31,    32,    33,    34,    35,    36,    37,    38,
      39,     8,     9,    10,    11,    12,    13,    -1,    -1,    -1,
       8,     9,    10,    11,    12,    13,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    22,    -1,    -1,    -1,    26,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      40,    -1,    -1,    -1,    -1,    -1,    46
  };

  /* STOS_[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
  const unsigned char
  script_parser::yystos_[] =
  {
         0,     1,    28,    29,    30,    52,    53,    54,    58,    59,
      41,     4,     0,    53,     4,    55,    68,    42,    42,    45,
      41,    44,    43,    56,    57,    59,    43,    56,     3,     4,
       5,    36,    42,    67,    68,     4,    68,    41,    47,    60,
      43,    44,     4,    33,    41,    60,    43,    42,    67,    67,
       6,     7,     8,     9,    10,    11,    12,    13,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    46,    59,    61,
      63,    41,    60,    57,    45,     4,    41,    60,    43,    67,
      69,    43,    67,    67,    67,    67,    67,    67,    67,    67,
      67,    67,    67,    67,    67,    67,    67,    67,    67,    55,
       4,    19,    21,    22,    23,    24,    25,    26,    27,    41,
      60,    62,    64,    65,    66,    68,    59,    46,    45,    43,
      44,    41,    42,    42,    42,    42,    42,    67,    49,    41,
      41,    67,    48,    65,    41,    14,    15,    16,    17,    18,
      50,    55,    46,    67,    43,    69,    67,    67,    66,    67,
      49,    41,    67,    67,    67,    67,    67,    67,    41,    41,
      43,    43,    43,    41,    43,    41,    65,    65,    67,    47,
      20,    41,    62,    65,    66,    48,    43,    65
  };

#if YYDEBUG
  /* TOKEN_NUMBER_[YYLEX-NUM] -- Internal symbol number corresponding
     to YYLEX-NUM.  */
  const unsigned short int
  script_parser::yytoken_number_[] =
  {
         0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,    62,    60,    38,   124,    43,    45,    42,    47,    37,
     286,    59,    40,    41,    44,    91,    93,   123,   125,    58,
      61
  };
#endif

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
  const unsigned char
  script_parser::yyr1_[] =
  {
         0,    51,    52,    52,    53,    53,    53,    54,    54,    54,
      54,    54,    55,    55,    56,    56,    57,    57,    57,    57,
      57,    57,    58,    58,    58,    58,    59,    59,    60,    61,
      61,    62,    62,    63,    63,    64,    64,    65,    65,    65,
      65,    65,    65,    65,    65,    65,    65,    65,    65,    65,
      65,    65,    66,    66,    66,    66,    66,    66,    67,    67,
      67,    67,    67,    67,    67,    67,    67,    67,    67,    67,
      67,    67,    67,    67,    67,    67,    67,    67,    67,    67,
      67,    67,    68,    68,    69,    69
  };

  /* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
  const unsigned char
  script_parser::yyr2_[] =
  {
         0,     2,     1,     2,     2,     1,     1,     3,     5,     6,
       5,     6,     1,     3,     1,     3,     1,     2,     2,     3,
       4,     5,     5,     6,     5,     6,     1,     1,     4,     0,
       1,     0,     1,     3,     4,     1,     2,     1,     2,     5,
       4,     3,     2,     2,     2,     3,     5,     7,     9,     5,
       7,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     2,     3,     1,     1,     1,
       4,     3,     1,     4,     1,     3
  };

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
  /* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
     First, the terminals, then, starting at \a yyntokens_, nonterminals.  */
  const char*
  const script_parser::yytname_[] =
  {
    "\"end of file\"", "error", "$undefined", "\"ival\"", "\"identifier\"",
  "\"sval\"", "\"||\"", "\"&&\"", "\"==\"", "\"!=\"", "\">=\"", "\"<=\"",
  "\"<<\"", "\">>\"", "\"+=\"", "\"-=\"", "\"*=\"", "\"/=\"", "\"%=\"",
  "\"if\"", "\"else\"", "\"while\"", "\"for\"", "\"switch\"", "\"case\"",
  "\"default\"", "\"break\"", "\"return\"", "\"int\"", "\"string\"",
  "\"void\"", "'>'", "'<'", "'&'", "'|'", "'+'", "'-'", "'*'", "'/'",
  "'%'", "NEG", "';'", "'('", "')'", "','", "'['", "']'", "'{'", "'}'",
  "':'", "'='", "$accept", "unit", "define_or_state", "declaration",
  "value_list", "arglist", "arg", "function", "type", "block", "decl_list",
  "state_list", "decls", "states", "statement", "assign", "expr", "value",
  "args", 0
  };
#endif

#if YYDEBUG
  /* YYRHS -- A `-1'-separated list of the rules' RHS.  */
  const script_parser::rhs_number_type
  script_parser::yyrhs_[] =
  {
        52,     0,    -1,    53,    -1,    52,    53,    -1,     1,    41,
      -1,    58,    -1,    54,    -1,    59,    55,    41,    -1,    59,
       4,    42,    43,    41,    -1,    59,     4,    42,    56,    43,
      41,    -1,    30,     4,    42,    43,    41,    -1,    30,     4,
      42,    56,    43,    41,    -1,    68,    -1,    55,    44,    68,
      -1,    57,    -1,    56,    44,    57,    -1,    59,    -1,    59,
      33,    -1,    59,     4,    -1,    59,    33,     4,    -1,    59,
       4,    45,    46,    -1,    59,    33,     4,    45,    46,    -1,
      59,     4,    42,    43,    60,    -1,    59,     4,    42,    56,
      43,    60,    -1,    30,     4,    42,    43,    60,    -1,    30,
       4,    42,    56,    43,    60,    -1,    28,    -1,    29,    -1,
      47,    61,    62,    48,    -1,    -1,    63,    -1,    -1,    64,
      -1,    59,    55,    41,    -1,    63,    59,    55,    41,    -1,
      65,    -1,    64,    65,    -1,    41,    -1,    66,    41,    -1,
       4,    42,    69,    43,    41,    -1,     4,    42,    43,    41,
      -1,    24,    67,    49,    -1,    25,    49,    -1,    26,    41,
      -1,    27,    41,    -1,    27,    67,    41,    -1,    19,    42,
      67,    43,    65,    -1,    19,    42,    67,    43,    65,    20,
      65,    -1,    22,    42,    66,    41,    67,    41,    66,    43,
      65,    -1,    21,    42,    67,    43,    65,    -1,    23,    42,
      67,    43,    47,    62,    48,    -1,    60,    -1,    68,    50,
      67,    -1,    68,    14,    67,    -1,    68,    15,    67,    -1,
      68,    16,    67,    -1,    68,    17,    67,    -1,    68,    18,
      67,    -1,    67,     7,    67,    -1,    67,     6,    67,    -1,
      67,     8,    67,    -1,    67,     9,    67,    -1,    67,    31,
      67,    -1,    67,    10,    67,    -1,    67,    32,    67,    -1,
      67,    11,    67,    -1,    67,    33,    67,    -1,    67,    34,
      67,    -1,    67,    12,    67,    -1,    67,    13,    67,    -1,
      67,    36,    67,    -1,    67,    35,    67,    -1,    67,    37,
      67,    -1,    67,    38,    67,    -1,    67,    39,    67,    -1,
      36,    67,    -1,    42,    67,    43,    -1,    68,    -1,     3,
      -1,     5,    -1,     4,    42,    69,    43,    -1,     4,    42,
      43,    -1,     4,    -1,     4,    45,    67,    46,    -1,    67,
      -1,    69,    44,    67,    -1
  };

  /* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
     YYRHS.  */
  const unsigned short int
  script_parser::yyprhs_[] =
  {
         0,     0,     3,     5,     8,    11,    13,    15,    19,    25,
      32,    38,    45,    47,    51,    53,    57,    59,    62,    65,
      69,    74,    80,    86,    93,    99,   106,   108,   110,   115,
     116,   118,   119,   121,   125,   130,   132,   135,   137,   140,
     146,   151,   155,   158,   161,   164,   168,   174,   182,   192,
     198,   206,   208,   212,   216,   220,   224,   228,   232,   236,
     240,   244,   248,   252,   256,   260,   264,   268,   272,   276,
     280,   284,   288,   292,   296,   300,   303,   307,   309,   311,
     313,   318,   322,   324,   329,   331
  };

  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
  const unsigned char
  script_parser::yyrline_[] =
  {
         0,   118,   118,   119,   122,   123,   124,   127,   128,   129,
     130,   131,   134,   135,   138,   139,   142,   143,   144,   145,
     146,   147,   150,   151,   152,   153,   156,   157,   160,   163,
     164,   167,   168,   171,   172,   175,   176,   179,   180,   181,
     182,   183,   184,   185,   186,   187,   188,   189,   190,   192,
     193,   194,   197,   198,   199,   200,   201,   202,   205,   206,
     207,   208,   209,   210,   211,   212,   213,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   223,   224,   225,   226,
     227,   228,   231,   232,   235,   236
  };

  // Print the state stack on the debug stream.
  void
  script_parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (state_stack_type::const_iterator i = yystate_stack_.begin ();
	 i != yystate_stack_.end (); ++i)
      *yycdebug_ << ' ' << *i;
    *yycdebug_ << std::endl;
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  script_parser::yy_reduce_print_ (int yyrule)
  {
    unsigned int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    /* Print the symbols being reduced, and their result.  */
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
	       << " (line " << yylno << "), ";
    /* The symbols being reduced.  */
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
		       yyrhs_[yyprhs_[yyrule] + yyi],
		       &(yysemantic_stack_[(yynrhs) - (yyi + 1)]),
		       &(yylocation_stack_[(yynrhs) - (yyi + 1)]));
  }
#endif // YYDEBUG

  /* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
  script_parser::token_number_type
  script_parser::yytranslate_ (int t)
  {
    static
    const token_number_type
    translate_table[] =
    {
           0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    39,    33,     2,
      42,    43,    37,    35,    44,    36,     2,    38,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    49,    41,
      32,    50,    31,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    45,     2,    46,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    47,    34,    48,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    40
    };
    if ((unsigned int) t <= yyuser_token_number_max_)
      return translate_table[t];
    else
      return yyundef_token_;
  }

  const int script_parser::yyeof_ = 0;
  const int script_parser::yylast_ = 466;
  const int script_parser::yynnts_ = 19;
  const int script_parser::yyempty_ = -2;
  const int script_parser::yyfinal_ = 12;
  const int script_parser::yyterror_ = 1;
  const int script_parser::yyerrcode_ = 256;
  const int script_parser::yyntokens_ = 51;

  const unsigned int script_parser::yyuser_token_number_max_ = 286;
  const script_parser::token_number_type script_parser::yyundef_token_ = 2;

} // namespace yy

#line 239 "d:\\Work\\ScriptEngine\\Sample Source\\Bison-Flex\\Compiler-StackBase\\script-parser.yy"

void yy::script_parser::error(const yy::script_parser::location_type& l, const std::string& m)
{
	driver.error(l, m);
}

