//
// ���zCPU�̖��߃R�[�h���蓖��
//
//		(c)2008 Chihiro.SAKAMOTO HyperWorks
//
#ifdef	VM_ENUMDEF
#define	VMCODE0(code_, name_)	code_,
#define	VMCODE1(code_, name_)	code_,
#endif
#ifdef	VM_CREATE
#define	VMCODE0(code_, name_)	void name_()			{ statement.push_back(CVMCode(code_)); }
#define	VMCODE1(code_, name_)	void name_(int arg1)	{ statement.push_back(CVMCode(code_, arg1)); }
#endif
#ifdef	VM_SWITCHTABLE
#define	VMCODE0(code_, name_)	case code_: name_(); break;
#define	VMCODE1(code_, name_)	case code_: name_(value()); break;
#endif
#ifdef	VM_NAMETABLE
#define	VMCODE0(code_, name_)	#name_,
#define	VMCODE1(code_, name_)	#name_,
#endif

VMCODE1(VM_PUSHCONST,			PushConst)
VMCODE1(VM_PUSHSTRING,			PushString)
VMCODE1(VM_PUSHVALUE,			PushValue)
VMCODE1(VM_PUSHLOCAL,			PushLocal)
VMCODE1(VM_PUSHARRAY,			PushArray)
VMCODE1(VM_PUSHLOCALARRAY,		PushLocalArray)
VMCODE1(VM_PUSHLOCALREF,		PushLocalRef)
VMCODE1(VM_PUSHLOCALARRAYREF,	PushLocalArrayRef)
VMCODE1(VM_PUSHADDR,			PushAddr)
VMCODE1(VM_PUSHARRAYADDR,		PushArrayAddr)
VMCODE1(VM_POPVALUE,			PopValue)
VMCODE1(VM_POPLOCAL,			PopLocal)
VMCODE1(VM_POPARRAY,			PopArray)
VMCODE1(VM_POPLOCALARRAY,		PopLocalArray)
VMCODE1(VM_POPLOCALREF,			PopLocalRef)
VMCODE1(VM_POPLOCALARRAYREF,	PopLocalArrayRef)
VMCODE1(VM_ALLOCSTACK,			OpAllocStack)
VMCODE0(VM_POP,					OpPop)
VMCODE0(VM_NEG,					OpNeg)
VMCODE0(VM_EQ,					OpEq)
VMCODE0(VM_NE,					OpNe)
VMCODE0(VM_GT,					OpGt)
VMCODE0(VM_GE,					OpGe)
VMCODE0(VM_LT,					OpLt)
VMCODE0(VM_LE,					OpLe)
VMCODE0(VM_LOGAND,				OpLogAnd)
VMCODE0(VM_LOGOR,				OpLogOr)
VMCODE0(VM_AND,					OpAnd)
VMCODE0(VM_OR,					OpOr)
VMCODE0(VM_LSHIFT,				OpLeftShift)
VMCODE0(VM_RSHIFT,				OpRightShift)
VMCODE0(VM_ADD,					OpAdd)
VMCODE0(VM_SUB,					OpSub)
VMCODE0(VM_MUL,					OpMul)
VMCODE0(VM_DIV,					OpDiv)
VMCODE0(VM_MOD,					OpMod)
VMCODE0(VM_STREQ,				OpStrEq)
VMCODE0(VM_STRNE,				OpStrNe)
VMCODE0(VM_STRGT,				OpStrGt)
VMCODE0(VM_STRGE,				OpStrGe)
VMCODE0(VM_STRLT,				OpStrLt)
VMCODE0(VM_STRLE,				OpStrLe)
VMCODE0(VM_STRADD,				OpStrAdd)
VMCODE1(VM_JMP,					OpJmp)
VMCODE1(VM_JMPC,				OpJmpC)
VMCODE1(VM_JMPNC,				OpJmpNC)
VMCODE1(VM_TEST,				OpTest)
VMCODE1(VM_CALL,				OpCall)
VMCODE1(VM_SYSCALL,				OpSysCall)
VMCODE0(VM_RETURN,				OpReturn)
VMCODE0(VM_RETURNV,				OpReturnV)
VMCODE0(VM_HALT,				OpHalt)

#undef	VMCODE0
#undef	VMCODE1
