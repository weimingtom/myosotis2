//
// �l�����Z�p�[�T�[
//
//	Chihiro.SAKAMOTO
//
#ifndef __parser_h__
#define __parser_h__

#include <string>
#include "calc-driver.h"
#include "node.h"

// �p�[�T�[�N���X

class cparser {
  public:
	cparser();
	~cparser();

	bool parse(calc_driver *driver, const std::string &f);

  private:
	cnode *add_sub_expr();
	cnode *mul_div_expr();
	cnode *term();

	int get_token(std::string &str)
	{
		if (token_type != OP_EOF) {
			int type = token_type;
			token_type = OP_EOF;
			str = token_string;
			return type;
		}
		return _get_token(str);
	}
	void unget_token(int token, const std::string &str)
	{
		token_type = token;
		token_string = str;
	}

	int _get_token(std::string &str);

  private:
	FILE *fp;

	int token_type;
	std::string token_string;
} ;

#endif
