#ifndef __CALC_DRIVER_H__
#define	__CALC_DRIVER_H__

#include <string>
#include <map>
#include "node.h"

class calc_driver {
  public:
	calc_driver();
	virtual ~calc_driver();

	bool calc(const std::string &f);

	int value(const std::string *name)
	{
		return values[*name];
	}
	void assign(const std::string &value, cnode *node);
	void print(cnode *node);
	void list();

	// Error handling.
	void error(const std::string& m);

  private:
	std::map<std::string, int> values;	// �ѿ��ơ��֥�
} ;

#endif
