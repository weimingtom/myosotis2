#include <functional>
#include <iostream>
#include <iomanip>
#include "node.h"
#include "compiler.h"
#include "script-parser.hh"

// �R�[�h�����p
CNodeValue CNodeValue::MakeNodeValue(compiler *c, CNode *node)
{
	switch (node->op()) {
	  case OP_CONST:
		return CNodeValue(CONST, node->value());

	  case OP_VALUE:
		{
			const CValueTag *tag = c->GetValueTag(node->string());
			if (tag == 0) {
				c->error(node->location(), "�ϐ�" +  node->string() + "�͖���`�ł��B");
				return CNodeValue(VALUE, 0);
			}
			return CNodeValue(VALUE, tag->addr_);
		}
	}
	return node->analyze(c);
}

// �ꎞ�ϐ��̊Ǘ�
CNodeValue CNodeValue::MakeTempValue(compiler *c, int value)
{
	if (value < 0)
		return CNodeValue(c, TEMP, c->AllocTempValue());
	return CNodeValue(VALUE, value);
}

void CNodeValue::ReleaseTempValue()
{
	c_->ReleaseTempValue(value_);
}

void CNodeValue::UseTempValue()
{
	c_->UseTempValue(value_);
}

int CNodeValue::value() const
{
	if (type_ == TEMP)
		return c_->GetTempAddr(value_);
	return value_;
}

// �m�[�h����
//	�������A�萔���m�̌v�Z�́Aleft�m�[�h�Ɍ��ʂ������A�����Ԃ�

CNode *CNode::MakeNode(compiler &c, const yy::location& l, int op, CNode *left, CNode *right)
{
	if (right == 0) {
		switch (op) {
		  case OP_NEG:
			if (left->op_ == OP_CONST) {				// �萔���Z���v�Z����
				left->value_ = -left->value_;
				return left;
			}
			break;
		}
		return new CNode(l, op, left);
	}

	// �萔���Z���v�Z����
	if (left->op_ == OP_CONST && right->op_ == OP_CONST) {
		switch (op) {
		  case OP_EQ:
			left->value_ = (left->value_ == right->value_)? 1: 0;
			break;

		  case OP_NE:
			left->value_ = (left->value_ != right->value_)? 1: 0;
			break;

		  case OP_GT:
			left->value_ = (left->value_ > right->value_)? 1: 0;
			break;

		  case OP_GE:
			left->value_ = (left->value_ >= right->value_)? 1: 0;
			break;

		  case OP_LT:
			left->value_ = (left->value_ < right->value_)? 1: 0;
			break;

		  case OP_LE:
			left->value_ = (left->value_ <= right->value_)? 1: 0;
			break;

		  case OP_MINUS:
			left->value_ -= right->value_;
			break;

		  case OP_PLUS:
			left->value_ += right->value_;
			break;

		  case OP_TIMES:
			left->value_ *= right->value_;
			break;

		  case OP_DIVIDE:
			if (right->value_ == 0) {
				c.error(l, "�萔�v�Z��0�ŏ��Z���܂����B");
			}
			else {
				left->value_ /= right->value_;
			}
			break;

		  case OP_MOD:
			if (right->value_ == 0) {
				c.error(l, "�萔�v�Z��0�ŏ��Z���܂����B");
			}
			else {
				left->value_ %= right->value_;
			}
			break;

		  default:
			return new CNode(l, op, left, right);
		}
		delete right;
		return left;
	}
	return new CNode(l, op, left, right);
}

CNodeValue CNode::analyze(compiler *c, int ret)
{
	switch (op_) {
	  case OP_NEG:
		return c->MakeNeg(ret, CNodeValue::MakeNodeValue(c, left_));

	  case OP_RANDFUNC:
		return c->MakeRand(ret, CNodeValue::MakeNodeValue(c, left_));

	  case OP_CONST:
		return c->MakeMoveC(ret, value_);

	  case OP_VALUE:
		return c->MakeMoveV(ret, CNodeValue::MakeNodeValue(c, this));
	}

	CNodeValue left = CNodeValue::MakeNodeValue(c, left_);
	CNodeValue right = CNodeValue::MakeNodeValue(c, right_);

	// �����v�Z�m�[�h�̏���
	return c->MakeOp(op_, ret, left, right);
}

// ������߂𐶐�
//
//	a = b
//	>	mov a, b
//
CNodeValue CAssign::analyze(compiler *c)
{
	const CValueTag *tag = c->GetValueTag(value_->string());
	if (tag == 0) {
		tag = c->AddValue(value_->string());
	}
	if (tag == 0) {
		c->error(l_, "�ϐ� " + value_->string() + " ����`�ł��܂���B");
		return CNodeValue();
	}
	return expr_->analyze(c, tag->addr_);
}
