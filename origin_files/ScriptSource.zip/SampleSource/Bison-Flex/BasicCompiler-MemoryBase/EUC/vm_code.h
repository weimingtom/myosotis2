#ifdef	VM_ENUMDEF
#define	VMCODE0(code_, name_)	code_,
#define	VMCODE1(code_, name_)	code_,
#define	VMCODE2(code_, name_)	code_,
#define	VMCODE3(code_, name_)	code_,
#endif

#ifdef	VM_CREATE
#define	VMCODE0(code_, name_)	void name_()								\
		{																	\
			statement.push_back(CVMCode(code_));							\
		}
#define	VMCODE1(code_, name_)	void name_(int arg1)						\
		{																	\
			statement.push_back(CVMCode(code_, arg1));						\
		}
#define	VMCODE2(code_, name_)	void name_(int arg1, int arg2)				\
		{																	\
			statement.push_back(CVMCode(code_, arg1, arg2));				\
		}
#define	VMCODE3(code_, name_)	void name_(int arg1, int arg2, int arg3)	\
		{																	\
			statement.push_back(CVMCode(code_, arg1, arg2, arg3));			\
		}
#endif

#ifdef	VM_NAMETABLE
#define	VMCODE0(code_, name_)	#name_,
#define	VMCODE1(code_, name_)	#name_,
#define	VMCODE2(code_, name_)	#name_,
#define	VMCODE3(code_, name_)	#name_,
#endif

#ifdef	VM_SWITCHTABLE
#define	VMCODE0(code_, name_)	case code_:									\
		{																	\
			name_();														\
		}																	\
		break;
#define	VMCODE1(code_, name_)	case code_:									\
		{																	\
			const int *v = value(1);										\
			name_(v[0]);													\
		}																	\
		break;
#define	VMCODE2(code_, name_)	case code_:									\
		{																	\
			const int *v = value(2);										\
			name_(v[0], v[1]);												\
		}																	\
		break;
#define	VMCODE3(code_, name_)	case code_:									\
		{																	\
			const int *v = value(3);										\
			name_(v[0], v[1], v[2]);										\
		}																	\
		break;
#endif

VMCODE1(VM_PUSHCONST,			PushConst)
VMCODE1(VM_PUSHVALUE,			PushValue)
VMCODE1(VM_POPVALUE,			PopValue)
VMCODE0(VM_POP,					OpPop)
VMCODE2(VM_MOV_C,				OpMovC)
VMCODE2(VM_MOV_V,				OpMovV)
VMCODE2(VM_NEG_C,				OpNegC)
VMCODE2(VM_NEG_V,				OpNegV)
VMCODE3(VM_EQ_CC,				OpEqCC)
VMCODE3(VM_EQ_VC,				OpEqVC)
VMCODE3(VM_EQ_CV,				OpEqCV)
VMCODE3(VM_EQ_VV,				OpEqVV)
VMCODE3(VM_NE_CC,				OpNeCC)
VMCODE3(VM_NE_VC,				OpNeVC)
VMCODE3(VM_NE_CV,				OpNeCV)
VMCODE3(VM_NE_VV,				OpNeVV)
VMCODE3(VM_GT_CC,				OpGtCC)
VMCODE3(VM_GT_VC,				OpGtVC)
VMCODE3(VM_GT_CV,				OpGtCV)
VMCODE3(VM_GT_VV,				OpGtVV)
VMCODE3(VM_GE_CC,				OpGeCC)
VMCODE3(VM_GE_VC,				OpGeVC)
VMCODE3(VM_GE_CV,				OpGeCV)
VMCODE3(VM_GE_VV,				OpGeVV)
VMCODE3(VM_LT_CC,				OpLtCC)
VMCODE3(VM_LT_VC,				OpLtVC)
VMCODE3(VM_LT_CV,				OpLtCV)
VMCODE3(VM_LT_VV,				OpLtVV)
VMCODE3(VM_LE_CC,				OpLeCC)
VMCODE3(VM_LE_VC,				OpLeVC)
VMCODE3(VM_LE_CV,				OpLeCV)
VMCODE3(VM_LE_VV,				OpLeVV)
VMCODE3(VM_ADD_CC,				OpAddCC)
VMCODE3(VM_ADD_VC,				OpAddVC)
VMCODE3(VM_ADD_CV,				OpAddCV)
VMCODE3(VM_ADD_VV,				OpAddVV)
VMCODE3(VM_SUB_CC,				OpSubCC)
VMCODE3(VM_SUB_VC,				OpSubVC)
VMCODE3(VM_SUB_CV,				OpSubCV)
VMCODE3(VM_SUB_VV,				OpSubVV)
VMCODE3(VM_MUL_CC,				OpMulCC)
VMCODE3(VM_MUL_VC,				OpMulVC)
VMCODE3(VM_MUL_CV,				OpMulCV)
VMCODE3(VM_MUL_VV,				OpMulVV)
VMCODE3(VM_DIV_CC,				OpDivCC)
VMCODE3(VM_DIV_VC,				OpDivVC)
VMCODE3(VM_DIV_CV,				OpDivCV)
VMCODE3(VM_DIV_VV,				OpDivVV)
VMCODE3(VM_MOD_CC,				OpModCC)
VMCODE3(VM_MOD_VC,				OpModVC)
VMCODE3(VM_MOD_CV,				OpModCV)
VMCODE3(VM_MOD_VV,				OpModVV)
VMCODE1(VM_JMP,					OpJmp)
VMCODE2(VM_JMPC,				OpJmpC)
VMCODE2(VM_JMPNC,				OpJmpNC)
VMCODE1(VM_PRINT,				OpPrint)
VMCODE2(VM_RAND_C,				OpRandC)
VMCODE2(VM_RAND_V,				OpRandV)
VMCODE0(VM_HALT,				OpHalt)

#undef	VMCODE0
#undef	VMCODE1
#undef	VMCODE2
#undef	VMCODE3
