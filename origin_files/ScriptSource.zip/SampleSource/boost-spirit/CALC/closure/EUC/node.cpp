#include <iostream>
#include "node.h"

int cnode::expr(std::map<std::string, int> &values) const
{
	switch (op_) {
	  case OP_NEG:
		return -left_->expr(values);

	  case OP_PLUS:
		return left_->expr(values) + right_->expr(values);

	  case OP_MINUS:
		return left_->expr(values) - right_->expr(values);

	  case OP_TIMES:
		return left_->expr(values) * right_->expr(values);

	  case OP_DIVIDE:
		return left_->expr(values) / right_->expr(values);

	  case OP_NUMBER:
		return number_;

	  case OP_IDENT:
		return values[string_];

	  default:
		return 0;		// error
	}
}
