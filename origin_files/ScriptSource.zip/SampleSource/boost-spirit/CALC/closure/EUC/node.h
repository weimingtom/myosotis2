#ifndef __NODE_H__
#define	__NODE_H__

#include <iostream>
#include <string>
#include <map>
#include <boost/shared_ptr.hpp>

// �Ρ���

// �Ρ��ɤ�̿��
enum OPCODE {
	OP_NEG,
	OP_PLUS,
	OP_MINUS,
	OP_TIMES,
	OP_DIVIDE,
	OP_NUMBER,
	OP_IDENT,
} ;

// �Ρ���

class cnode;
typedef	boost::shared_ptr<cnode> cnode_t;

class cnode {
  public:
	cnode(int op, const cnode_t &left, const cnode_t &right)
		: op_(op), left_(left), right_(right), number_(0)
	{
	}
	cnode(int op, const cnode_t &left)
		: op_(op), left_(left), number_(0)
	{
	}
	cnode(int op, int number)
		: op_(op), number_(number)
	{
	}
	cnode(int op, const std::string &str)
		: op_(op), number_(0), string_(str)
	{
	}
	cnode(int op, const char *b, const char *e)
		: op_(op), string_(b, e)
	{
	}

	int expr(std::map<std::string, int> &values) const;

	int op() const { return op_; }
	int number() const { return number_; }
	const std::string &string() const { return string_; }
	cnode_t left() const { return left_; }
	cnode_t right() const { return right_; }

  protected:
	int op_;
	int number_;
	std::string string_;
	cnode_t left_;
	cnode_t right_;
} ;

#endif
