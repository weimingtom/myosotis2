//
//	boost::spirit�ɂ��AC���ꕗ�\���p�[�T�[
//
//		2008/06/05	Chihiro.SAKAMOTO
//		Copyright 	Chihiro.SAKAMOTO
//
#ifndef	__PARSER_H__
#define	__PARSER_H__

#include <string>

class compiler;
bool script_parser(const std::string &path, compiler *driver);

#endif
