//
//	boost::spirit�ˤ�롢C������������ץ�
//
//		2008/06/05	Chihiro.SAKAMOTO
//		Copyright 	Chihiro.SAKAMOTO
//
#include "stdafx.h"
#include "compiler.h"

// main

int main(int argc, char *argv[])
{
	for (++argv; argv[0]; ++argv) {
		vm::data data;
		bool compile_result;
		{
			compiler driver;
			compile_result = driver.compile(*argv, data);
#ifdef	_DEBUG
			if (compile_result)
				driver.debug_dump();
#endif
		}
		if (compile_result) {
			vm::vcpu machine(data);
			int result = machine.run();
			std::cout << "result = " << result << std::endl;
		}
	}

	return 0;
}
