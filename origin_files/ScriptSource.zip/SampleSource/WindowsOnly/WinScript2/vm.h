#ifndef	__VM_H__
#define	__VM_H__

#include <vector>
#include "vm_value.h"

#ifdef	_MSC_VER
//
//	VS2008�ł́A�Z�L���A���C�u�����֐��i*_s�j���g���悤�x�����o�܂��B 
//	�����ł́A��ʉ��igcc���̑Ή��j�̂��߁A�����C�u�������g�p���Ă���̂ŁA
//	�x����}�~���Ă��܂��B
//
#pragma warning(disable: 4996)
#endif

#define	VM_ENUMDEF
enum	{
#include "vm_code.h"
	VM_MAXCOMMAND,
} ;
#undef	VM_ENUMDEF

int VmMessageBox(const char *title, const char *message);
void VmMoveTo(int dc, int x, int y);
void VmLineTo(int dc, int x, int y);
void VmSetColor(int dc, int r, int g, int b);
int VmGetDC();
void VmReleaseDC(int hdc);

namespace vm {

	enum {
		SYS_TOSTR,
		SYS_MESSAGE_BOX,
		SYS_MOVE_TO,
		SYS_LINE_TO,
		SYS_SET_COLOR,
		SYS_GET_DC,
		SYS_RELEASE_DC,
	} ;

	class data {
	  public:
		enum {
			ON_CREATE,			// WM_CREATE
			ON_DESTROY,			// WM_DESTROY
			ON_PAINT,			// WM_PAINT
			ON_LBUTTONDOWN,		// WM_LBUTTONDOWN
			ON_LBUTTONUP,		// WM_LBUTTONUP
			ON_MOUSEMOVE,		// WM_MOUSEMOVE
			MAX_ENTRY_POINT		// �G���g���[�|�C���g�̐�
		} ;

	  public:
		data(): command_(0), text_buffer_(0)
		{
		}
		~data()
		{
			delete[] command_;
			delete[] text_buffer_;
		}

	  public:
		unsigned char *command_;	// �R�}���h�e�[�u��
		char *text_buffer_;			// �e�L�X�g�f�[�^
		int command_size_;			// �R�}���h�T�C�Y
		int text_size_;				// �e�L�X�g�T�C�Y
		int value_size_;			// �O���[�o���ϐ��T�C�Y
		int entry_point_[MAX_ENTRY_POINT];		// �J�n�ʒu
	} ;


	// 0���Z��O
	class devide_by_zero: public std::exception {
	  public:
		const char *what() const throw()
		{
			return "devide by zero";
		}
	} ;

	// ���z�}�V��
	class vcpu {
	  public:
		const static int STACK_SIZE = 1000;
		const static int global_flag = 0x4000000;
		const static int global_mask = 0x3ffffff;

	  public:
		vcpu()
		{
		}
		~vcpu()
		{
		}

//		int run();
		int call(data &program, int entry)
		{
			return internal_call(program, entry, 0, 0);
		}

		int call(data &program, int entry, int arg1)
		{
			int arg[] = { arg1 };
			return internal_call(program, entry, arg, 1);
		}

		int call(data &program, int entry, int arg1, int arg2)
		{
			int arg[] = { arg1, arg2 };
			return internal_call(program, entry, arg, 2);
		}

		int call(data &program, int entry, int arg1, int arg2, int arg3)
		{
			int arg[] = { arg1, arg2, arg3 };
			return internal_call(program, entry, arg, 3);
		}

	  private:
		int internal_call(data &program, int entry, int *arg, int narg);

	  private:
		// �萔Push
		void PushConst(int val)
		{
			push(val);
		}

		// �����萔Push
		void PushString(int val)
		{
			push(std::string(text_buffer_ + val));
		}

		// �ϐ�Push
		void PushValue(int val)
		{
			push(global_value[val]);
		}

		// ���[�J���ϐ�Push
		void PushLocal(int val)
		{
			push(stack[val + stack_base]);
		}

		// �z�񂩂�Push
		void PushArray(int val)
		{
			int index = top().i_; pop();
			push(global_value[val + index]);
		}

		// ���[�J���̔z�񂩂�Push
		void PushLocalArray(int val)
		{
			int index = top().i_; pop();
			push(stack[val + stack_base + index]);
		}

		// ���[�J���ϐ�(�Q��)Push
		void PushLocalRef(int val)
		{
			int addr = stack[val + stack_base].i_;
			push(ref_to_value(addr));
		}

		// ���[�J���̔z��(�Q��)����Push
		void PushLocalArrayRef(int val)
		{
			int addr = stack[val + stack_base].i_;
			int index = top().i_; pop();
			push(ref_to_value(addr + index));
		}

		// �A�h���X��Push
		void PushAddr(int val)
		{
			if ((val & global_flag) == 0)	// local
				val +=  + stack_base;
			push(val);
		}

		// �z��̃A�h���X��Push
		void PushArrayAddr(int val)
		{
			if ((val & global_flag) == 0)	// local
				val +=  + stack_base;
			int index = top().i_; pop();
			push(val + index);
		}

		// �ϐ���Pop
		void PopValue(int val)
		{
			global_value[val] = top(); pop();
		}

		// ���[�J���ϐ���Pop
		void PopLocal(int val)
		{
			stack[val + stack_base] = top(); pop();
		}

		// �z��ϐ���Pop
		void PopArray(int val)
		{
			int index = top().i_; pop();
			global_value[val + index] = top(); pop();
		}

		// ���[�J���̔z��ϐ���Pop
		void PopLocalArray(int val)
		{
			int index = top().i_; pop();
			stack[val + stack_base + index] = top(); pop();
		}

		// ���[�J���ϐ�(�Q��)��Pop
		void PopLocalRef(int val)
		{
			int addr = stack[val + stack_base].i_;
			set_ref(addr, top()); pop();
		}

		// ���[�J���̔z��ϐ�(�Q��)��Pop
		void PopLocalArrayRef(int val)
		{
			int addr = stack[val + stack_base].i_;
			int index = top().i_; pop();
			set_ref(addr + index, top()); pop();
		}

		// ���[�J���ϐ����m��
		void OpAllocStack(int val)
		{
			stack.resize(stack_base + val);
		}

		// ��Pop�i�X�^�b�N�g�b�v���̂Ă�j
		void OpPop()
		{
			pop();
		}

		// �P���}�C�i�X
		void OpNeg()
		{
			top().i_ = -top().i_;
		}

		// ==
		void OpEq()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs == rhs);
		}

		// !=
		void OpNe()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs != rhs);
		}

		// >
		void OpGt()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs > rhs);
		}

		// >=
		void OpGe()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs >= rhs);
		}

		// <
		void OpLt()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs < rhs);
		}

		// <=
		void OpLe()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs <= rhs);
		}

		// &&
		void OpLogAnd()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs && rhs);
		}

		// ||
		void OpLogOr()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs || rhs);
		}

		// &
		void OpAnd()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs & rhs);
		}

		// |
		void OpOr()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs | rhs);
		}

		// <<
		void OpLeftShift()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs << rhs);
		}

		// >>
		void OpRightShift()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs >> rhs);
		}

		// +
		void OpAdd()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs + rhs);
		}

		// -
		void OpSub()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs - rhs);
		}

		// *
		void OpMul()
		{
			int rhs = top().i_; pop();
			int lhs = top().i_; pop();
			push(lhs * rhs);
		}

		// /
		void OpDiv()
		{
			int rhs = top().i_; pop();
			if (rhs == 0)
				throw devide_by_zero();
			int lhs = top().i_; pop();
			push(lhs / rhs);
		}

		// %
		void OpMod()
		{
			int rhs = top().i_; pop();
			if (rhs == 0)
				throw devide_by_zero();
			int lhs = top().i_; pop();
			push(lhs % rhs);
		}

		// �������==
		void OpStrEq()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs == rhs);
		}

		// �������!=
		void OpStrNe()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs != rhs);
		}

		// �������>
		void OpStrGt()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs > rhs);
		}

		// �������>=
		void OpStrGe()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs >= rhs);
		}

		// �������<
		void OpStrLt()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs < rhs);
		}

		// �������<=
		void OpStrLe()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs <= rhs);
		}

		// �������+
		void OpStrAdd()
		{
			const std::string &rhs = text(top()); pop();
			const std::string &lhs = text(top()); pop();

			push(lhs + rhs);
		}

		// �������W�����v
		void OpJmp(int val)
		{
			jmp(val);
		}

		// �^�̎��W�����v
		void OpJmpC(int val)
		{
			int cond = top().i_; pop();
			if (cond)
				jmp(val);
		}

		// �U�̎��W�����v
		void OpJmpNC(int val)
		{
			int cond = top().i_; pop();
			if (!cond)
				jmp(val);
		}

		// switch���p���ꔻ��
		void OpTest(int val)
		{
			int value = top().i_; pop();
			if (value == top().i_) {
				pop();
				jmp(val);
			}
		}

		// �֐��R�[��
		void OpCall(int val)
		{
			push(stack_base);
			push(addr());					// ���^�[���A�h���X��Push
			stack_base = stack.size();		// �X�^�b�N�x�[�X�X�V
			jmp(val);
		}

		// �����Ȃ����^�[��
		void OpReturn()
		{
			stack.resize(stack_base);		// ���[�J���ϐ��r��
			int addr = top().i_; pop();
			stack_base = top().i_; pop();
			int arg_count = top().i_; pop();
			stack.pop(arg_count);
			jmp(addr);
		}

		// �����t�����^�[��
		void OpReturnV()
		{
			vm::value result = top(); pop();
			stack.resize(stack_base);		// ���[�J���ϐ��r��
			int addr = top().i_; pop();
			stack_base = top().i_; pop();
			int arg_count = top().i_; pop();
			stack.pop(arg_count);
			push(result);
			jmp(addr);
		}

		// ���zCPU�v���O������~
		void OpHalt()
		{
		}

		// �V�X�e���R�[���i�g�ݍ��݊֐��j
		void OpSysCall(int val)
		{
			pop();	// arg_count
			switch (val) {
			  case SYS_TOSTR:
				sys_tostr();
				break;
			  case SYS_MESSAGE_BOX:
				sys_message_box();
				break;
			  case SYS_MOVE_TO:
				sys_move_to();
				break;
			  case SYS_LINE_TO:
				sys_line_to();
				break;
			  case SYS_SET_COLOR:
				sys_set_color();
				break;
			  case SYS_GET_DC:
				sys_get_dc();
				break;
			  case SYS_RELEASE_DC:
				sys_release_dc();
				break;
			}
		}

		// �V�X�e���R�[���iMessageBox�j
		void sys_message_box()
		{
			const std::string message = text(top()); pop();
			const std::string title = text(top()); pop();

			push(VmMessageBox(title.c_str(), message.c_str()));
		}

		// �V�X�e���R�[���iMoveTo�j
		void sys_move_to()
		{
			int y = top().i_; pop();
			int x = top().i_; pop();
			int dc = top().i_; pop();

			VmMoveTo(dc, x, y);
		}

		// �V�X�e���R�[���iLineTo�j
		void sys_line_to()
		{
			int y = top().i_; pop();
			int x = top().i_; pop();
			int dc = top().i_; pop();

			VmLineTo(dc, x, y);
		}

		// �V�X�e���R�[���iSetColor�j
		void sys_set_color()
		{
			int b = top().i_; pop();
			int g = top().i_; pop();
			int r = top().i_; pop();
			int dc = top().i_; pop();

			VmSetColor(dc, r, g, b);
		}

		// �V�X�e���R�[���iGetDC�j
		void sys_get_dc()
		{
			push(VmGetDC());
		}

		// �V�X�e���R�[���iReleaseDC�j
		void sys_release_dc()
		{
			int dc = top().i_; pop();
			VmReleaseDC(dc);
		}

		// �V�X�e���R�[��(���l�𕶎���ɕϊ�)
		void sys_tostr()
		{
			int v = top().i_; pop();
			char str[16];
			sprintf(str, "%d", v);
			push(std::string(str));			// �߂�l�̓X�^�b�N�ɓ����
		}

	  private:
		int value() { int v = *(int *)command_ptr_; command_ptr_ += 4; return v; }
		int addr() const { return (int)(command_ptr_ - command_); }
		void jmp(int addr) { command_ptr_ = command_ + addr; }
		void push(int v) { stack.push(vm::value(v)); }
		void push(const std::string &v) { stack.push(vm::value(v)); }
		void push(const vm::value &v) { stack.push(v); }
		void pop() { stack.pop(); }
		const vm::value &top() const { return stack.top(); }
		vm::value &top() { return stack.top(); }
		std::string text(const vm::value &v) { return v.s_->str_; }
		const vm::value &ref_to_value(int addr) const
		{
			if (addr & global_flag)
				return global_value[addr & global_mask];
			return stack[addr];
		}
		void set_ref(int addr, const vm::value &v)
		{
			if (addr & global_flag)
				global_value[addr & global_mask] = v;
			else
				stack[addr] = v;
		}

	  private:
		unsigned char *command_;
		unsigned char *command_ptr_;
		int command_size_;
		char *text_buffer_;
		int text_size_;

		vm::stack<vm::value, STACK_SIZE> stack;
		std::vector<vm::value> global_value;
		int stack_base;
	} ;

}

#endif
